// Load environment variables FIRST before any other imports
import { config } from 'dotenv';
config({ path: '.env.local' });

// Shim to start Next.js dev server via existing npm dev script
import { spawn } from 'child_process';

console.log('🚀 Starting ApexContent Engine (Next.js)...\n');

// Start pg-boss workers in separate process with active event loop
console.log('🔧 Starting pg-boss workers in dedicated process...\n');
const workerProcess = spawn('tsx', ['server/worker-process.ts'], {
  stdio: 'inherit',
  shell: true,
});

workerProcess.on('error', (error) => {
  console.error('❌ Failed to start worker process:', error);
});

workerProcess.on('close', (code) => {
  console.log(`⚠️  Worker process exited with code ${code}`);
});

const nextDev = spawn('npx', ['next', 'dev'], {
  stdio: 'inherit',
  shell: true,
});

nextDev.on('error', (error) => {
  console.error('Failed to start Next.js:', error);
  process.exit(1);
});

nextDev.on('close', (code) => {
  console.log(`Next.js process exited with code ${code}`);
  process.exit(code || 0);
});

// Handle shutdown gracefully
process.on('SIGINT', () => {
  workerProcess.kill('SIGINT');
  nextDev.kill('SIGINT');
});

process.on('SIGTERM', () => {
  workerProcess.kill('SIGTERM');
  nextDev.kill('SIGTERM');
});
