"use client";

import { useQuery, useMutation } from "@tanstack/react-query";
import { use, Suspense } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, FileText, ExternalLink, Sparkles, Home, Trash2, RefreshCw } from "lucide-react";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useRouter } from "next/navigation";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Article {
  id: number;
  articleStatus: string;
  chosenTitle: string;
  seoTitle: string | null;
  slug: string | null;
  wordCount: number | null;
  createdAt: string;
}

interface Batch {
  id: number;
  userId: number;
  coreTopic: string;
  targetUrl: string;
  status: string;
  numArticlesRequested: number;
  titlePoolJson?: {
    titles: string[];
    primaryKeywords?: string[];
    contentStrategy?: string;
  } | null;
  createdAt: string;
  completedAt: string | null;
}

interface BatchResponse {
  batch: Batch;
  articles: Article[];
  summary: {
    total: number;
    completed: number;
    inProgress: number;
    pending: number;
    failed: number;
  };
}

function BatchDetailContent({ paramsPromise }: { paramsPromise: Promise<{ id: string }> }) {
  const resolvedParams = use(paramsPromise);
  const batchId = resolvedParams.id;
  const { toast } = useToast();
  const router = useRouter();

  const { data, isLoading, error, refetch, isFetching } = useQuery<BatchResponse>({
    queryKey: [`/api/batches/${batchId}`],
    refetchInterval: (query) => {
      // Auto-poll every 5 seconds when batch is actively running
      const batchData = query.state.data as BatchResponse | undefined;
      return batchData?.batch.status === "RUNNING" ? 5000 : false;
    },
  });

  const handleRefresh = async () => {
    await refetch();
    toast({
      title: "Refreshed",
      description: "Article statuses updated",
    });
  };

  const deleteBatchMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/batches/${batchId}`, {
        method: "DELETE",
      });
    },
    onSuccess: (data: any) => {
      toast({
        title: "Batch deleted",
        description: `Batch and ${data.deletedArticlesCount} articles permanently removed.`,
      });
      router.push("/content");
    },
    onError: (error) => {
      toast({
        title: "Delete failed",
        description: error instanceof Error ? error.message : "Failed to delete batch",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Batch not found</CardTitle>
            <CardDescription>The requested batch could not be loaded.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const { batch, articles, summary } = data;

  const hasTitlePool = batch.titlePoolJson && batch.titlePoolJson.titles && batch.titlePoolJson.titles.length > 0;
  const isPending = batch.status === "PENDING";

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2" data-testid="text-batch-title">{batch.coreTopic}</h1>
            <p className="text-muted-foreground" data-testid="text-batch-url">{batch.targetUrl}</p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={handleRefresh}
              disabled={isFetching}
              data-testid="button-refresh"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Link href="/home">
              <Button variant="outline" data-testid="button-home">
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
            </Link>
            {isPending && hasTitlePool && (
              <Link href={`/batches/${batch.id}/select`}>
                <Button data-testid="button-select-titles" size="lg">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Select Titles to Generate
                </Button>
              </Link>
            )}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" data-testid="button-delete-batch">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Batch
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this batch?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete the batch "{batch.coreTopic}" and all {summary.total} associated articles. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteBatchMutation.mutate()}
                    disabled={deleteBatchMutation.isPending}
                    className="bg-destructive hover:bg-destructive/90"
                    data-testid="button-confirm-delete"
                  >
                    {deleteBatchMutation.isPending ? "Deleting..." : "Delete Permanently"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Badge data-testid="badge-batch-status">{batch.status}</Badge>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-5">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Total</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-count">{summary.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Completed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600" data-testid="text-completed-count">{summary.completed}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600" data-testid="text-inprogress-count">{summary.inProgress}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-600" data-testid="text-pending-count">{summary.pending}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium">Failed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600" data-testid="text-failed-count">{summary.failed}</div>
            </CardContent>
          </Card>
        </div>
        
        {summary.failed > 0 && (
          <Card className="border-red-200 bg-red-50 dark:bg-red-950/10 dark:border-red-900">
            <CardHeader>
              <CardTitle className="text-red-800 dark:text-red-200">⚠️ Failed Articles</CardTitle>
              <CardDescription>
                {summary.failed} article(s) failed due to API quota limits or errors. You can requeue them to retry.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={async () => {
                  const failedArticles = articles.filter(a => a.articleStatus === "FAILED");
                  const response = await fetch("/api/admin/requeue-failed", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ articleIds: failedArticles.map(a => a.id) }),
                  });
                  if (response.ok) {
                    window.location.reload();
                  }
                }}
                variant="destructive"
                data-testid="button-requeue-failed"
              >
                Requeue {summary.failed} Failed Article(s)
              </Button>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Articles ({articles.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isPending && hasTitlePool && articles.length === 0 && (
              <div className="text-center py-8 space-y-4">
                <div className="text-muted-foreground">
                  <p className="mb-2">This batch has {batch.titlePoolJson!.titles.length} generated titles ready for selection.</p>
                  <p>Click "Select Titles to Generate" above to choose which articles to create.</p>
                </div>
              </div>
            )}
            {articles.length > 0 && (
              <div className="space-y-3">
                {articles.map((article) => (
                <div
                  key={article.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                  data-testid={`article-item-${article.id}`}
                >
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{article.chosenTitle}</h3>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      {article.wordCount && <span>{article.wordCount} words</span>}
                      {article.slug && <span className="font-mono">{article.slug}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={["COMPLETE", "GPT4_ENHANCED", "GEMINI_COMPLETE", "CHATGPT_REVIEWED"].includes(article.articleStatus) ? "default" : "secondary"}>
                      {article.articleStatus}
                    </Badge>
                    {["COMPLETE", "GPT4_ENHANCED", "GEMINI_COMPLETE", "CHATGPT_REVIEWED"].includes(article.articleStatus) && article.wordCount && (
                      <Link href={`/content/${article.id}`}>
                        <Button variant="outline" size="sm" data-testid={`button-view-article-${article.id}`}>
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View & Edit
                        </Button>
                      </Link>
                    )}
                  </div>
                </div>
              ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function BatchDetail({ params }: { params: Promise<{ id: string }> }) {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    }>
      <BatchDetailContent paramsPromise={params} />
    </Suspense>
  );
}
