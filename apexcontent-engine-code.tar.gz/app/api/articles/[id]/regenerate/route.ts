import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { articles, jobBatches, jobEvents } from "@/shared/schema";
import { eq, and } from "drizzle-orm";
import { addArticleJob } from "@/lib/queue";
import { getCompletedArticleRun, restoreArticleFromCache, shouldBypassCache } from "@/lib/article-run-cache";
import { requireTeamMember } from "@/lib/api/auth";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    // CRITICAL: Verify authentication and get team context
    const { teamId } = await requireTeamMember(request);

    const { id } = await context.params;
    const articleId = parseInt(id);
    
    if (isNaN(articleId)) {
      return NextResponse.json(
        { error: "Invalid article ID" },
        { status: 400 }
      );
    }

    const body = await request.json();
    const { customInstructions } = body;

    // CRITICAL: Verify article belongs to user's team
    const [article] = await db
      .select()
      .from(articles)
      .where(
        and(
          eq(articles.id, articleId),
          eq(articles.teamId, teamId) // TEAM ISOLATION
        )
      );

    if (!article) {
      return NextResponse.json(
        { error: "Article not found or access denied" },
        { status: 404 }
      );
    }

    const [batch] = await db
      .select()
      .from(jobBatches)
      .where(eq(jobBatches.id, article.batchId));

    if (!batch) {
      return NextResponse.json(
        { error: "Batch not found" },
        { status: 404 }
      );
    }

    // CRITICAL: Validate businessName before regeneration
    // Prevents generating content with generic "company" placeholders
    if (!batch.businessName || batch.businessName.trim().length === 0) {
      return NextResponse.json(
        { 
          error: "Business name required",
          message: "This batch was created without a business name. Article regeneration requires a valid business name to prevent AI hallucination of company names in text and images. Please update the batch business name first or create a new batch with a business name."
        },
        { status: 400 }
      );
    }

    // ============================================================================
    // CACHE REUSE SHORT-CIRCUIT
    // Check for completed runs and reuse cached outputs to avoid expensive regeneration
    // Bypassed if custom instructions provided (user wants fresh generation)
    // ============================================================================
    
    if (!shouldBypassCache(customInstructions)) {
      const cachedRun = await getCompletedArticleRun(articleId);
      
      if (cachedRun) {
        // OPTIMIZATION: Restore from cache instead of expensive API calls
        await restoreArticleFromCache(articleId, cachedRun);
        
        await db.insert(jobEvents).values({
          articleId,
          batchId: article.batchId,
          eventType: "ARTICLE_RESTORED_FROM_CACHE",
          stage: "OPTIMIZATION",
          message: `Article restored from cached run ${cachedRun.runId} (completed: ${cachedRun.completedAt}) - skipped expensive regeneration`,
          payloadJson: { 
            cachedRunId: cachedRun.runId,
            restoredAt: new Date(),
          },
          severity: "info",
        });
        
        console.log(`✅ [Article ${articleId}] Restored from cache - bypassed expensive regeneration`);
        
        return NextResponse.json({
          success: true,
          articleId,
          status: "COMPLETE",
          message: "Article restored from cache - no regeneration needed",
          cached: true,
          cachedRunId: cachedRun.runId,
        });
      }
    }

    const generationParams = batch.generationParams as any || {};
    const tone = generationParams.tone || "professional";
    const geographicFocus = generationParams.geographicFocus;
    const audience = generationParams.audience;
    const wordCountMin = generationParams.wordCountMin || 800;
    const wordCountMax = generationParams.wordCountMax || 2000;

    // CRITICAL: Reset article fields with team filter
    await db
      .update(articles)
      .set({ 
        articleStatus: "PENDING",
        finalHtmlContent: null,
        heroImageUrl: null,
        seoTitle: null,
        metaDescription: null,
        slug: null,
        keywordsJson: null,
        hashtagsJson: null,
        faqJson: null,
        wordCount: null,
        seoScore: null,
        hyperlinkedKeywordsJson: null,
        metaEnrichment: null,
        podcastUrl: null,
        podcastDuration: null,
        podcastStatus: "none",
        podcastGeneratedAt: null,
        podcastScriptJson: null,
      })
      .where(
        and(
          eq(articles.id, articleId),
          eq(articles.teamId, teamId) // CRITICAL TEAM FILTER ON UPDATE
        )
      );

    await db.insert(jobEvents).values({
      articleId,
      batchId: article.batchId,
      eventType: "ARTICLE_REGENERATION_REQUESTED",
      stage: "ORCHESTRATION",
      message: customInstructions 
        ? `Article regeneration requested with instructions: ${customInstructions.slice(0, 200)}`
        : "Article regeneration requested",
      payloadJson: { 
        customInstructions: customInstructions || null,
        originalTitle: article.chosenTitle,
        wordCountMin,
        wordCountMax,
      },
      severity: "info",
    });

    // Generate a new run ID for this regeneration attempt
    // Each regeneration gets a fresh run ID to track separate attempts
    // This allows the worker to detect duplicates and reuse cache when applicable
    const runId = crypto.randomUUID();
    
    await addArticleJob({
      articleId: article.id,
      batchId: article.batchId,
      runId, // Unique ID for this regeneration attempt
      title: article.chosenTitle,
      targetUrl: batch.targetUrl,
      tone,
      wordCountMin,
      wordCountMax,
      geographicFocus,
      audience,
      businessName: batch.businessName || undefined,
      companyLogoUrl: batch.companyLogoUrl || undefined,
      competitorUrls: batch.competitorUrlsJson as string[] || undefined,
      semanticClusterId: batch.semanticClusterId || undefined,
      serpFeatureTarget: batch.serpFeatureTarget || undefined,
      customInstructions: customInstructions || undefined,
    });

    console.log(`🔄 Article ${articleId} queued for regeneration${customInstructions ? ' with custom instructions' : ''}`);

    return NextResponse.json({
      success: true,
      articleId,
      status: "PENDING",
      message: customInstructions 
        ? "Article regeneration started with your custom instructions"
        : "Article regeneration started",
    });
  } catch (error) {
    console.error("❌ Article regeneration error:", error);
    return NextResponse.json(
      { 
        error: "Failed to regenerate article",
        message: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    );
  }
}
