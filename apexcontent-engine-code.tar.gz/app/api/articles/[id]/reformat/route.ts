import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { articles } from "@/shared/schema";
import { eq, and } from "drizzle-orm";
import { addReformatJob } from "@/lib/queue";
import { requireTeamMember } from "@/lib/api/auth";

export async function POST(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    // CRITICAL: Verify authentication and get team context
    const { teamId } = await requireTeamMember(request);

    const { id } = await context.params;
    const articleId = parseInt(id);

    if (isNaN(articleId)) {
      return NextResponse.json(
        { error: "Invalid article ID" },
        { status: 400 }
      );
    }

    // CRITICAL: Verify article belongs to user's team
    const [article] = await db
      .select()
      .from(articles)
      .where(
        and(
          eq(articles.id, articleId),
          eq(articles.teamId, teamId) // TEAM ISOLATION
        )
      );

    if (!article) {
      return NextResponse.json(
        { error: "Article not found or access denied" },
        { status: 404 }
      );
    }

    // Queue reformat job (runs in background - instant response)
    await addReformatJob({ articleId });

    console.log(`🔄 Reformat job queued for article ${articleId}`);

    return NextResponse.json({
      success: true,
      message: "Reformat job queued - will complete in 20-30 seconds",
      articleId,
    });

  } catch (error) {
    console.error("❌ Reformat queue error:", error);
    return NextResponse.json(
      { 
        error: "Failed to queue reformat",
        message: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    );
  }
}
