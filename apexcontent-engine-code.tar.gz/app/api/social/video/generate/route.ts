import { NextRequest, NextResponse } from "next/server";
import { getPgBoss } from "@/lib/queue";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { socialPostId, platform = "tiktok" } = body;

    if (!socialPostId) {
      return NextResponse.json(
        { error: "socialPostId is required" },
        { status: 400 }
      );
    }

    // Validate that the social post has a company name
    const { db } = await import("@/lib/db");
    const { socialPosts } = await import("@/shared/schema");
    const { eq } = await import("drizzle-orm");
    
    const [post] = await db
      .select()
      .from(socialPosts)
      .where(eq(socialPosts.id, socialPostId))
      .limit(1);

    if (!post) {
      return NextResponse.json(
        { error: "Social post not found" },
        { status: 404 }
      );
    }

    if (!post.companyName) {
      return NextResponse.json(
        { 
          error: "Company name is required for video generation",
          message: "Please edit this post to add your company name before generating a video."
        },
        { status: 400 }
      );
    }

    console.log(`📹 Queueing video generation for Social Post ${socialPostId}`);

    // CRITICAL: Update status IMMEDIATELY before queuing to fix double-click issue
    await db
      .update(socialPosts)
      .set({
        videoStatus: "GENERATING",
        videoProgress: 0,
        videoStage: "queued",
        updatedAt: new Date(),
      })
      .where(eq(socialPosts.id, socialPostId));

    console.log(`✅ Video status set to GENERATING (progress: 0%, stage: queued)`);

    // Queue the video generation job
    const queue = await getPgBoss();
    console.log(`📋 pg-boss instance obtained, attempting to send job...`);
    
    const jobId = await queue.send(
      "social-video-generation",
      { socialPostId, platform },
      {
        retryLimit: 2, // Retry twice on failure
        retryDelay: 30, // 30 seconds between retries
        expireInSeconds: 900, // 15 minutes max
      }
    );

    if (!jobId) {
      console.error(`❌ CRITICAL: pg-boss.send() returned NULL! Job was NOT queued.`);
      // Rollback status if job queueing failed
      await db
        .update(socialPosts)
        .set({
          videoStatus: "FAILED",
          videoProgress: 0,
          videoStage: null,
          errorMessage: "Failed to queue job - pg-boss returned null",
        })
        .where(eq(socialPosts.id, socialPostId));
      
      throw new Error("Failed to queue video generation job - pg-boss returned null. The job queue may not be accepting jobs.");
    }

    console.log(`✅ Video generation job queued successfully: ${jobId}`);

    return NextResponse.json({
      success: true,
      jobId,
      socialPostId,
      platform,
      message: "Video generation started. This will take 2-3 minutes.",
      estimatedTime: "2-3 minutes",
      videoStatus: "GENERATING",
      videoProgress: 0,
      videoStage: "queued",
    });
  } catch (error) {
    console.error("❌ Failed to queue video generation:", error);
    return NextResponse.json(
      {
        error: "Failed to start video generation",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
