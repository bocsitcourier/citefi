import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { socialPosts } from "@/shared/schema";
import { desc, ne, and, eq } from "drizzle-orm";
import { requireTeamMember } from "@/lib/api/auth";

export async function GET(request: NextRequest) {
  try {
    // CRITICAL: Verify authentication and get team context
    const { teamId } = await requireTeamMember(request);

    // CRITICAL: Fetch posts filtered by team_id
    const posts = await db
      .select()
      .from(socialPosts)
      .where(
        and(
          ne(socialPosts.status, "DELETED"),
          eq(socialPosts.teamId, teamId) // TEAM ISOLATION
        )
      )
      .orderBy(desc(socialPosts.createdAt));

    return NextResponse.json(posts);
  } catch (error) {
    console.error("Failed to fetch social posts:", error);
    return NextResponse.json(
      { error: "Failed to fetch social posts" },
      { status: 500 }
    );
  }
}
