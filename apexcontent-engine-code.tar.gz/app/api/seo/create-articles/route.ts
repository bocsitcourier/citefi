import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { jobBatches, articles, users } from "@/shared/schema";
import { eq } from "drizzle-orm";
import { addBatchGenerationJob } from "@/lib/queue";
import { generateTitlePool } from "@/lib/gemini";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      userId = 1, 
      seoToolType, 
      seoToolOutput, 
      targetUrl,
      numArticles = 5,
      wordCountMin = 800,
      wordCountMax = 2000,
      tone = "professional"
    } = body;

    if (!seoToolType || !seoToolOutput || !targetUrl) {
      return NextResponse.json(
        { error: "Missing required fields: seoToolType, seoToolOutput, targetUrl" },
        { status: 400 }
      );
    }

    // Verify user exists
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId));

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      );
    }

    // Generate article titles based on SEO tool output
    let coreTopic = "";
    let titlePoolResult;

    switch (seoToolType) {
      case "local_research": {
        const location = seoToolOutput.location || "";
        const businessType = seoToolOutput.business_type || "";
        coreTopic = `${businessType} in ${location}`;
        
        // Generate titles based on local SEO insights
        const localKeywords = seoToolOutput.location_keywords?.primary?.join(", ") || "";
        const localQuestions = seoToolOutput.local_questions?.map((q: any) => q.question).join(", ") || "";
        const enhancedTopic = `${coreTopic} - Focus: ${localKeywords}. Questions: ${localQuestions}`;
        
        titlePoolResult = await generateTitlePool(
          enhancedTopic.substring(0, 500),
          targetUrl,
          Math.min(numArticles * 2, 50),
          tone,
          location,
          seoToolOutput.trending_topics?.map((t: any) => t.topic).join(", ")
        );
        break;
      }

      case "competitor_analysis": {
        coreTopic = `Competitive Analysis - ${seoToolOutput.competitor_url}`;
        
        // Generate titles based on competitor gaps and opportunities
        const contentGaps = seoToolOutput.content_gaps?.join(", ") || "";
        const uniqueAngles = seoToolOutput.unique_angles?.join(", ") || "";
        const enhancedTopic = `Content Opportunities: ${contentGaps}. Unique Angles: ${uniqueAngles}`;
        
        titlePoolResult = await generateTitlePool(
          enhancedTopic.substring(0, 500),
          targetUrl,
          Math.min(numArticles * 2, 50),
          tone,
          undefined,
          seoToolOutput.keyword_opportunities?.join(", ")
        );
        break;
      }

      case "content_structure": {
        coreTopic = seoToolOutput.title || "SEO-Optimized Content";
        
        // Generate titles based on content structure
        const headings = seoToolOutput.headings?.map((h: any) => h.text).join(", ") || "";
        const keyTakeaways = seoToolOutput.key_takeaways?.join(", ") || "";
        const enhancedTopic = `${coreTopic}. Structure: ${headings}. Takeaways: ${keyTakeaways}`;
        
        titlePoolResult = await generateTitlePool(
          enhancedTopic.substring(0, 500),
          targetUrl,
          Math.min(numArticles * 2, 50),
          tone
        );
        break;
      }

      case "pillar_cluster": {
        // Handle pillar/cluster strategy
        const pillarTitle = seoToolOutput.pillar_page?.title || 
                           seoToolOutput.title || 
                           "Content Strategy";
        coreTopic = pillarTitle;
        
        const pillarKeywords = seoToolOutput.pillar_page?.target_keywords?.join(", ") || 
                               seoToolOutput.target_keywords?.join(", ") || "";
        const enhancedTopic = `${coreTopic}. Keywords: ${pillarKeywords}`;
        
        titlePoolResult = await generateTitlePool(
          enhancedTopic.substring(0, 500),
          targetUrl,
          Math.min(numArticles * 2, 50),
          tone,
          undefined,
          pillarKeywords
        );
        break;
      }

      default:
        return NextResponse.json(
          { error: "Invalid SEO tool type. Must be: local_research, competitor_analysis, content_structure, or pillar_cluster" },
          { status: 400 }
        );
    }

    // Create batch with title pool
    const [batch] = await db
      .insert(jobBatches)
      .values({
        userId,
        coreTopic,
        targetUrl,
        status: "PENDING",
        numArticlesRequested: numArticles,
        titlePoolJson: {
          titles: titlePoolResult.titles,
          primaryKeywords: titlePoolResult.primaryKeywords,
          contentStrategy: titlePoolResult.contentStrategy,
          seoToolType,
          seoToolOutput,
        },
      })
      .returning();

    // Select the first N titles for article generation
    const selectedTitles = titlePoolResult.titles.slice(0, numArticles);

    // Create article records
    const articleRecords = selectedTitles.map((title: string) => ({
      batchId: batch.id,
      chosenTitle: title,
      articleStatus: "PENDING",
    }));

    const createdArticles = await db
      .insert(articles)
      .values(articleRecords)
      .returning();

    // Update batch status
    await db
      .update(jobBatches)
      .set({ status: "RUNNING" })
      .where(eq(jobBatches.id, batch.id));

    // Queue batch generation job
    const jobId = await addBatchGenerationJob({
      batchId: batch.id,
      userId,
      selectedTitles,
      targetUrl,
      tone,
      wordCountMin,
      wordCountMax,
    });

    console.log(`✅ SEO-based batch created: ${batch.id} with ${selectedTitles.length} articles from ${seoToolType}`);

    return NextResponse.json({
      success: true,
      batchId: batch.id,
      articleIds: createdArticles.map((a: any) => a.id),
      numArticles: selectedTitles.length,
      titles: selectedTitles,
      message: `${selectedTitles.length} articles queued for generation based on ${seoToolType} insights`,
    });
  } catch (error) {
    console.error("❌ SEO article creation error:", error);
    return NextResponse.json(
      { 
        error: "Failed to create articles from SEO tool output",
        message: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    );
  }
}
