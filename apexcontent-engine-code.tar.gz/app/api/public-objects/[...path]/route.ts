import { NextRequest, NextResponse } from "next/server";
import { objectStorageClient } from "@/lib/storage";

export const dynamic = "force-dynamic";

// Serve public objects from Replit Object Storage
export async function GET(
  request: NextRequest,
  context: { params: Promise<{ path: string[] }> }
) {
  try {
    const { path } = await context.params;
    const filePath = path.join("/");
    
    // Extract bucket ID from environment
    const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
    if (!bucketId) {
      return NextResponse.json(
        { error: "Object storage not configured" },
        { status: 500 }
      );
    }

    // Get the file from object storage
    // Note: Files are stored with 'public/' prefix in GCS
    const bucket = objectStorageClient.bucket(bucketId);
    const fullPath = `public/${filePath}`;
    const file = bucket.file(fullPath);
    
    const [exists] = await file.exists();
    if (!exists) {
      console.error(`[PUBLIC_OBJECTS] File not found: ${fullPath}`);
      return NextResponse.json(
        { error: "File not found" },
        { status: 404 }
      );
    }

    // Get file metadata for content type
    const [metadata] = await file.getMetadata();
    
    // Stream the file
    const stream = file.createReadStream();
    const chunks: Buffer[] = [];
    
    for await (const chunk of stream) {
      chunks.push(Buffer.from(chunk));
    }
    
    const buffer = Buffer.concat(chunks);
    
    return new NextResponse(buffer, {
      headers: {
        "Content-Type": metadata.contentType || "application/octet-stream",
        "Content-Length": metadata.size?.toString() || buffer.length.toString(),
        "Cache-Control": "public, max-age=31536000", // Cache for 1 year
      },
    });
  } catch (error) {
    console.error("[PUBLIC_OBJECTS] Error serving file:", error);
    return NextResponse.json(
      { error: "Failed to serve file" },
      { status: 500 }
    );
  }
}
