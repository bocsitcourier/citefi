import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { userQuotas, adminActionLogs } from "@/shared/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/api/auth";
import { z } from "zod";

interface RouteParams {
  params: Promise<{ userId: string }>;
}

const quotaUpdateSchema = z.object({
  articlesPerDay: z.number().int().min(0).max(10000).optional(),
  articlesPerMonth: z.number().int().min(0).max(100000).optional(),
  socialsPerDay: z.number().int().min(0).max(1000).optional(),
  socialsPerMonth: z.number().int().min(0).max(10000).optional(),
  videosPerDay: z.number().int().min(0).max(500).optional(),
  videosPerMonth: z.number().int().min(0).max(5000).optional(),
});

export async function PUT(req: NextRequest, { params }: RouteParams) {
  try {
    const adminUserId = await requireAdmin(req);
    const resolvedParams = await params;
    const userId = parseInt(resolvedParams.userId);
    const body = await req.json();

    const validationResult = quotaUpdateSchema.safeParse(body);
    if (!validationResult.success) {
      return NextResponse.json(
        { error: "Invalid quota values provided", details: validationResult.error.errors },
        { status: 400 }
      );
    }

    const {
      articlesPerDay,
      articlesPerMonth,
      socialsPerDay,
      socialsPerMonth,
      videosPerDay,
      videosPerMonth,
    } = validationResult.data;

    const [existingQuota] = await db
      .select()
      .from(userQuotas)
      .where(eq(userQuotas.userId, userId))
      .limit(1);

    if (existingQuota) {
      await db
        .update(userQuotas)
        .set({
          articlesPerDay: articlesPerDay ?? existingQuota.articlesPerDay,
          articlesPerMonth: articlesPerMonth ?? existingQuota.articlesPerMonth,
          socialsPerDay: socialsPerDay ?? existingQuota.socialsPerDay,
          socialsPerMonth: socialsPerMonth ?? existingQuota.socialsPerMonth,
          videosPerDay: videosPerDay ?? existingQuota.videosPerDay,
          videosPerMonth: videosPerMonth ?? existingQuota.videosPerMonth,
          updatedAt: new Date(),
        })
        .where(eq(userQuotas.userId, userId));
    } else {
      await db.insert(userQuotas).values({
        userId,
        articlesPerDay: articlesPerDay ?? 100,
        articlesPerMonth: articlesPerMonth ?? 1000,
        socialsPerDay: socialsPerDay ?? 50,
        socialsPerMonth: socialsPerMonth ?? 500,
        videosPerDay: videosPerDay ?? 10,
        videosPerMonth: videosPerMonth ?? 100,
        currentDayArticles: 0,
        currentMonthArticles: 0,
        currentDaySocials: 0,
        currentMonthSocials: 0,
        currentDayVideos: 0,
        currentMonthVideos: 0,
        quotaPeriodStart: new Date(),
      });
    }

    const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0] || 
                     req.headers.get('x-real-ip') || 
                     'unknown';

    await db.insert(adminActionLogs).values({
      adminUserId,
      action: 'quota_updated',
      targetUserId: userId,
      ipAddress: clientIp,
      metadata: {
        articlesPerDay,
        articlesPerMonth,
        socialsPerDay,
        socialsPerMonth,
        videosPerDay,
        videosPerMonth,
      } as any,
    });

    return NextResponse.json({
      success: true,
      message: "Quota updated successfully",
    });
  } catch (error: any) {
    console.error("Update quota error:", error);
    
    const message = error instanceof Error ? error.message : "Failed to update quota";
    let status = 500;
    
    if (message === "Authentication required" || message === "No authentication token provided" || message === "Invalid or expired token") {
      status = 401;
    } else if (message === "Admin access required") {
      status = 403;
    } else if (error.statusCode) {
      status = error.statusCode;
    }
    
    return NextResponse.json({ error: message }, { status });
  }
}

export async function POST(req: NextRequest, { params }: RouteParams) {
  try {
    const adminUserId = await requireAdmin(req);
    const resolvedParams = await params;
    const userId = parseInt(resolvedParams.userId);

    const [existingQuota] = await db
      .select()
      .from(userQuotas)
      .where(eq(userQuotas.userId, userId))
      .limit(1);

    if (existingQuota) {
      await db
        .update(userQuotas)
        .set({
          currentDayArticles: 0,
          currentMonthArticles: 0,
          currentDaySocials: 0,
          currentMonthSocials: 0,
          currentDayVideos: 0,
          currentMonthVideos: 0,
          quotaPeriodStart: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(userQuotas.userId, userId));
    } else {
      await db.insert(userQuotas).values({
        userId,
        articlesPerDay: 100,
        articlesPerMonth: 1000,
        socialsPerDay: 50,
        socialsPerMonth: 500,
        videosPerDay: 10,
        videosPerMonth: 100,
        currentDayArticles: 0,
        currentMonthArticles: 0,
        currentDaySocials: 0,
        currentMonthSocials: 0,
        currentDayVideos: 0,
        currentMonthVideos: 0,
        quotaPeriodStart: new Date(),
      });
    }

    const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0] || 
                     req.headers.get('x-real-ip') || 
                     'unknown';

    await db.insert(adminActionLogs).values({
      adminUserId,
      action: 'quota_reset',
      targetUserId: userId,
      ipAddress: clientIp,
      metadata: { reason: 'Manual reset by admin' } as any,
    });

    return NextResponse.json({
      success: true,
      message: "Quota usage reset successfully",
    });
  } catch (error: any) {
    console.error("Reset quota error:", error);
    
    const message = error instanceof Error ? error.message : "Failed to reset quota";
    let status = 500;
    
    if (message === "Authentication required" || message === "No authentication token provided" || message === "Invalid or expired token") {
      status = 401;
    } else if (message === "Admin access required") {
      status = 403;
    } else if (error.statusCode) {
      status = error.statusCode;
    }
    
    return NextResponse.json({ error: message }, { status });
  }
}
