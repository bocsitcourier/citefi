import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { userQuotas, users } from "@/shared/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/api/auth";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);

    const quotas = await db
      .select({
        id: userQuotas.id,
        userId: userQuotas.userId,
        userEmail: users.email,
        userName: users.fullName,
        articlesPerDay: userQuotas.articlesPerDay,
        articlesPerMonth: userQuotas.articlesPerMonth,
        socialsPerDay: userQuotas.socialsPerDay,
        socialsPerMonth: userQuotas.socialsPerMonth,
        videosPerDay: userQuotas.videosPerDay,
        videosPerMonth: userQuotas.videosPerMonth,
        currentDayArticles: userQuotas.currentDayArticles,
        currentMonthArticles: userQuotas.currentMonthArticles,
        currentDaySocials: userQuotas.currentDaySocials,
        currentMonthSocials: userQuotas.currentMonthSocials,
        currentDayVideos: userQuotas.currentDayVideos,
        currentMonthVideos: userQuotas.currentMonthVideos,
        quotaPeriodStart: userQuotas.quotaPeriodStart,
      })
      .from(userQuotas)
      .leftJoin(users, eq(userQuotas.userId, users.id));

    return NextResponse.json(quotas);
  } catch (error: any) {
    console.error("Get quotas error:", error);
    
    const message = error instanceof Error ? error.message : "Failed to fetch quotas";
    let status = 500;
    
    if (message === "Authentication required" || message === "No authentication token provided" || message === "Invalid or expired token") {
      status = 401;
    } else if (message === "Admin access required") {
      status = 403;
    } else if (error.statusCode) {
      status = error.statusCode;
    }
    
    return NextResponse.json({ error: message }, { status });
  }
}
