import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { users, activityLogs } from "@/shared/schema";
import { requireAdmin } from "@/lib/api/auth";
import { eq } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Verify admin access
    const admin = await requireAdmin(req);
    const { id } = await params;
    const userId = parseInt(id);

    if (isNaN(userId)) {
      return NextResponse.json(
        { error: "Invalid user ID" },
        { status: 400 }
      );
    }

    // Prevent self-suspension
    if (userId === admin.id) {
      return NextResponse.json(
        { error: "Cannot suspend your own account" },
        { status: 400 }
      );
    }

    // Get user
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user) {
      return NextResponse.json(
        { error: "User not found" },
        { status: 404 }
      );
    }

    // Update user status to suspended
    await db
      .update(users)
      .set({
        accountStatus: "suspended",
      })
      .where(eq(users.id, userId));

    // Log activity
    await db.insert(activityLogs).values({
      userId: admin.id,
      action: "user_suspended",
      resource: "users",
      resourceId: userId,
      ipAddress: req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || null,
      userAgent: req.headers.get("user-agent") || null,
      details: { 
        suspendedEmail: user.email,
        suspendedBy: admin.email,
        previousStatus: user.accountStatus,
      },
      severity: "warning",
    });

    return NextResponse.json({
      message: "User suspended successfully",
      user: {
        id: user.id,
        email: user.email,
        accountStatus: "suspended",
      },
    });
  } catch (error: any) {
    console.error("Suspend user error:", error);
    
    if (error.message === "Admin access required") {
      return NextResponse.json(
        { error: "Admin access required" },
        { status: 403 }
      );
    }

    if (error.message === "No authentication token provided" || 
        error.message === "Invalid or expired token") {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
