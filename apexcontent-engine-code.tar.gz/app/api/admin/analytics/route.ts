import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/api/auth";
import { db } from "@/lib/db";
import { articles, users } from "@/shared/schema";
import { sql, gte, and, eq } from "drizzle-orm";
import { subDays } from "date-fns";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);

    const { searchParams } = new URL(req.url);
    const days = parseInt(searchParams.get("days") || "30");

    const startDate = subDays(new Date(), days);

    const dailyStatsResult = await db.execute(sql`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as total_articles,
        COUNT(DISTINCT user_id) as active_users
      FROM ${articles}
      WHERE created_at >= ${startDate}
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    `);
    const dailyStats = (dailyStatsResult as any).rows || [];

    const userStats = await db
      .select({
        userId: articles.userId,
        userEmail: users.email,
        userName: users.fullName,
        articleCount: sql<number>`count(${articles.id})`,
      })
      .from(articles)
      .leftJoin(users, eq(articles.userId, users.id))
      .where(gte(articles.createdAt, startDate))
      .groupBy(articles.userId, users.email, users.fullName)
      .orderBy(sql`count(${articles.id}) DESC`)
      .limit(10);

    const totalArticles = await db
      .select({ count: sql<number>`count(*)` })
      .from(articles)
      .where(gte(articles.createdAt, startDate));

    const totalUsers = await db
      .select({ count: sql<number>`count(DISTINCT ${articles.userId})` })
      .from(articles)
      .where(gte(articles.createdAt, startDate));

    return NextResponse.json({
      period: {
        days,
        startDate: startDate.toISOString(),
        endDate: new Date().toISOString(),
      },
      summary: {
        totalArticles: Number(totalArticles[0]?.count) || 0,
        activeUsers: Number(totalUsers[0]?.count) || 0,
        averagePerDay: Number(totalArticles[0]?.count || 0) / days,
      },
      dailyStats: dailyStats,
      topUsers: userStats,
    });
  } catch (error: any) {
    console.error("Analytics error:", error);
    
    const message = error instanceof Error ? error.message : "Failed to fetch analytics";
    let status = 500;
    
    if (message === "Authentication required" || message === "No authentication token provided" || message === "Invalid or expired token") {
      status = 401;
    } else if (message === "Admin access required") {
      status = 403;
    } else if (error.statusCode) {
      status = error.statusCode;
    }
    
    return NextResponse.json({ error: message }, { status });
  }
}
