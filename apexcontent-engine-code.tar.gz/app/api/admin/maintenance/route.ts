import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { maintenanceFlags, adminActionLogs } from "@/shared/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/api/auth";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);

    const [flag] = await db
      .select()
      .from(maintenanceFlags)
      .where(eq(maintenanceFlags.id, 1))
      .limit(1);

    if (!flag) {
      await db.insert(maintenanceFlags).values({
        id: 1,
        isEnabled: false,
        message: "System is under maintenance. Please check back later.",
      });

      return NextResponse.json({
        isEnabled: false,
        message: "System is under maintenance. Please check back later.",
      });
    }

    return NextResponse.json(flag);
  } catch (error) {
    console.error("Get maintenance flag error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch maintenance flag" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const adminUserId = await requireAdmin(req);
    const { isEnabled, message } = await req.json();

    const [existing] = await db
      .select()
      .from(maintenanceFlags)
      .where(eq(maintenanceFlags.id, 1))
      .limit(1);

    if (existing) {
      await db
        .update(maintenanceFlags)
        .set({
          isEnabled,
          message: message || "System is under maintenance. Please check back later.",
          updatedAt: new Date(),
        })
        .where(eq(maintenanceFlags.id, 1));
    } else {
      await db.insert(maintenanceFlags).values({
        id: 1,
        isEnabled,
        message: message || "System is under maintenance. Please check back later.",
      });
    }

    const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0] || 
                     req.headers.get('x-real-ip') || 
                     'unknown';

    await db.insert(adminActionLogs).values({
      adminUserId,
      action: 'maintenance_mode_toggled',
      ipAddress: clientIp,
      metadata: JSON.stringify({
        isEnabled,
        message,
      }),
    });

    return NextResponse.json({
      success: true,
      isEnabled,
      message,
    });
  } catch (error) {
    console.error("Update maintenance flag error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to update maintenance flag" },
      { status: 500 }
    );
  }
}
