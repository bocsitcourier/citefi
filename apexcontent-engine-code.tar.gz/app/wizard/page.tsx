"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, ChevronLeft, Sparkles } from "lucide-react";
import { useRouter } from "next/navigation";

export default function ContentWizard() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    coreTopic: "",
    targetUrl: "",
    competitorUrls: [] as string[],
    geographicFocus: "",
    serpFeatureTarget: "none",
    semanticClusterId: undefined as number | undefined,
    tone: "professional",
    numTitles: 25,
  });

  const steps = [
    { id: 1, title: "Topic & URL", description: "Define your content topic" },
    { id: 2, title: "Competitor Analysis", description: "Add competitor URLs" },
    { id: 3, title: "SEO Optimization", description: "Configure SEO features" },
    { id: 4, title: "Review & Generate", description: "Review and create" },
  ];

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleGenerate = () => {
    // Store in sessionStorage and redirect to dashboard
    sessionStorage.setItem("wizardData", JSON.stringify(formData));
    router.push("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold" data-testid="text-wizard-title">
            Guided Content Creation
          </h1>
          <p className="text-muted-foreground">
            Step-by-step wizard for creating SEO-optimized content
          </p>
        </div>

        <div className="flex items-center justify-center gap-2">
          {steps.map((s, idx) => (
            <div key={s.id} className="flex items-center">
              <div
                className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                  step >= s.id ? "bg-primary text-primary-foreground" : "bg-muted"
                }`}
              >
                <div className="w-6 h-6 rounded-full bg-background text-foreground flex items-center justify-center text-sm font-bold">
                  {s.id}
                </div>
                <span className="text-sm font-medium hidden md:inline">{s.title}</span>
              </div>
              {idx < steps.length - 1 && (
                <ChevronRight className="w-5 h-5 mx-2 text-muted-foreground" />
              )}
            </div>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{steps[step - 1].title}</CardTitle>
            <CardDescription>{steps[step - 1].description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {step === 1 && (
              <>
                <div className="space-y-2">
                  <Label>Core Topic *</Label>
                  <Input
                    placeholder="e.g., Best CRM Software for Small Businesses"
                    value={formData.coreTopic}
                    onChange={(e) => setFormData({ ...formData, coreTopic: e.target.value })}
                    data-testid="input-core-topic"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Target URL *</Label>
                  <Input
                    placeholder="https://yoursite.com/target-page"
                    value={formData.targetUrl}
                    onChange={(e) => setFormData({ ...formData, targetUrl: e.target.value })}
                    data-testid="input-target-url"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Number of Titles</Label>
                  <Input
                    type="number"
                    min={5}
                    max={100}
                    value={formData.numTitles}
                    onChange={(e) => setFormData({ ...formData, numTitles: parseInt(e.target.value) })}
                    data-testid="input-num-titles"
                  />
                </div>
              </>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Add up to 5 competitor URLs to analyze their content strategy (optional)
                </p>
                {[0, 1, 2, 3, 4].map((idx) => (
                  <div key={idx} className="space-y-2">
                    <Label>Competitor URL {idx + 1}</Label>
                    <Input
                      placeholder={`https://competitor${idx + 1}.com/article`}
                      value={formData.competitorUrls[idx] || ""}
                      onChange={(e) => {
                        const newUrls = [...formData.competitorUrls];
                        if (e.target.value) {
                          newUrls[idx] = e.target.value;
                        } else {
                          newUrls.splice(idx, 1);
                        }
                        setFormData({ ...formData, competitorUrls: newUrls.filter(Boolean) });
                      }}
                      data-testid={`input-competitor-${idx}`}
                    />
                  </div>
                ))}
              </div>
            )}

            {step === 3 && (
              <>
                <div className="space-y-2">
                  <Label>SERP Feature Target</Label>
                  <Select
                    value={formData.serpFeatureTarget}
                    onValueChange={(value: string) => setFormData({ ...formData, serpFeatureTarget: value })}
                  >
                    <SelectTrigger data-testid="select-serp-feature-wizard">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="Featured Snippet">Featured Snippet</SelectItem>
                      <SelectItem value="PAA">People Also Ask</SelectItem>
                      <SelectItem value="List">List/Carousel</SelectItem>
                      <SelectItem value="Q&A">Q&A Schema</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Geographic Focus *</Label>
                  <Input
                    placeholder="e.g., Boston, Massachusetts or Seattle, Washington"
                    value={formData.geographicFocus}
                    onChange={(e) => setFormData({ ...formData, geographicFocus: e.target.value })}
                    data-testid="input-geo-focus-wizard"
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    REQUIRED: All titles will include this location for local SEO.
                  </p>
                </div>
                <div className="space-y-2">
                  <Label>Content Tone</Label>
                  <Select
                    value={formData.tone}
                    onValueChange={(value: string) => setFormData({ ...formData, tone: value })}
                  >
                    <SelectTrigger data-testid="select-tone-wizard">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="casual">Casual</SelectItem>
                      <SelectItem value="technical">Technical</SelectItem>
                      <SelectItem value="persuasive">Persuasive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {step === 4 && (
              <div className="space-y-4">
                <h3 className="font-semibold">Review Your Configuration</h3>
                <div className="grid gap-3 p-4 bg-muted rounded-lg">
                  <div>
                    <span className="text-sm font-medium">Topic:</span>
                    <p className="text-sm text-muted-foreground">{formData.coreTopic}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium">Competitor URLs:</span>
                    <p className="text-sm text-muted-foreground">
                      {formData.competitorUrls.length} URL(s)
                    </p>
                  </div>
                  <div>
                    <span className="text-sm font-medium">SERP Target:</span>
                    <Badge>{formData.serpFeatureTarget}</Badge>
                  </div>
                  {formData.geographicFocus && (
                    <div>
                      <span className="text-sm font-medium">Geographic Focus:</span>
                      <p className="text-sm text-muted-foreground">{formData.geographicFocus}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 1}
            data-testid="button-back"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          {step < 4 ? (
            <Button onClick={handleNext} data-testid="button-next">
              Next
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button onClick={handleGenerate} data-testid="button-generate">
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Content
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
