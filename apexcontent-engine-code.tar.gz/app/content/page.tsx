"use client";

import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Loader2, ExternalLink, Trash2, Home, RefreshCw } from "lucide-react";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Batch {
  id: number;
  coreTopic: string;
  status: string;
  numArticlesRequested: number;
  createdAt: string;
}

export default function ContentLibrary() {
  const { toast } = useToast();
  
  const { data: batches, isLoading, refetch, isFetching } = useQuery<Batch[]>({
    queryKey: ["/api/batches"],
  });

  const handleRefresh = async () => {
    await refetch();
    toast({
      title: "Refreshed",
      description: "Article list updated with latest statuses",
    });
  };

  const deleteBatchMutation = useMutation({
    mutationFn: async (batchId: number) => {
      return await apiRequest(`/api/batches/${batchId}`, {
        method: "DELETE",
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/batches"] });
      toast({
        title: "Batch deleted",
        description: `Batch and ${data.deletedArticlesCount} articles permanently removed from the system.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Delete failed",
        description: error instanceof Error ? error.message : "Failed to delete batch",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const hasBatches = batches && batches.length > 0;

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2" data-testid="text-page-title">Content Library</h1>
            <p className="text-muted-foreground" data-testid="text-page-description">
              Browse and export your generated articles
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={handleRefresh}
              disabled={isFetching}
              data-testid="button-refresh"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Link href="/home">
              <Button variant="default" className="bg-primary hover:bg-primary/90" data-testid="button-home">
                <Home className="w-4 h-4 mr-2" />
                Home
              </Button>
            </Link>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Generated Articles
            </CardTitle>
            <CardDescription>
              View all completed and in-progress content
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!hasBatches ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No articles yet</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Generate your first batch of articles from the dashboard
                </p>
                <Link href="/dashboard">
                  <Button data-testid="button-goto-dashboard">
                    Go to Dashboard
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {batches.map((batch) => (
                  <div
                    key={batch.id}
                    className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                    data-testid={`batch-item-${batch.id}`}
                  >
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">{batch.coreTopic}</h3>
                      <p className="text-sm text-muted-foreground">
                        {batch.numArticlesRequested} articles • Created {new Date(batch.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={batch.status === "COMPLETE" ? "default" : "secondary"}>
                        {batch.status}
                      </Badge>
                      <Link href={`/batches/${batch.id}`}>
                        <Button variant="outline" size="sm" data-testid={`button-view-batch-${batch.id}`}>
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View
                        </Button>
                      </Link>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="destructive"
                            size="sm"
                            data-testid={`button-delete-batch-${batch.id}`}
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Batch
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Batch and All Articles?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete this batch and all {batch.numArticlesRequested} associated articles from the system. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel data-testid={`button-cancel-delete-batch-${batch.id}`}>
                              Cancel
                            </AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteBatchMutation.mutate(batch.id)}
                              disabled={deleteBatchMutation.isPending}
                              data-testid={`button-confirm-delete-batch-${batch.id}`}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              {deleteBatchMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                              Delete Permanently
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
