"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Pin,
  ArrowLeft,
  Copy,
  Download,
  Edit,
  Edit2,
  Trash2,
  Calendar,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  MapPin,
  Briefcase,
  MessageSquare,
  Video,
  Loader2 as LoaderIcon,
  Play,
  Upload,
  X,
  Image as ImageIcon,
  RefreshCw,
  Share2,
  ExternalLink,
} from "lucide-react";
import Link from "next/link";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface SocialPostVariant {
  id: number;
  socialPostId: number;
  platform: string;
  variantIndex: number;
  caption: string;
  characterCount: number;
  hashtags: string;
  hashtagsJson: string[];
  emojisJson?: string[];
  imageUrl: string | null;
  status: string;
  errorMessage: string | null;
  createdAt: string;
}

interface SocialPostDetail {
  id: number;
  userId: number;
  articleId: number | null;
  topic: string;
  title: string;
  location: string;
  tone: string;
  mood: string | null;
  industry: string | null;
  landingPageUrl: string | null;
  userEmail: string | null;
  companyName: string | null;
  companyLogoUrl: string | null;
  videoUrl: string | null;
  videoStatus: string | null;
  videoProgress: number | null;
  videoStage: string | null;
  videoDuration: number | null;
  platformsJson: string[];
  status: string;
  scheduleAt: string | null;
  publishedAt: string | null;
  createdAt: string;
  updatedAt: string;
  variants: SocialPostVariant[];
}

export default function SocialPostDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [editLogoFile, setEditLogoFile] = useState<File | null>(null);
  const [editLogoPreview, setEditLogoPreview] = useState<string>("");
  const [logoUploading, setLogoUploading] = useState(false);
  const [editFormData, setEditFormData] = useState({
    title: "",
    topic: "",
    companyName: "",
    location: "",
    tone: "",
    mood: "",
    industry: "",
  });
  const [regeneratingVariantId, setRegeneratingVariantId] = useState<number | null>(null);

  const postId = params.id as string;

  const { data: post, isLoading } = useQuery<SocialPostDetail>({
    queryKey: [`/api/social_posts/${postId}`],
    enabled: !!postId,
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest(`/api/social_posts/${postId}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      toast({
        title: "Deleted",
        description: "Social post has been deleted",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/social_posts'] });
      router.push("/social/dashboard");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete post",
        variant: "destructive",
      });
    },
  });

  const scheduleMutation = useMutation({
    mutationFn: async (scheduleData: { scheduleAt: string }) => {
      await apiRequest(`/api/social_posts/${postId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(scheduleData),
      });
    },
    onSuccess: () => {
      toast({
        title: "Scheduled",
        description: "Post has been scheduled successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/social_posts/${postId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/social_posts'] });
      setScheduleDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to schedule post",
        variant: "destructive",
      });
    },
  });

  const handleEditLogoUpload = async (file: File): Promise<string> => {
    setLogoUploading(true);
    try {
      const formData = new FormData();
      formData.append("logo", file);
      
      const response = await fetch("/api/upload/logo", {
        method: "POST",
        body: formData,
      });
      
      if (!response.ok) {
        // Try to parse JSON error, fallback to generic message if HTML returned
        let errorMessage = "Failed to upload logo";
        try {
          const error = await response.json();
          errorMessage = error.error || error.message || errorMessage;
        } catch {
          // Server returned HTML (404 or 500), use status-based message
          errorMessage = `Server error (${response.status}): ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      return data.url;
    } finally {
      setLogoUploading(false);
    }
  };

  const handleEditLogoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type - explicitly allow only PNG, JPG, JPEG, WebP
    const allowedTypes = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
    if (!allowedTypes.includes(file.type.toLowerCase())) {
      toast({
        title: "Invalid file type",
        description: "Please select PNG, JPG, or WebP image",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Logo must be less than 5MB",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setEditLogoPreview(reader.result as string);
    };
    reader.readAsDataURL(file);

    setEditLogoFile(file);
  };

  const removeEditLogoFile = () => {
    setEditLogoFile(null);
    setEditLogoPreview("");
  };

  const updateMutation = useMutation({
    mutationFn: async (updateData: typeof editFormData) => {
      // Upload logo if new file is selected
      let updatedData: any = { ...updateData };
      if (editLogoFile) {
        try {
          const logoUrl = await handleEditLogoUpload(editLogoFile);
          updatedData.companyLogoUrl = logoUrl;
        } catch (error: any) {
          throw new Error(`Logo upload failed: ${error.message}`);
        }
      }

      await apiRequest(`/api/social_posts/${postId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData),
      });
    },
    onSuccess: async () => {
      toast({
        title: "Updated",
        description: "Post has been updated successfully",
      });
      // Force refetch to immediately update the UI
      await queryClient.refetchQueries({ queryKey: [`/api/social_posts/${postId}`] });
      await queryClient.invalidateQueries({ queryKey: ['/api/social_posts'] });
      setEditDialogOpen(false);
      setEditLogoFile(null);
      setEditLogoPreview("");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update post",
        variant: "destructive",
      });
    },
  });

  const regenerateVariantMutation = useMutation({
    mutationFn: async (variantId: number) => {
      const response = await apiRequest(`/api/social-posts/variants/${variantId}/regenerate`, {
        method: "POST",
      });
      return { variantId, response };
    },
    onSuccess: ({ variantId, response }) => {
      // Optimistically update the query cache with the new variant data
      // Use functional updater to avoid clobbering concurrent updates
      queryClient.setQueryData<SocialPostDetail>(
        [`/api/social_posts/${postId}`], 
        (prev) => {
          if (!prev || !response.variant) return prev;
          
          return {
            ...prev,
            variants: prev.variants.map(v => 
              v.id === variantId 
                ? { 
                    ...v, 
                    caption: response.variant.caption,
                    hashtags: response.variant.hashtags.map((h: any) => h.tag).join(' '),
                    hashtagsJson: response.variant.hashtags,
                    emojisJson: response.variant.emojis || [],
                    hyperlinksJson: response.variant.hyperlinks || [],
                    characterCount: response.variant.characterCount,
                    status: response.variant.status,
                    errorMessage: null,
                  }
                : v
            ),
          };
        }
      );
      
      // Also invalidate to fetch fresh data
      queryClient.invalidateQueries({ queryKey: [`/api/social_posts/${postId}`] });
      
      // Get platform from cached data safely
      const updatedPost = queryClient.getQueryData<SocialPostDetail>([`/api/social_posts/${postId}`]);
      const variant = updatedPost?.variants.find(v => v.id === variantId);
      const platform = variant?.platform || 'variant';
      
      toast({
        title: "Regenerated successfully ✓",
        description: `${platform.charAt(0).toUpperCase() + platform.slice(1)} content has been regenerated.`,
      });
      
      setRegeneratingVariantId(null);
    },
    onError: (error: any, variantId) => {
      const variant = post?.variants.find(v => v.id === variantId);
      const platform = variant?.platform || 'variant';
      
      toast({
        title: `${platform.charAt(0).toUpperCase() + platform.slice(1)} regeneration failed`,
        description: error instanceof Error ? error.message : "An error occurred during regeneration",
        variant: "destructive",
      });
      
      console.error(`Failed to regenerate variant ${variantId}:`, error);
      setRegeneratingVariantId(null);
    },
  });

  const generateVideoMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("/api/social/video/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          socialPostId: parseInt(postId),
          platform: "tiktok", // Default platform for video
        }),
      });
      return response;
    },
    onSuccess: (data: any) => {
      toast({
        title: "Video generation started",
        description: "Your 60-second video is being generated. This will take 2-3 minutes.",
      });
      
      // CRITICAL: Optimistic cache update to fix double-click issue
      queryClient.setQueryData<SocialPostDetail>([`/api/social_posts/${postId}`], (old) => {
        if (!old) return old;
        return {
          ...old,
          videoStatus: data.videoStatus || "GENERATING",
          videoProgress: data.videoProgress || 0,
          videoStage: data.videoStage || "queued",
        };
      });
      
      // Also invalidate to ensure we get fresh data
      queryClient.invalidateQueries({ queryKey: [`/api/social_posts/${postId}`] });
    },
    onError: (error: Error) => {
      toast({
        title: "Video generation failed",
        description: error.message || "Failed to start video generation",
        variant: "destructive",
      });
    },
  });

  // Poll for video generation status (tighter polling when generating)
  useEffect(() => {
    if (!post || !post.videoStatus) return;
    
    if (post.videoStatus === "GENERATING") {
      const pollInterval = setInterval(() => {
        queryClient.invalidateQueries({ queryKey: [`/api/social_posts/${postId}`] });
      }, 2000); // Poll every 2 seconds for real-time progress updates

      return () => clearInterval(pollInterval);
    }
  }, [post?.videoStatus, postId]);

  const platformIcon = (platform: string, className = "w-4 h-4") => {
    switch (platform.toLowerCase()) {
      case 'x':
      case 'twitter':
        return <Twitter className={className} />;
      case 'facebook':
        return <Facebook className={className} />;
      case 'instagram':
        return <Instagram className={className} />;
      case 'linkedin':
        return <Linkedin className={className} />;
      case 'pinterest':
        return <Pin className={className} />;
      default:
        return <MessageSquare className={className} />;
    }
  };

  const statusIcon = (status: string | null | undefined) => {
    if (!status) {
      return <AlertCircle className="w-4 h-4 text-gray-400" />;
    }
    switch (status.toLowerCase()) {
      case 'published':
      case 'ready':
        return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'scheduled':
        return <Clock className="w-4 h-4 text-blue-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'generating':
        return <Clock className="w-4 h-4 text-yellow-500 animate-spin" />;
      default:
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: `${label} copied to clipboard`,
    });
  };

  // Generate platform-specific share URLs
  const generateShareUrl = (platform: string, caption: string, hashtags: string, landingPageUrl?: string) => {
    const fullText = `${caption}\n\n${hashtags}`.trim();
    const encodedText = encodeURIComponent(fullText);
    const encodedUrl = landingPageUrl ? encodeURIComponent(landingPageUrl) : '';
    
    const normalizedPlatform = platform.toLowerCase();
    
    switch (normalizedPlatform) {
      case 'twitter':
      case 'x':
        // Twitter/X web intent (max 280 chars)
        return `https://twitter.com/intent/tweet?text=${encodedText}${landingPageUrl ? `&url=${encodedUrl}` : ''}`;
      
      case 'facebook':
        // Facebook sharer
        if (landingPageUrl) {
          return `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`;
        }
        return `https://www.facebook.com/sharer/sharer.php?quote=${encodedText}`;
      
      case 'linkedin':
        // LinkedIn share (opens share dialog)
        if (landingPageUrl) {
          return `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`;
        }
        // For LinkedIn without URL, we'll copy to clipboard instead
        return null;
      
      case 'pinterest':
        // Pinterest pin creation
        if (landingPageUrl) {
          return `https://pinterest.com/pin/create/button/?url=${encodedUrl}&description=${encodedText}`;
        }
        return null;
      
      case 'instagram':
        // Instagram doesn't support web posting - copy to clipboard only
        return null;
      
      default:
        return null;
    }
  };

  const handleQuickShare = (platform: string, caption: string, hashtags: string) => {
    const shareUrl = generateShareUrl(platform, caption, hashtags, post?.landingPageUrl || undefined);
    
    if (shareUrl) {
      // Open platform's sharing page in new tab
      window.open(shareUrl, '_blank', 'noopener,noreferrer,width=600,height=700');
      toast({
        title: "Opening share dialog",
        description: `Opening ${platform} to share your post`,
      });
    } else {
      // For Instagram and platforms without web sharing, copy to clipboard
      const fullText = `${caption}\n\n${hashtags}`.trim();
      copyToClipboard(fullText, "Post content");
      toast({
        title: "Content copied",
        description: `Open ${platform} app and paste your content`,
      });
    }
  };

  const handleSchedule = () => {
    if (!scheduleDate || !scheduleTime) {
      toast({
        title: "Error",
        description: "Please select both date and time",
        variant: "destructive",
      });
      return;
    }

    const scheduleAt = new Date(`${scheduleDate}T${scheduleTime}`).toISOString();
    scheduleMutation.mutate({ scheduleAt });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto p-6">
          <div className="text-center py-16">
            <div className="text-lg text-muted-foreground">Loading post details...</div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto p-6">
          <div className="text-center py-16">
            <div className="text-lg text-muted-foreground mb-4">Post not found</div>
            <Link href="/social/dashboard">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/social/dashboard">
              <Button variant="outline" size="icon" data-testid="button-back">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold" data-testid="text-post-title">
                {post.title}
              </h1>
              <div className="flex items-center gap-2 mt-1">
                {statusIcon(post.status)}
                <Badge variant="outline" data-testid="badge-post-status">
                  {post.status}
                </Badge>
                {post.scheduleAt && (
                  <span className="text-sm text-muted-foreground">
                    Scheduled for {format(new Date(post.scheduleAt), "PPp")}
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => {
              if (post) {
                setEditFormData({
                  title: post.title || "",
                  topic: post.topic || "",
                  companyName: post.companyName || "",
                  location: post.location || "",
                  tone: post.tone || "",
                  mood: post.mood || "",
                  industry: post.industry || "",
                });
                setEditDialogOpen(true);
              }
            }} data-testid="button-edit">
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
            <Button variant="outline" onClick={() => setScheduleDialogOpen(true)} data-testid="button-schedule">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule
            </Button>
            <Button variant="destructive" onClick={() => setDeleteDialogOpen(true)} data-testid="button-delete">
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </Button>
          </div>
        </div>

        {/* Post Overview */}
        <Card data-testid="card-overview">
          <CardHeader>
            <CardTitle>Post Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Topic</Label>
                <p className="text-base" data-testid="text-topic">{post.topic}</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Location</Label>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <p className="text-base" data-testid="text-location">{post.location}</p>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium text-muted-foreground">Tone</Label>
                <p className="text-base" data-testid="text-tone">{post.tone}</p>
              </div>
              {post.mood && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Mood</Label>
                  <p className="text-base" data-testid="text-mood">{post.mood}</p>
                </div>
              )}
              {post.industry && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Industry</Label>
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-muted-foreground" />
                    <p className="text-base" data-testid="text-industry">{post.industry}</p>
                  </div>
                </div>
              )}
              {post.companyName && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Company Name</Label>
                  <p className="text-base" data-testid="text-company-name">{post.companyName}</p>
                </div>
              )}
              {post.landingPageUrl && (
                <div>
                  <Label className="text-sm font-medium text-muted-foreground">Landing Page</Label>
                  <a href={post.landingPageUrl} target="_blank" rel="noopener noreferrer" className="text-base text-primary hover:underline" data-testid="link-landing-page">
                    {post.landingPageUrl}
                  </a>
                </div>
              )}
            </div>
            <Separator />
            <div>
              <Label className="text-sm font-medium text-muted-foreground mb-2 block">Platforms</Label>
              <div className="flex flex-wrap gap-2">
                {post.platformsJson && Array.isArray(post.platformsJson) ? (
                  post.platformsJson.map((platform) => (
                    <Badge key={platform} variant="secondary" data-testid={`badge-platform-${platform}`}>
                      {platform}
                    </Badge>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No platforms selected</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 60-Second Video */}
        <Card data-testid="card-video">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Video className="w-5 h-5 text-primary" />
                <CardTitle>60-Second Video</CardTitle>
              </div>
              {post.videoStatus && (
                <Badge variant={post.videoStatus === "READY" ? "default" : post.videoStatus === "FAILED" ? "destructive" : "secondary"}>
                  {post.videoStatus}
                </Badge>
              )}
            </div>
            <CardDescription>
              AI-generated 60-second video with images, voiceover, and company branding
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!post.videoUrl && !post.videoStatus && (
              <div className="text-center py-8 space-y-4">
                <Video className="w-16 h-16 mx-auto text-muted-foreground" />
                <div>
                  <p className="text-lg font-medium mb-2">No video generated yet</p>
                  <p className="text-sm text-muted-foreground mb-4">
                    {!post.companyName 
                      ? "Company name is required to generate videos. Please edit this post to add your company name."
                      : "Generate a professional 60-second video with AI-powered voiceover, images, and branding"}
                  </p>
                  {!post.companyName ? (
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        disabled
                        className="opacity-50 cursor-not-allowed"
                        data-testid="button-generate-video-disabled"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Generate 60-Second Video
                      </Button>
                      <div className="flex flex-col items-center gap-2">
                        <p className="text-xs text-destructive">
                          ⚠️ Company name required for video generation
                        </p>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => {
                            setEditFormData({
                              title: post.title || "",
                              topic: post.topic || "",
                              companyName: post.companyName || "",
                              location: post.location || "",
                              tone: post.tone || "",
                              mood: post.mood || "",
                              industry: post.industry || "",
                            });
                            setEditDialogOpen(true);
                          }}
                          data-testid="button-edit-to-add-company"
                        >
                          <Edit2 className="w-3 h-3 mr-2" />
                          Add Company Name
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      onClick={() => generateVideoMutation.mutate()}
                      disabled={generateVideoMutation.isPending}
                      data-testid="button-generate-video"
                    >
                      {generateVideoMutation.isPending ? (
                        <>
                          <LoaderIcon className="w-4 h-4 mr-2 animate-spin" />
                          Starting Generation...
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Generate 60-Second Video
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
            )}

            {post.videoStatus === "GENERATING" && (
              <div className="text-center py-8 space-y-4">
                <LoaderIcon className="w-16 h-16 mx-auto text-primary animate-spin" />
                <div>
                  <p className="text-lg font-medium mb-2">Generating your video...</p>
                  <p className="text-sm text-muted-foreground mb-4">
                    {post.videoStage === "queued" && "Initializing video generation..."}
                    {post.videoStage === "script_complete" && "✍️ Video script written"}
                    {post.videoStage === "parallel_generation" && "🚀 Creating images and voiceover in parallel..."}
                    {post.videoStage === "assets_complete" && "🎬 Assets ready, composing video..."}
                    {post.videoStage === "composition_complete" && "✨ Finalizing your video..."}
                    {!post.videoStage && "Processing..."}
                  </p>
                  
                  {/* Progress Bar */}
                  <div className="max-w-md mx-auto">
                    <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                      <div 
                        className="bg-primary h-full transition-all duration-500 ease-out"
                        style={{ width: `${post.videoProgress || 0}%` }}
                        data-testid="video-progress-bar"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground mt-2" data-testid="video-progress-text">
                      {post.videoProgress || 0}% complete
                    </p>
                  </div>
                  
                  <p className="text-xs text-muted-foreground mt-4">
                    This process takes 2-3 minutes. The page updates automatically.
                  </p>
                </div>
              </div>
            )}

            {post.videoStatus === "FAILED" && (
              <div className="text-center py-8 space-y-4">
                <XCircle className="w-16 h-16 mx-auto text-destructive" />
                <div>
                  <p className="text-lg font-medium mb-2">Video generation failed</p>
                  <p className="text-sm text-muted-foreground mb-4">
                    Something went wrong. Please try again.
                  </p>
                  <Button
                    onClick={() => generateVideoMutation.mutate()}
                    disabled={generateVideoMutation.isPending}
                    variant="outline"
                    data-testid="button-retry-video"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Retry Generation
                  </Button>
                </div>
              </div>
            )}

            {post.videoUrl && post.videoStatus === "READY" && (
              <div className="space-y-4">
                <div className="relative aspect-video rounded-lg overflow-hidden bg-black">
                  <video
                    src={post.videoUrl}
                    controls
                    className="w-full h-full"
                    data-testid="video-player"
                  >
                    Your browser does not support the video tag.
                  </video>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    {post.videoDuration && (
                      <span>Duration: {post.videoDuration}s</span>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = post.videoUrl!;
                        link.download = `social-video-${post.id}.mp4`;
                        link.click();
                      }}
                      data-testid="button-download-video"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Video
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => generateVideoMutation.mutate()}
                      disabled={generateVideoMutation.isPending}
                      data-testid="button-regenerate-video"
                    >
                      {generateVideoMutation.isPending ? (
                        <>
                          <LoaderIcon className="w-4 h-4 mr-2 animate-spin" />
                          Regenerating...
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Regenerate
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {post.companyName && (
                  <div className="text-sm text-muted-foreground">
                    Branded with: {post.companyName}
                    {post.companyLogoUrl && " (with logo)"}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Platform Variants */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Platform Content ({post.variants?.length || 0})</h2>
          {!post.variants || post.variants.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                No content generated yet for this post
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {post.variants.map((variant) => (
                <Card key={variant.id} data-testid={`variant-card-${variant.id}`} className="hover-elevate">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {platformIcon(variant.platform)}
                        <CardTitle className="text-lg capitalize">{variant.platform}</CardTitle>
                      </div>
                      <div className="flex items-center gap-2">
                        {statusIcon(variant.status)}
                        <Badge variant="outline" data-testid={`variant-status-${variant.id}`}>
                          {variant.status}
                        </Badge>
                      </div>
                    </div>
                    {variant.errorMessage && (
                      <CardDescription className="text-red-500" data-testid={`variant-error-${variant.id}`}>
                        Error: {variant.errorMessage}
                      </CardDescription>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Image */}
                    {variant.imageUrl && (
                      <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                        <img
                          src={variant.imageUrl}
                          alt={`${variant.platform} image`}
                          className="w-full h-full object-cover"
                          data-testid={`variant-image-${variant.id}`}
                        />
                      </div>
                    )}

                    {/* Caption */}
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <Label className="text-sm font-medium">Caption</Label>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(variant.caption, "Caption")}
                          data-testid={`button-copy-caption-${variant.id}`}
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                      <p className="text-sm whitespace-pre-wrap border rounded-lg p-3 bg-muted" data-testid={`variant-caption-${variant.id}`}>
                        {variant.caption}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {variant.characterCount} characters
                      </p>
                    </div>

                    {/* Hashtags */}
                    {variant.hashtagsJson && variant.hashtagsJson.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-sm font-medium">Hashtags</Label>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(variant.hashtags || variant.hashtagsJson.join(' '), "Hashtags")}
                            data-testid={`button-copy-hashtags-${variant.id}`}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {variant.hashtagsJson.map((tag, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {typeof tag === 'string' ? tag : tag.tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Emojis */}
                    {variant.emojisJson && variant.emojisJson.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-sm font-medium">Emojis</Label>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(variant.emojisJson?.join(' ') || '', "Emojis")}
                            data-testid={`button-copy-emojis-${variant.id}`}
                          >
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {variant.emojisJson.map((emoji, idx) => (
                            <Badge key={idx} variant="secondary" className="text-xs">
                              {emoji}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Variant Actions */}
                    <div className="flex flex-col gap-3">
                      {/* Quick Share Button */}
                      <Button
                        variant="default"
                        className="w-full"
                        onClick={() => handleQuickShare(
                          variant.platform,
                          variant.caption,
                          variant.hashtags || variant.hashtagsJson?.join(' ') || ''
                        )}
                        disabled={variant.status !== "READY"}
                        data-testid={`button-quick-share-${variant.id}`}
                      >
                        {['instagram'].includes(variant.platform.toLowerCase()) ? (
                          <>
                            <Copy className="w-4 h-4 mr-2" />
                            Copy & Open {variant.platform}
                          </>
                        ) : (
                          <>
                            <Share2 className="w-4 h-4 mr-2" />
                            Quick Share to {variant.platform}
                          </>
                        )}
                      </Button>
                      
                      {/* Secondary Actions */}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          className="flex-1"
                          onClick={() => {
                            setRegeneratingVariantId(variant.id);
                            regenerateVariantMutation.mutate(variant.id);
                          }}
                          disabled={regeneratingVariantId === variant.id || variant.status === "GENERATING"}
                          data-testid={`button-regenerate-variant-${variant.id}`}
                        >
                          {regeneratingVariantId === variant.id ? (
                            <>
                              <LoaderIcon className="w-4 h-4 mr-2 animate-spin" />
                              Regenerating...
                            </>
                          ) : (
                            <>
                              <RefreshCw className="w-4 h-4 mr-2" />
                              Regenerate
                            </>
                          )}
                        </Button>
                        {variant.imageUrl && (
                          <Button
                            variant="outline"
                            onClick={() => {
                              const link = document.createElement('a');
                              link.href = variant.imageUrl!;
                              link.download = `${variant.platform}-${variant.id}.png`;
                              link.click();
                            }}
                            data-testid={`button-download-image-${variant.id}`}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Post?</DialogTitle>
              <DialogDescription>
                This will permanently delete this social media post and all its platform variants. This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} data-testid="button-cancel-delete">
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={() => {
                  deleteMutation.mutate();
                  setDeleteDialogOpen(false);
                }}
                disabled={deleteMutation.isPending}
                data-testid="button-confirm-delete"
              >
                {deleteMutation.isPending ? "Deleting..." : "Delete"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Schedule Dialog */}
        <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Schedule Post</DialogTitle>
              <DialogDescription>
                Choose when you want to publish this post to your social media accounts.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="schedule-date">Date</Label>
                <Input
                  id="schedule-date"
                  type="date"
                  value={scheduleDate}
                  onChange={(e) => setScheduleDate(e.target.value)}
                  data-testid="input-schedule-date"
                />
              </div>
              <div>
                <Label htmlFor="schedule-time">Time</Label>
                <Input
                  id="schedule-time"
                  type="time"
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  data-testid="input-schedule-time"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setScheduleDialogOpen(false)} data-testid="button-cancel-schedule">
                Cancel
              </Button>
              <Button
                onClick={handleSchedule}
                disabled={scheduleMutation.isPending || !scheduleDate || !scheduleTime}
                data-testid="button-confirm-schedule"
              >
                {scheduleMutation.isPending ? "Scheduling..." : "Schedule"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Edit Post Details</DialogTitle>
              <DialogDescription>
                Update the post information. Note: This will not regenerate existing content.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="edit-title">Title</Label>
                <Input
                  id="edit-title"
                  value={editFormData.title}
                  onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                  data-testid="input-edit-title"
                />
              </div>
              <div>
                <Label htmlFor="edit-topic">Topic</Label>
                <Input
                  id="edit-topic"
                  value={editFormData.topic}
                  onChange={(e) => setEditFormData({ ...editFormData, topic: e.target.value })}
                  data-testid="input-edit-topic"
                />
              </div>
              <div>
                <Label htmlFor="edit-company">Company Name *</Label>
                <Input
                  id="edit-company"
                  value={editFormData.companyName}
                  onChange={(e) => setEditFormData({ ...editFormData, companyName: e.target.value })}
                  placeholder="Required for video generation"
                  data-testid="input-edit-company"
                />
              </div>
              <div>
                <Label htmlFor="edit-location">Location *</Label>
                <Input
                  id="edit-location"
                  value={editFormData.location}
                  onChange={(e) => setEditFormData({ ...editFormData, location: e.target.value })}
                  placeholder="e.g., San Francisco, CA"
                  data-testid="input-edit-location"
                />
              </div>
              <div>
                <Label htmlFor="edit-industry">Industry</Label>
                <Input
                  id="edit-industry"
                  value={editFormData.industry}
                  onChange={(e) => setEditFormData({ ...editFormData, industry: e.target.value })}
                  data-testid="input-edit-industry"
                />
              </div>
              <div>
                <Label>Company Logo (Optional)</Label>
                <div className="space-y-3 mt-2">
                  {!editLogoPreview && !post?.companyLogoUrl && (
                    <div className="flex items-center gap-2">
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleEditLogoSelect}
                        disabled={logoUploading}
                        data-testid="input-edit-logo-upload"
                        className="flex-1"
                      />
                      {logoUploading && <LoaderIcon className="w-4 h-4 animate-spin" />}
                    </div>
                  )}
                  
                  {(editLogoPreview || post?.companyLogoUrl) && (
                    <div className="relative inline-block">
                      <div className="w-32 h-32 border-2 border-dashed border-border rounded-lg overflow-hidden bg-muted flex items-center justify-center">
                        <img 
                          src={editLogoPreview || post?.companyLogoUrl || ""} 
                          alt="Logo preview" 
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
                        onClick={removeEditLogoFile}
                        data-testid="button-remove-edit-logo"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                  
                  <p className="text-sm text-muted-foreground">
                    Upload your company logo for video branding (PNG/JPG, max 5MB)
                  </p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialogOpen(false)} data-testid="button-cancel-edit">
                Cancel
              </Button>
              <Button
                onClick={() => updateMutation.mutate(editFormData)}
                disabled={updateMutation.isPending || !editFormData.location}
                data-testid="button-save-edit"
              >
                {updateMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
