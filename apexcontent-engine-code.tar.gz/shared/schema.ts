import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, serial, jsonb, index, uniqueIndex, uuid } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================================================
// TEAM MANAGEMENT TABLES - Must be defined FIRST for foreign key references
// ============================================================================

// Teams table - organizational units for user isolation
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  createdBy: integer("created_by").notNull().references(() => users.id), // Circular reference handled by Drizzle
  deletedAt: timestamp("deleted_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  publicIdIdx: index("teams_public_id_idx").on(table.publicId),
  nameIdx: index("teams_name_idx").on(table.name),
  createdByIdx: index("teams_created_by_idx").on(table.createdBy),
}));

// Team Members table - join table for user-team relationships
export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  teamId: integer("team_id").notNull().references(() => teams.id, { onDelete: 'cascade' }),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }), // Circular reference handled by Drizzle
  role: varchar("role", { length: 50 }).notNull().default("member"), // member, admin
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
}, (table) => ({
  teamUserUnique: uniqueIndex("team_members_team_user_unique").on(table.teamId, table.userId),
  teamIdIdx: index("team_members_team_id_idx").on(table.teamId),
  userIdIdx: index("team_members_user_id_idx").on(table.userId),
}));

// ============================================================================
// MVP CORE TABLES - Essential for basic content generation pipeline
// ============================================================================

// Users table - authentication and roles with comprehensive security
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash"), // Bcrypt hashed password (nullable for OAuth-only users)
  role: varchar("role", { length: 50 }).notNull().default("team_member"), // team_member, admin
  
  // Account Status & Security
  accountStatus: varchar("account_status", { length: 20 }).notNull().default("active"), // active, locked, suspended
  failedLoginAttempts: integer("failed_login_attempts").notNull().default(0),
  lockedUntil: timestamp("locked_until"),
  
  // 2FA Configuration
  twoFactorEnabled: integer("two_factor_enabled").notNull().default(0), // Boolean as 0/1
  twoFactorMethod: varchar("two_factor_method", { length: 20 }), // email, totp (Google Authenticator)
  emailVerified: integer("email_verified").notNull().default(0), // Boolean as 0/1
  
  // OAuth Integration
  googleId: varchar("google_id", { length: 255 }).unique(), // Google OAuth user ID
  
  // Profile Information
  fullName: varchar("full_name", { length: 255 }),
  profilePictureUrl: text("profile_picture_url"),
  
  // Team Management
  defaultTeamId: integer("default_team_id").references(() => teams.id),
  
  // Soft Delete Support
  deletedAt: timestamp("deleted_at"),
  
  // Timestamps
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  emailIdx: index("users_email_idx").on(table.email),
  googleIdIdx: index("users_google_id_idx").on(table.googleId),
  roleIdx: index("users_role_idx").on(table.role),
  publicIdIdx: index("users_public_id_idx").on(table.publicId),
  defaultTeamIdIdx: index("users_default_team_id_idx").on(table.defaultTeamId),
}));

// Sessions table - tracks active JWT sessions for monitoring and force logout
export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  tokenHash: text("token_hash").notNull().unique(), // SHA-256 hash of JWT for revocation
  ipAddress: varchar("ip_address", { length: 45 }), // IPv4 or IPv6
  userAgent: text("user_agent"), // Browser/device info
  deviceInfo: jsonb("device_info"), // Parsed user agent details
  
  // Session Management
  isActive: integer("is_active").notNull().default(1), // Boolean as 0/1
  expiresAt: timestamp("expires_at").notNull(),
  lastActivityAt: timestamp("last_activity_at").notNull().defaultNow(),
  
  // Team Context (for team-scoped sessions)
  teamContextId: integer("team_context_id").references(() => teams.id),
  
  // Force Logout Support
  forceLogoutAt: timestamp("force_logout_at"), // When session was forcefully terminated
  terminatedBy: integer("terminated_by").references(() => users.id), // Admin who terminated session
  terminationReason: varchar("termination_reason", { length: 255 }), // Reason for termination
  
  // Timestamps
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("sessions_user_id_idx").on(table.userId),
  tokenHashIdx: index("sessions_token_hash_idx").on(table.tokenHash),
  expiresAtIdx: index("sessions_expires_at_idx").on(table.expiresAt),
  isActiveIdx: index("sessions_is_active_idx").on(table.isActive),
  forceLogoutAtIdx: index("sessions_force_logout_at_idx").on(table.forceLogoutAt),
}));

// Activity Logs table - comprehensive audit trail for admin monitoring
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id), // Nullable for system events
  teamId: integer("team_id").references(() => teams.id), // Track team context
  
  // Event Details
  action: varchar("action", { length: 100 }).notNull(), // login, logout, password_change, 2fa_setup, content_generate, etc.
  resource: varchar("resource", { length: 100 }), // users, articles, social_posts, etc.
  resourceId: integer("resource_id"), // ID of affected resource
  
  // Enhanced Tracking (for team-scoped content)
  targetType: varchar("target_type", { length: 50 }), // article, video, social, batch, system
  targetPublicId: varchar("target_public_id", { length: 36 }), // UUID of target resource
  
  // Context Information
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  details: jsonb("details"), // Additional context (old values, new values, error messages)
  
  // Severity for filtering
  severity: varchar("severity", { length: 20 }).notNull().default("info"), // info, warning, error, critical
  
  // Timestamps
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("activity_logs_user_id_idx").on(table.userId),
  teamIdActionIdx: index("activity_logs_team_id_action_idx").on(table.teamId, table.action),
  actionIdx: index("activity_logs_action_idx").on(table.action),
  createdAtIdx: index("activity_logs_created_at_idx").on(table.createdAt),
  severityIdx: index("activity_logs_severity_idx").on(table.severity),
  targetPublicIdIdx: index("activity_logs_target_public_id_idx").on(table.targetPublicId),
}));

// TOTP Secrets table - stores Google Authenticator secrets
export const totpSecrets = pgTable("totp_secrets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id).unique(),
  secret: varchar("secret", { length: 64 }).notNull(), // Base32-encoded TOTP secret
  backupCodes: jsonb("backup_codes"), // Array of one-time backup codes (hashed)
  
  // Timestamps
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastUsedAt: timestamp("last_used_at"),
}, (table) => ({
  userIdIdx: index("totp_secrets_user_id_idx").on(table.userId),
}));

// Email Verification Codes table - stores temporary 2FA codes sent via email
export const emailVerificationCodes = pgTable("email_verification_codes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  code: varchar("code", { length: 6 }).notNull(), // 6-digit code
  purpose: varchar("purpose", { length: 50 }).notNull(), // login_2fa, email_verification, password_reset
  
  // Security
  attempts: integer("attempts").notNull().default(0), // Track verification attempts
  isUsed: integer("is_used").notNull().default(0), // Boolean as 0/1
  expiresAt: timestamp("expires_at").notNull(),
  
  // Timestamps
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("email_codes_user_id_idx").on(table.userId),
  codeIdx: index("email_codes_code_idx").on(table.code),
  expiresAtIdx: index("email_codes_expires_at_idx").on(table.expiresAt),
}));

// Job Batches table - tracks bulk submission jobs
export const jobBatches = pgTable("job_batches", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  userId: integer("user_id").notNull().references(() => users.id),
  teamId: integer("team_id").references(() => teams.id),
  localeId: integer("locale_id").references(() => locales.id), // Geographic location reference
  coreTopic: varchar("core_topic", { length: 255 }).notNull(),
  targetUrl: text("target_url").notNull(),
  status: varchar("status", { length: 50 }).notNull().default("PENDING"), // PENDING, RUNNING, PARTIAL_COMPLETE, COMPLETE, FAILED
  numArticlesRequested: integer("num_articles_requested").notNull(),
  titlePoolJson: jsonb("title_pool_json"), // Stores array of 50 titles
  generationParams: jsonb("generation_params"), // Stores tone, wordCountMin, wordCountMax, geographicFocus, audience
  
  // NAP Data (Name, Address, Phone) for Local SEO
  businessName: varchar("business_name", { length: 255 }), // Business/brand name
  businessAddress: text("business_address"), // Full street address
  businessPhone: varchar("business_phone", { length: 20 }), // E.164 format (+1-415-555-0123)
  
  // Company Branding (for image generation)
  companyLogoUrl: text("company_logo_url"), // Logo uploaded to object storage for AI image reference
  
  // Advanced Features
  competitorUrlsJson: jsonb("competitor_urls_json"), // Array of 1-5 competitor URLs for grounding
  semanticClusterId: integer("semantic_cluster_id"), // Optional linking cluster ID
  serpFeatureTarget: varchar("serp_feature_target", { length: 50 }), // Featured Snippet, PAA, List, Q&A
  
  // Soft Delete Support
  deletedAt: timestamp("deleted_at"),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
}, (table) => ({
  publicIdIdx: index("job_batches_public_id_idx").on(table.publicId),
  teamIdStatusIdx: index("job_batches_team_id_status_idx").on(table.teamId, table.status),
  userIdIdx: index("job_batches_user_id_idx").on(table.userId),
}));

// Articles table - stores final content with all SEO metadata
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  batchId: integer("batch_id").notNull().references(() => jobBatches.id),
  teamId: integer("team_id").references(() => teams.id),
  localeId: integer("locale_id").references(() => locales.id), // Geographic location reference
  articleStatus: varchar("article_status", { length: 50 }).notNull().default("PENDING"), // PENDING, IN_PROGRESS, GEMINI_COMPLETE, CHATGPT_REVIEWED, GPT4_ENHANCED, COMPLETE, FAILED
  chosenTitle: varchar("chosen_title", { length: 255 }).notNull(),
  finalHtmlContent: text("final_html_content"),
  heroImageUrl: text("hero_image_url"), // Primary hero image URL for article display
  seoTitle: varchar("seo_title", { length: 60 }),
  metaDescription: varchar("meta_description", { length: 160 }),
  slug: varchar("slug", { length: 255 }).unique(),
  keywordsJson: jsonb("keywords_json"), // Array of long-phrase keywords
  hashtagsJson: jsonb("hashtags_json"), // Array of hashtags
  faqJson: jsonb("faq_json"), // Array of {question, answer} FAQ items
  imagePromptsJson: jsonb("image_prompts_json"), // Array of 3 DALL-E image generation prompts from Gemini
  wordCount: integer("word_count"),
  
  // Advanced SEO & Geo Features
  geoAccuracyScore: integer("geo_accuracy_score"), // 0-100 score for local relevance
  internalLinkSuggestions: jsonb("internal_link_suggestions"), // Suggested anchors for cluster linking
  
  // ChatGPT Review Layer Enrichment
  seoScore: integer("seo_score"), // 0-100 ChatGPT SEO quality score
  hyperlinkedKeywordsJson: jsonb("hyperlinked_keywords_json"), // 5-10 internal/external keyword links
  metaEnrichment: jsonb("meta_enrichment"), // ChatGPT social snippets, OG tags, schema markup
  
  // AI Podcast Module
  podcastUrl: text("podcast_url"), // Storage URL for generated podcast audio
  podcastDuration: integer("podcast_duration"), // Duration in seconds
  podcastGeneratedAt: timestamp("podcast_generated_at"),
  podcastStatus: varchar("podcast_status", { length: 50 }).default("none"), // none, pending, processing, ready, failed
  podcastScriptJson: jsonb("podcast_script_json"), // Two-voice conversational script
  
  // Soft Delete Support
  deletedAt: timestamp("deleted_at"),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  publicIdIdx: index("articles_public_id_idx").on(table.publicId),
  teamIdStatusIdx: index("articles_team_id_status_idx").on(table.teamId, table.articleStatus),
  batchIdIdx: index("articles_batch_id_idx").on(table.batchId),
  slugIdx: index("articles_slug_idx").on(table.slug),
}));

// Article Assets table - stores image/audio/video metadata
export const articleAssets = pgTable("article_assets", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  articleId: integer("article_id").notNull().references(() => articles.id),
  teamId: integer("team_id").references(() => teams.id),
  assetType: varchar("asset_type", { length: 20 }).notNull().default("image"), // image, audio, video
  imagePromptUsed: text("image_prompt_used"),
  storageUrl: text("storage_url").notNull(),
  altText: varchar("alt_text", { length: 255 }),
  fileFormat: varchar("file_format", { length: 10 }).notNull().default("webp"),
  metadataJson: jsonb("metadata_json"), // video duration, dimensions, audio bitrate
  
  // Soft Delete Support
  deletedAt: timestamp("deleted_at"),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  publicIdIdx: index("article_assets_public_id_idx").on(table.publicId),
  teamIdIdx: index("article_assets_team_id_idx").on(table.teamId),
  articleIdIdx: index("article_assets_article_id_idx").on(table.articleId),
}));

// Job Events table - tracks all job processing events for debugging
export const jobEvents = pgTable("job_events", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").references(() => jobBatches.id),
  articleId: integer("article_id").references(() => articles.id),
  eventType: varchar("event_type", { length: 50 }).notNull(), // TITLE_POOL_START, TITLE_POOL_COMPLETE, ARTICLE_START, STAGE_1, STAGE_2, STAGE_3, ARTICLE_COMPLETE, ARTICLE_FAILED
  stage: varchar("stage", { length: 50 }), // GEMINI, GPT, IMAGES
  message: text("message").notNull(),
  payloadJson: jsonb("payload_json"), // Additional event data (word count, errors, etc)
  durationMs: integer("duration_ms"), // Time taken for this event
  severity: varchar("severity", { length: 20 }).notNull().default("info"), // info, warning, error
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  batchIdIdx: index("job_events_batch_id_idx").on(table.batchId),
  articleIdIdx: index("job_events_article_id_idx").on(table.articleId),
  createdAtIdx: index("job_events_created_at_idx").on(table.createdAt),
  eventTypeIdx: index("job_events_event_type_idx").on(table.eventType),
  severityIdx: index("job_events_severity_idx").on(table.severity),
}));

// ============================================================================
// OPTIONAL GEO TABLE - Can be added later but keeping schema for compatibility
// ============================================================================

// Article Runs table - tracks regeneration attempts with cached outputs
export const articleRuns = pgTable("article_runs", {
  id: serial("id").primaryKey(),
  articleId: integer("article_id").notNull().references(() => articles.id),
  runId: varchar("run_id", { length: 36 }).notNull(), // UUID v4
  runType: varchar("run_type", { length: 50 }).notNull().default("generation"), // generation, regeneration, manual
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  status: varchar("status", { length: 20 }).notNull().default("running"), // running, completed, failed
  cachedGeminiOutput: jsonb("cached_gemini_output"), // Stage 1 output
  cachedChatgptOutput: jsonb("cached_chatgpt_output"), // Stage 2 output  
  cachedGpt4Output: jsonb("cached_gpt4_output"), // Stage 3 output
}, (table) => ({
  // CRITICAL: Unique constraint prevents duplicate runs and enables cache lookup
  articleRunsUnique: uniqueIndex("article_runs_article_id_run_id_unique").on(table.articleId, table.runId),
  articleIdIdx: index("article_runs_article_id_idx").on(table.articleId),
  runIdIdx: index("article_runs_run_id_idx").on(table.runId),
  statusIdx: index("article_runs_status_idx").on(table.status),
}));

// Locales table - geographic locations with coordinates for geo-first features
export const locales = pgTable("locales", {
  id: serial("id").primaryKey(),
  countryCode: varchar("country_code", { length: 2 }).notNull(), // US, CA, UK (ISO 3166-1 alpha-2)
  region: varchar("region", { length: 100 }), // State/Province
  city: varchar("city", { length: 100 }),
  postalCode: varchar("postal_code", { length: 20 }),
  
  // Geocoding coordinates (6 decimal precision ~0.11 meters)
  latitude: varchar("latitude", { length: 20 }), // Decimal degrees format: 37.774929
  longitude: varchar("longitude", { length: 20 }), // Decimal degrees format: -122.419418
  
  // Google Places API metadata
  placeId: varchar("place_id", { length: 255 }).unique(), // Google Places unique ID
  formattedAddress: text("formatted_address"), // Full address from Google
  
  // Additional locale metadata
  language: varchar("language", { length: 10 }).notNull().default("en-US"),
  timezone: varchar("timezone", { length: 50 }), // IANA timezone (e.g., America/Los_Angeles)
  population: integer("population"), // Optional demographic data
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  cityRegionIdx: index("locales_city_region_idx").on(table.city, table.region),
  placeIdIdx: index("locales_place_id_idx").on(table.placeId),
  coordinatesIdx: index("locales_coordinates_idx").on(table.latitude, table.longitude),
}));

// ============================================================================
// BATCH-LEVEL SEO CACHE - Performance Optimization
// Stores reusable SEO context once per batch (30-50% API call reduction)
// ============================================================================

// Batch SEO Cache table - stores reusable analysis per batch
export const batchSeoCache = pgTable("batch_seo_cache", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").notNull().references(() => jobBatches.id).unique(),
  
  // Location Analysis (generated once, reused across all articles)
  locationAnalysisJson: jsonb("location_analysis_json"), // Demographics, landmarks, local culture
  locationKeywordsJson: jsonb("location_keywords_json"), // City-specific keyword variations
  
  // Competitor Research (generated once per batch)
  competitorInsightsJson: jsonb("competitor_insights_json"), // Analyzed competitor patterns
  competitorKeywordsJson: jsonb("competitor_keywords_json"), // Extracted keyword opportunities
  
  // Semantic Clusters (shared topic groupings)
  semanticClustersJson: jsonb("semantic_clusters_json"), // Related topic clusters
  topicalAuthorityJson: jsonb("topical_authority_json"), // Subject matter expertise context
  
  // ENHANCED v2.0: Deep Local Intelligence
  localRegulations: jsonb("local_regulations"), // Local laws, licensing, zoning regulations
  authorityEntities: jsonb("authority_entities"), // Local organizations, experts, landmarks with credibility scores
  keyStatistics: jsonb("key_statistics"), // Statistics with sources and freshness dates
  
  // ENHANCED v3.0: Intent-Based Content Gap Analysis (Reddit Research)
  redditResearch: jsonb("reddit_research"), // Reddit questions, discussions, content gaps, E-E-A-T proof
  
  // ENHANCED v3.1: Expert Discovery for E-E-A-T signals
  expertDiscovery: jsonb("expert_discovery"), // Subject matter experts with credibility scores
  
  // Session Metadata
  cacheVersion: varchar("cache_version", { length: 10 }).notNull().default("3.1"), // Cache schema version (v3.1: Reddit JSON API + Expert Discovery)
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"), // Optional TTL for cache invalidation
}, (table) => ({
  batchIdIdx: index("batch_seo_cache_batch_id_idx").on(table.batchId),
}));

// ============================================================================
// ADVANCED FEATURE TABLES - SEO Logs, Social Posts, Error Tracking, Versioning
// ============================================================================

// SEO Logs table - tracks SEO performance and costs
export const seoLogs = pgTable("seo_logs", {
  id: serial("id").primaryKey(),
  articleId: integer("article_id").notNull().references(() => articles.id),
  tokenCost: integer("token_cost").notNull(), // AI tokens consumed
  geoAccuracyScore: integer("geo_accuracy_score"), // 0-100 score
  schemaValidationFail: integer("schema_validation_fail").notNull().default(0), // Boolean as 0/1
  rankTrackingScore: integer("rank_tracking_score"), // Optional rank improvement metric
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  articleIdIdx: index("seo_logs_article_id_idx").on(table.articleId),
}));

// ============================================================================
// STANDALONE SOCIAL MEDIA MODULE - Phase 10
// Separate from article generation pipeline
// ============================================================================

// Social Posts table - standalone social media post generator (Enhanced for Business)
export const socialPosts = pgTable("social_posts", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  userId: integer("user_id").notNull().references(() => users.id),
  teamId: integer("team_id").references(() => teams.id),
  articleId: integer("article_id").references(() => articles.id), // Optional linking to articles
  
  // Business-Focused User Input
  topic: varchar("topic", { length: 255 }).notNull(), // Main topic of the post
  title: varchar("title", { length: 255 }).notNull(), // Post headline
  location: varchar("location", { length: 255 }).notNull(), // City, neighborhood, landmark for geo-targeting
  prompt: text("prompt"), // Additional content prompt (now optional)
  tone: varchar("tone", { length: 50 }).notNull().default("Professional"), // Professional, Authoritative, Friendly-Professional, Insightful, Executive
  mood: varchar("mood", { length: 50 }), // Motivational, Analytical, Informative, Persuasive, Neutral
  industry: varchar("industry", { length: 100 }), // Logistics, Finance, Healthcare, Retail, Tech, etc.
  landingPageUrl: varchar("landing_page_url", { length: 500 }), // URL for internal hyperlinks in posts
  
  // Company Branding (for video generation)
  companyName: varchar("company_name", { length: 255 }), // Company name to display in video
  companyLogoUrl: text("company_logo_url"), // Logo uploaded to object storage
  
  // Selected Platforms (JSON array: ["x", "facebook", "instagram", "linkedin", "pinterest"])
  platformsJson: jsonb("platforms_json").notNull(),
  numberOfPosts: integer("number_of_posts").notNull().default(3), // Posts per platform
  
  // Generation Settings
  includeImage: integer("include_image").notNull().default(1), // Boolean as 0/1
  includeVideo: integer("include_video").notNull().default(0), // Boolean as 0/1 - Generate 60s video
  imagePreference: varchar("image_preference", { length: 50 }), // hero, platform-specific, none
  autoShare: integer("auto_share").notNull().default(0), // Boolean as 0/1
  userEmail: varchar("user_email", { length: 255 }), // For mailto: hashtag links
  
  // Video Generation (60-second slideshow with voiceover)
  videoUrl: text("video_url"), // Permanent storage URL for generated video
  videoStatus: varchar("video_status", { length: 20 }), // PENDING, GENERATING, READY, FAILED
  videoProgress: integer("video_progress").default(0), // Progress percentage (0-100)
  videoStage: varchar("video_stage", { length: 50 }), // Current stage: queued, script, images, tts, composition, finalize
  videoDuration: integer("video_duration").default(60), // Video duration in seconds (default 60)
  videoScriptJson: jsonb("video_script_json"), // 4-scene script (15s each)
  videoGeneratedAt: timestamp("video_generated_at"), // When video was generated
  
  // SEO & GEO Data
  geoTagsJson: jsonb("geo_tags_json"), // City, neighborhood geo tags
  seoKeywordsJson: jsonb("seo_keywords_json"), // Primary + secondary keywords
  
  // Status Tracking
  status: varchar("status", { length: 50 }).notNull().default("PENDING"), // PENDING, GENERATING, READY, SCHEDULED, POSTED, FAILED
  scheduleAt: timestamp("schedule_at"), // Optional future posting time
  
  // Job Metadata
  jobId: varchar("job_id", { length: 255 }), // pg-boss job ID
  errorMessage: text("error_message"),
  
  // Soft Delete Support
  deletedAt: timestamp("deleted_at"),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  publicIdIdx: index("social_posts_public_id_idx").on(table.publicId),
  teamIdStatusIdx: index("social_posts_team_id_status_idx").on(table.teamId, table.status),
  userIdIdx: index("social_posts_user_id_idx").on(table.userId),
  statusIdx: index("social_posts_status_idx").on(table.status),
  scheduleAtIdx: index("social_posts_schedule_at_idx").on(table.scheduleAt),
}));

// Social Post Variants table - one row per platform with generated content
export const socialPostVariants = pgTable("social_post_variants", {
  id: serial("id").primaryKey(),
  socialPostId: integer("social_post_id").notNull().references(() => socialPosts.id),
  platform: varchar("platform", { length: 20 }).notNull(), // x, facebook, instagram, linkedin, pinterest
  variantIndex: integer("variant_index").notNull().default(1), // Which variant number (1-N)
  
  // Generated Content
  caption: text("caption").notNull(), // AI-generated platform-specific caption
  characterCount: integer("character_count").notNull(),
  hashtags: text("hashtags"), // Space-separated hashtags for easy copy-paste
  hashtagsJson: jsonb("hashtags_json").notNull(), // Array of hashtags with mailto: links
  emojisJson: jsonb("emojis_json"), // Array of emojis used
  hyperlinksJson: jsonb("hyperlinks_json"), // Links embedded in caption
  
  // Platform-Specific Metadata
  characterLimit: integer("character_limit"), // Platform character limit (280 for X, etc.)
  aspectRatio: varchar("aspect_ratio", { length: 10 }), // Image aspect ratio (1:1, 4:5, 16:9)
  imageUrl: text("image_url"), // DALL-E generated image URL (permanent Replit storage)
  platformMetadata: jsonb("platform_metadata"), // Platform-specific fields (Twitter thread ID, IG alt text, etc.)
  
  // Status Tracking
  status: varchar("status", { length: 20 }).notNull().default("PENDING"), // PENDING, GENERATING, READY, FAILED
  errorMessage: text("error_message"), // Error details if status is FAILED
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  socialPostIdIdx: index("social_post_variants_social_post_id_idx").on(table.socialPostId),
  platformIdx: index("social_post_variants_platform_idx").on(table.platform),
  statusIdx: index("social_post_variants_status_idx").on(table.status),
}));

// Social Post Assets table - generated images and videos for social posts
export const socialPostAssets = pgTable("social_post_assets", {
  id: serial("id").primaryKey(),
  socialPostId: integer("social_post_id").notNull().references(() => socialPosts.id),
  variantId: integer("variant_id").references(() => socialPostVariants.id), // Optional: link to specific platform variant
  platform: varchar("platform", { length: 20 }).notNull(), // Platform this asset is optimized for
  
  // Asset Type
  assetType: varchar("asset_type", { length: 10 }).notNull().default("image"), // "image" or "video"
  
  // Common Data
  promptUsed: text("prompt_used").notNull(), // AI prompt used to generate this asset
  storageUrl: text("storage_url").notNull(), // Permanent Replit Object Storage URL
  altText: varchar("alt_text", { length: 255 }), // Accessibility text / description
  aspectRatio: varchar("aspect_ratio", { length: 10 }).notNull(), // "16:9", "1:1", "2:3", "1.91:1", "9:16"
  
  // Image-Specific Data
  width: integer("width"), // Image width in pixels
  height: integer("height"), // Image height in pixels
  fileFormat: varchar("file_format", { length: 10 }).notNull().default("webp"), // webp, mp4, etc.
  
  // Video-Specific Data
  videoDuration: integer("video_duration"), // Video duration in seconds (for videos)
  videoResolution: varchar("video_resolution", { length: 10 }), // "720p", "1080p" (for videos)
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  socialPostIdIdx: index("social_post_assets_social_post_id_idx").on(table.socialPostId),
  platformIdx: index("social_post_assets_platform_idx").on(table.platform),
  assetTypeIdx: index("social_post_assets_asset_type_idx").on(table.assetType),
}));

// Social Post Jobs table - tracks pg-boss job processing
export const socialPostJobs = pgTable("social_post_jobs", {
  id: serial("id").primaryKey(),
  socialPostId: integer("social_post_id").notNull().references(() => socialPosts.id),
  jobId: varchar("job_id", { length: 255 }).notNull().unique(), // pg-boss job ID
  jobType: varchar("job_type", { length: 50 }).notNull(), // GENERATION, SCHEDULING, POSTING
  status: varchar("status", { length: 50 }).notNull(), // PENDING, ACTIVE, COMPLETED, FAILED
  attempt: integer("attempt").notNull().default(1),
  maxAttempts: integer("max_attempts").notNull().default(3),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  socialPostIdIdx: index("social_post_jobs_social_post_id_idx").on(table.socialPostId),
  jobIdIdx: index("social_post_jobs_job_id_idx").on(table.jobId),
  statusIdx: index("social_post_jobs_status_idx").on(table.status),
}));

// Social Post Logs table - audit trail for social post actions
export const socialPostLogs = pgTable("social_post_logs", {
  id: serial("id").primaryKey(),
  socialPostId: integer("social_post_id").notNull().references(() => socialPosts.id),
  eventType: varchar("event_type", { length: 50 }).notNull(), // GENERATION_START, PLATFORM_GENERATED, IMAGE_GENERATED, READY, POSTED, FAILED
  stage: varchar("stage", { length: 50 }), // GEMINI, GPT4, IMAGE_GEN, POSTING
  message: text("message").notNull(),
  payloadJson: jsonb("payload_json"), // Additional event data
  severity: varchar("severity", { length: 20 }).notNull().default("info"), // info, warning, error
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  socialPostIdIdx: index("social_post_logs_social_post_id_idx").on(table.socialPostId),
  eventTypeIdx: index("social_post_logs_event_type_idx").on(table.eventType),
  severityIdx: index("social_post_logs_severity_idx").on(table.severity),
}));

// Error Logs table - system-wide error tracking
export const errorLogs = pgTable("error_logs", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id").references(() => jobBatches.id),
  articleId: integer("article_id").references(() => articles.id),
  errorType: varchar("error_type", { length: 50 }).notNull(), // GEMINI, GPT4, SCHEMA, UPLOAD, QUEUE
  errorMessage: text("error_message").notNull(),
  stackTrace: text("stack_trace"),
  severity: varchar("severity", { length: 20 }).notNull().default("error"), // warning, error, critical
  resolved: integer("resolved").notNull().default(0), // Boolean as 0/1
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  batchIdIdx: index("error_logs_batch_id_idx").on(table.batchId),
  articleIdIdx: index("error_logs_article_id_idx").on(table.articleId),
  errorTypeIdx: index("error_logs_error_type_idx").on(table.errorType),
  resolvedIdx: index("error_logs_resolved_idx").on(table.resolved),
}));

// Admin Action Logs table - audit trail for admin actions
export const adminActionLogs = pgTable("admin_action_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(), // DELETE_BATCH, REQUEUE_JOB, RESOLVE_ERROR, etc.
  targetType: varchar("target_type", { length: 50 }), // BATCH, ARTICLE, ERROR
  targetId: integer("target_id"),
  details: text("details"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("admin_action_logs_user_id_idx").on(table.userId),
  actionIdx: index("admin_action_logs_action_idx").on(table.action),
}));

// Article Versions table - content versioning and rollback
export const articleVersions = pgTable("article_versions", {
  id: serial("id").primaryKey(),
  articleId: integer("article_id").notNull().references(() => articles.id),
  versionNumber: integer("version_number").notNull(),
  finalHtmlContent: text("final_html_content").notNull(),
  seoTitle: varchar("seo_title", { length: 60 }),
  metaDescription: varchar("meta_description", { length: 160 }),
  keywordsJson: jsonb("keywords_json"),
  hashtagsJson: jsonb("hashtags_json"),
  geoAccuracyScore: integer("geo_accuracy_score"),
  wordCount: integer("word_count"),
  changeReason: text("change_reason"), // Why this version was created
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  articleIdIdx: index("article_versions_article_id_idx").on(table.articleId),
}));

// ============================================================================
// ADMIN MANAGEMENT TABLES - Phase 1, 2, 3 Features
// ============================================================================

// User Invites table - invite team members with expiring links
export const userInvites = pgTable("user_invites", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull(),
  invitedBy: integer("invited_by").notNull().references(() => users.id),
  role: varchar("role", { length: 50 }).notNull().default("team_member"), // admin, team_member
  
  // Invite Token
  tokenHash: text("token_hash").notNull().unique(), // SHA-256 hash of invite token
  expiresAt: timestamp("expires_at").notNull(),
  
  // Status Tracking
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, accepted, expired, cancelled
  acceptedAt: timestamp("accepted_at"),
  acceptedBy: integer("accepted_by").references(() => users.id), // Created user ID
  
  // Metadata
  message: text("message"), // Optional personal message from inviter
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  emailIdx: index("user_invites_email_idx").on(table.email),
  tokenHashIdx: index("user_invites_token_hash_idx").on(table.tokenHash),
  statusIdx: index("user_invites_status_idx").on(table.status),
  expiresAtIdx: index("user_invites_expires_at_idx").on(table.expiresAt),
}));

// Login History table - comprehensive login tracking with geo/IP
export const loginHistory = pgTable("login_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id), // Nullable for failed login attempts
  email: varchar("email", { length: 255 }).notNull(), // Store email even for failed attempts
  
  // Login Outcome
  success: integer("success").notNull(), // Boolean as 0/1
  failureReason: varchar("failure_reason", { length: 100 }), // wrong_password, account_locked, 2fa_failed, etc.
  
  // Request Context
  ipAddress: varchar("ip_address", { length: 45 }).notNull(),
  userAgent: text("user_agent"),
  
  // Geo Location (populated asynchronously)
  country: varchar("country", { length: 2 }), // ISO country code
  region: varchar("region", { length: 100 }),
  city: varchar("city", { length: 100 }),
  latitude: varchar("latitude", { length: 20 }),
  longitude: varchar("longitude", { length: 20 }),
  
  // Device Info (parsed from user agent)
  deviceType: varchar("device_type", { length: 20 }), // desktop, mobile, tablet
  browser: varchar("browser", { length: 50 }),
  os: varchar("os", { length: 50 }),
  
  // Session Reference
  sessionId: integer("session_id").references(() => sessions.id),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("login_history_user_id_idx").on(table.userId),
  emailIdx: index("login_history_email_idx").on(table.email),
  successIdx: index("login_history_success_idx").on(table.success),
  ipAddressIdx: index("login_history_ip_address_idx").on(table.ipAddress),
  createdAtIdx: index("login_history_created_at_idx").on(table.createdAt),
}));

// Password Resets table - admin password reset override tracking
export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  initiatedBy: integer("initiated_by").references(() => users.id), // Admin who initiated override
  resetType: varchar("reset_type", { length: 20 }).notNull(), // admin_override, user_request
  
  // Reset Token
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  
  // Status
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, used, expired, cancelled
  usedAt: timestamp("used_at"),
  
  // Context
  ipAddress: varchar("ip_address", { length: 45 }),
  reason: text("reason"), // Admin override reason
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("password_resets_user_id_idx").on(table.userId),
  tokenHashIdx: index("password_resets_token_hash_idx").on(table.tokenHash),
  statusIdx: index("password_resets_status_idx").on(table.status),
}));

// User Quotas table - usage limits per user/role
export const userQuotas = pgTable("user_quotas", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id), // Nullable for role-based quotas
  role: varchar("role", { length: 50 }), // For role-based quotas
  
  // Quota Limits
  quotaType: varchar("quota_type", { length: 50 }).notNull(), // articles_per_day, social_posts_per_day, videos_per_day, api_calls_per_hour
  limitValue: integer("limit_value").notNull(), // Maximum allowed
  periodType: varchar("period_type", { length: 20 }).notNull(), // hour, day, week, month
  
  // Current Usage (resets based on period)
  currentUsage: integer("current_usage").notNull().default(0),
  periodStartsAt: timestamp("period_starts_at").notNull().defaultNow(),
  periodEndsAt: timestamp("period_ends_at").notNull(),
  
  // Metadata
  enabled: integer("enabled").notNull().default(1), // Boolean as 0/1
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  userIdIdx: index("user_quotas_user_id_idx").on(table.userId),
  roleIdx: index("user_quotas_role_idx").on(table.role),
  quotaTypeIdx: index("user_quotas_quota_type_idx").on(table.quotaType),
}));

// System Metrics table - health monitoring data
export const systemMetrics = pgTable("system_metrics", {
  id: serial("id").primaryKey(),
  
  // Resource Usage
  cpuUsagePercent: integer("cpu_usage_percent"), // 0-100
  memoryUsageMb: integer("memory_usage_mb"),
  memoryTotalMb: integer("memory_total_mb"),
  diskUsageMb: integer("disk_usage_mb"),
  diskTotalMb: integer("disk_total_mb"),
  
  // Queue Status
  queueDepthArticles: integer("queue_depth_articles").notNull().default(0),
  queueDepthSocialPosts: integer("queue_depth_social_posts").notNull().default(0),
  queueDepthVideos: integer("queue_depth_videos").notNull().default(0),
  activeWorkers: integer("active_workers").notNull().default(0),
  
  // FFmpeg Status
  ffmpegJobsActive: integer("ffmpeg_jobs_active").notNull().default(0),
  ffmpegJobsFailed: integer("ffmpeg_jobs_failed").notNull().default(0),
  
  // API Health
  geminiApiStatus: varchar("gemini_api_status", { length: 20 }).notNull().default("healthy"), // healthy, degraded, down
  openaiApiStatus: varchar("openai_api_status", { length: 20 }).notNull().default("healthy"),
  databaseStatus: varchar("database_status", { length: 20 }).notNull().default("healthy"),
  
  // Timestamp
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
}, (table) => ({
  recordedAtIdx: index("system_metrics_recorded_at_idx").on(table.recordedAt),
}));

// Maintenance Flags table - system-wide maintenance mode and feature toggles
export const maintenanceFlags = pgTable("maintenance_flags", {
  id: serial("id").primaryKey(),
  flagKey: varchar("flag_key", { length: 100 }).notNull().unique(), // maintenance_mode, 2fa_required, new_user_signups_enabled, etc.
  flagValue: integer("flag_value").notNull().default(0), // Boolean as 0/1
  description: text("description"),
  
  // Change Tracking
  lastModifiedBy: integer("last_modified_by").references(() => users.id),
  lastModifiedAt: timestamp("last_modified_at").notNull().defaultNow(),
  
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  flagKeyIdx: index("maintenance_flags_flag_key_idx").on(table.flagKey),
}));

// ============================================================================
// CLEANUP & MAINTENANCE TABLES - Automated system cleanup jobs
// ============================================================================

// Cleanup Jobs table - tracks automated cleanup job executions
export const cleanupJobs = pgTable("cleanup_jobs", {
  id: serial("id").primaryKey(),
  jobType: varchar("job_type", { length: 50 }).notNull(), // media_cleanup, log_rotation, orphan_cleanup, user_expiry
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, running, completed, failed
  itemsProcessed: integer("items_processed").notNull().default(0),
  itemsDeleted: integer("items_deleted").notNull().default(0),
  errorMessage: text("error_message"),
  dryRun: integer("dry_run").notNull().default(0), // Boolean as 0/1
  
  // Execution Times
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  jobTypeIdx: index("cleanup_jobs_job_type_idx").on(table.jobType),
  statusIdx: index("cleanup_jobs_status_idx").on(table.status),
  createdAtIdx: index("cleanup_jobs_created_at_idx").on(table.createdAt),
}));

// Cleanup Configuration table - stores retention policies and cleanup settings
export const cleanupConfig = pgTable("cleanup_config", {
  id: serial("id").primaryKey(),
  settingKey: varchar("setting_key", { length: 100 }).notNull().unique(),
  settingValue: jsonb("setting_value").notNull(), // e.g., {"media_retention_days": 90, "log_retention_days": 60}
  description: text("description"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  updatedBy: integer("updated_by").references(() => users.id),
}, (table) => ({
  settingKeyIdx: index("cleanup_config_setting_key_idx").on(table.settingKey),
}));

// ============================================================================
// CONTENT CLUSTER TRACKING - Advanced local SEO coverage depth
// ============================================================================

// Content Clusters table - tracks topic pillars for comprehensive local coverage
export const contentClusters = pgTable("content_clusters", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  teamId: integer("team_id").references(() => teams.id),
  
  // Cluster Identity
  topicPillar: varchar("topic_pillar", { length: 255 }).notNull(), // e.g., "senior care", "dental services"
  location: varchar("location", { length: 255 }).notNull(), // City or region
  localeId: integer("locale_id").references(() => locales.id),
  
  // Coverage Tracking
  status: varchar("status", { length: 20 }).notNull().default("planning"), // planning, in_progress, complete
  totalNodesPlanned: integer("total_nodes_planned").notNull().default(0), // Total subtopics to cover
  totalNodesComplete: integer("total_nodes_complete").notNull().default(0), // Completed subtopics
  
  // Metadata
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
}, (table) => ({
  publicIdIdx: index("content_clusters_public_id_idx").on(table.publicId),
  teamIdIdx: index("content_clusters_team_id_idx").on(table.teamId),
  topicLocationIdx: index("content_clusters_topic_location_idx").on(table.topicPillar, table.location),
  statusIdx: index("content_clusters_status_idx").on(table.status),
}));

// Coverage Nodes table - tracks individual subtopic coverage within clusters
export const coverageNodes = pgTable("coverage_nodes", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  clusterId: integer("cluster_id").notNull().references(() => contentClusters.id, { onDelete: 'cascade' }),
  
  // Node Identity
  subtopicCategory: varchar("subtopic_category", { length: 100 }).notNull(), // types, costs, laws, providers, testimonials, faqs, best_practices, neighborhoods
  subtopicTitle: varchar("subtopic_title", { length: 255 }).notNull(), // Specific subtopic title
  
  // Content Coverage
  articleId: integer("article_id").references(() => articles.id), // Linked article covering this node
  depthScore: integer("depth_score").notNull().default(0), // 0-100, measures completeness
  localSignalStrength: integer("local_signal_strength").notNull().default(0), // 0-100, local relevance
  eatScore: integer("eat_score").notNull().default(0), // 0-100, E-E-A-T alignment
  
  // Status
  status: varchar("status", { length: 20 }).notNull().default("pending"), // pending, drafted, published
  
  // Metadata
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  publicIdIdx: index("coverage_nodes_public_id_idx").on(table.publicId),
  clusterIdIdx: index("coverage_nodes_cluster_id_idx").on(table.clusterId),
  subtopicCategoryIdx: index("coverage_nodes_subtopic_category_idx").on(table.subtopicCategory),
  articleIdIdx: index("coverage_nodes_article_id_idx").on(table.articleId),
  statusIdx: index("coverage_nodes_status_idx").on(table.status),
}));

// Local Authority Signals table - stores local entities and citations for E-E-A-T
export const localAuthoritySignals = pgTable("local_authority_signals", {
  id: serial("id").primaryKey(),
  publicId: uuid("public_id").notNull().unique().defaultRandom(),
  
  // Entity Identity
  entityName: varchar("entity_name", { length: 255 }).notNull(), // Local org, expert, landmark
  entityType: varchar("entity_type", { length: 50 }).notNull(), // organization, expert, landmark, regulation, statistic
  location: varchar("location", { length: 255 }).notNull(), // City or region
  
  // Citation Data
  citationUrl: text("citation_url"), // Source URL for verification
  citationText: text("citation_text"), // Quotable text or data point
  credibilityScore: integer("credibility_score").notNull().default(0), // 0-100
  
  // Freshness
  freshnessDate: timestamp("freshness_date"), // Last verified or published date
  isVerified: integer("is_verified").notNull().default(0), // Boolean as 0/1
  
  // Usage Tracking
  timesUsed: integer("times_used").notNull().default(0), // How many articles reference this
  lastUsedAt: timestamp("last_used_at"),
  
  // Metadata
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  publicIdIdx: index("local_authority_signals_public_id_idx").on(table.publicId),
  entityTypeLocationIdx: index("local_authority_signals_entity_type_location_idx").on(table.entityType, table.location),
  locationIdx: index("local_authority_signals_location_idx").on(table.location),
  freshnessDateIdx: index("local_authority_signals_freshness_date_idx").on(table.freshnessDate),
}));

// ============================================================================
// RELATIONS
// ============================================================================

export const usersRelations = relations(users, ({ many }) => ({
  jobBatches: many(jobBatches),
  sessions: many(sessions),
  activityLogs: many(activityLogs),
  totpSecret: many(totpSecrets),
  emailCodes: many(emailVerificationCodes),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

export const activityLogsRelations = relations(activityLogs, ({ one }) => ({
  user: one(users, {
    fields: [activityLogs.userId],
    references: [users.id],
  }),
}));

export const totpSecretsRelations = relations(totpSecrets, ({ one }) => ({
  user: one(users, {
    fields: [totpSecrets.userId],
    references: [users.id],
  }),
}));

export const emailVerificationCodesRelations = relations(emailVerificationCodes, ({ one }) => ({
  user: one(users, {
    fields: [emailVerificationCodes.userId],
    references: [users.id],
  }),
}));

export const jobBatchesRelations = relations(jobBatches, ({ one, many }) => ({
  user: one(users, {
    fields: [jobBatches.userId],
    references: [users.id],
  }),
  locale: one(locales, {
    fields: [jobBatches.localeId],
    references: [locales.id],
  }),
  articles: many(articles),
  seoCache: one(batchSeoCache, {
    fields: [jobBatches.id],
    references: [batchSeoCache.batchId],
  }),
}));

export const batchSeoCacheRelations = relations(batchSeoCache, ({ one }) => ({
  batch: one(jobBatches, {
    fields: [batchSeoCache.batchId],
    references: [jobBatches.id],
  }),
}));

export const articlesRelations = relations(articles, ({ one, many }) => ({
  batch: one(jobBatches, {
    fields: [articles.batchId],
    references: [jobBatches.id],
  }),
  locale: one(locales, {
    fields: [articles.localeId],
    references: [locales.id],
  }),
  assets: many(articleAssets),
  seoLogs: many(seoLogs),
  socialPosts: many(socialPosts),
  versions: many(articleVersions),
}));

export const articleAssetsRelations = relations(articleAssets, ({ one }) => ({
  article: one(articles, {
    fields: [articleAssets.articleId],
    references: [articles.id],
  }),
}));

export const localesRelations = relations(locales, ({ many }) => ({
  jobBatches: many(jobBatches),
  articles: many(articles),
}));

export const seoLogsRelations = relations(seoLogs, ({ one }) => ({
  article: one(articles, {
    fields: [seoLogs.articleId],
    references: [articles.id],
  }),
}));

export const socialPostsRelations = relations(socialPosts, ({ one, many }) => ({
  user: one(users, {
    fields: [socialPosts.userId],
    references: [users.id],
  }),
  article: one(articles, {
    fields: [socialPosts.articleId],
    references: [articles.id],
  }),
  variants: many(socialPostVariants),
  assets: many(socialPostAssets),
  jobs: many(socialPostJobs),
  logs: many(socialPostLogs),
}));

export const socialPostVariantsRelations = relations(socialPostVariants, ({ one, many }) => ({
  socialPost: one(socialPosts, {
    fields: [socialPostVariants.socialPostId],
    references: [socialPosts.id],
  }),
  assets: many(socialPostAssets),
}));

export const socialPostAssetsRelations = relations(socialPostAssets, ({ one }) => ({
  socialPost: one(socialPosts, {
    fields: [socialPostAssets.socialPostId],
    references: [socialPosts.id],
  }),
  variant: one(socialPostVariants, {
    fields: [socialPostAssets.variantId],
    references: [socialPostVariants.id],
  }),
}));

export const socialPostJobsRelations = relations(socialPostJobs, ({ one }) => ({
  socialPost: one(socialPosts, {
    fields: [socialPostJobs.socialPostId],
    references: [socialPosts.id],
  }),
}));

export const socialPostLogsRelations = relations(socialPostLogs, ({ one }) => ({
  socialPost: one(socialPosts, {
    fields: [socialPostLogs.socialPostId],
    references: [socialPosts.id],
  }),
}));

export const errorLogsRelations = relations(errorLogs, ({ one }) => ({
  batch: one(jobBatches, {
    fields: [errorLogs.batchId],
    references: [jobBatches.id],
  }),
  article: one(articles, {
    fields: [errorLogs.articleId],
    references: [articles.id],
  }),
}));

export const adminActionLogsRelations = relations(adminActionLogs, ({ one }) => ({
  user: one(users, {
    fields: [adminActionLogs.userId],
    references: [users.id],
  }),
}));

export const articleVersionsRelations = relations(articleVersions, ({ one }) => ({
  article: one(articles, {
    fields: [articleVersions.articleId],
    references: [articles.id],
  }),
  creator: one(users, {
    fields: [articleVersions.createdBy],
    references: [users.id],
  }),
}));

export const contentClustersRelations = relations(contentClusters, ({ one, many }) => ({
  team: one(teams, {
    fields: [contentClusters.teamId],
    references: [teams.id],
  }),
  locale: one(locales, {
    fields: [contentClusters.localeId],
    references: [locales.id],
  }),
  creator: one(users, {
    fields: [contentClusters.createdBy],
    references: [users.id],
  }),
  coverageNodes: many(coverageNodes),
}));

export const coverageNodesRelations = relations(coverageNodes, ({ one }) => ({
  cluster: one(contentClusters, {
    fields: [coverageNodes.clusterId],
    references: [contentClusters.id],
  }),
  article: one(articles, {
    fields: [coverageNodes.articleId],
    references: [articles.id],
  }),
}));

// ============================================================================
// INSERT SCHEMAS & TYPES
// ============================================================================

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
  joinedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
  lastLoginAt: true,
}).extend({
  password: z.string().min(12).max(255).optional(), // Password validation (12+ chars, hashed later)
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
  lastActivityAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

export const insertTotpSecretSchema = createInsertSchema(totpSecrets).omit({
  id: true,
  createdAt: true,
  lastUsedAt: true,
});

export const insertEmailVerificationCodeSchema = createInsertSchema(emailVerificationCodes).omit({
  id: true,
  createdAt: true,
});

export const insertJobBatchSchema = createInsertSchema(jobBatches).omit({
  id: true,
  publicId: true,
  createdAt: true,
  completedAt: true,
  deletedAt: true,
});

export const insertBatchSeoCacheSchema = createInsertSchema(batchSeoCache).omit({
  id: true,
  generatedAt: true,
});

export const insertArticleSchema = createInsertSchema(articles).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true,
});

export const insertArticleAssetSchema = createInsertSchema(articleAssets).omit({
  id: true,
  publicId: true,
  createdAt: true,
  deletedAt: true,
});

export const insertLocaleSchema = createInsertSchema(locales).omit({
  id: true,
  createdAt: true,
});

export const insertSeoLogSchema = createInsertSchema(seoLogs).omit({
  id: true,
  createdAt: true,
});

export const insertSocialPostSchema = createInsertSchema(socialPosts).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
  deletedAt: true,
});

export const insertSocialPostVariantSchema = createInsertSchema(socialPostVariants).omit({
  id: true,
  createdAt: true,
});

export const insertSocialPostAssetSchema = createInsertSchema(socialPostAssets).omit({
  id: true,
  createdAt: true,
});

export const insertSocialPostJobSchema = createInsertSchema(socialPostJobs).omit({
  id: true,
  createdAt: true,
});

export const insertSocialPostLogSchema = createInsertSchema(socialPostLogs).omit({
  id: true,
  createdAt: true,
});

export const insertErrorLogSchema = createInsertSchema(errorLogs).omit({
  id: true,
  createdAt: true,
});

export const insertAdminActionLogSchema = createInsertSchema(adminActionLogs).omit({
  id: true,
  createdAt: true,
});

export const insertArticleVersionSchema = createInsertSchema(articleVersions).omit({
  id: true,
  createdAt: true,
});

// Admin Management Schemas
export const insertUserInviteSchema = createInsertSchema(userInvites).omit({
  id: true,
  createdAt: true,
  acceptedAt: true,
  acceptedBy: true,
});

export const insertLoginHistorySchema = createInsertSchema(loginHistory).omit({
  id: true,
  createdAt: true,
});

export const insertPasswordResetSchema = createInsertSchema(passwordResets).omit({
  id: true,
  createdAt: true,
  usedAt: true,
});

export const insertUserQuotaSchema = createInsertSchema(userQuotas).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSystemMetricSchema = createInsertSchema(systemMetrics).omit({
  id: true,
  recordedAt: true,
});

export const insertMaintenanceFlagSchema = createInsertSchema(maintenanceFlags).omit({
  id: true,
  createdAt: true,
  lastModifiedAt: true,
});

export const insertCleanupJobSchema = createInsertSchema(cleanupJobs).omit({
  id: true,
  createdAt: true,
  startedAt: true,
  completedAt: true,
});

export const insertCleanupConfigSchema = createInsertSchema(cleanupConfig).omit({
  id: true,
  updatedAt: true,
});

export const insertContentClusterSchema = createInsertSchema(contentClusters).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
  completedAt: true,
});

export const insertCoverageNodeSchema = createInsertSchema(coverageNodes).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLocalAuthoritySignalSchema = createInsertSchema(localAuthoritySignals).omit({
  id: true,
  publicId: true,
  createdAt: true,
  updatedAt: true,
  lastUsedAt: true,
});

// TypeScript types
export type Team = typeof teams.$inferSelect;
export type InsertTeam = z.infer<typeof insertTeamSchema>;

export type TeamMember = typeof teamMembers.$inferSelect;
export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;

export type TotpSecret = typeof totpSecrets.$inferSelect;
export type InsertTotpSecret = z.infer<typeof insertTotpSecretSchema>;

export type EmailVerificationCode = typeof emailVerificationCodes.$inferSelect;
export type InsertEmailVerificationCode = z.infer<typeof insertEmailVerificationCodeSchema>;

export type JobBatch = typeof jobBatches.$inferSelect;
export type InsertJobBatch = z.infer<typeof insertJobBatchSchema>;

export type BatchSeoCache = typeof batchSeoCache.$inferSelect;
export type InsertBatchSeoCache = z.infer<typeof insertBatchSeoCacheSchema>;

export type Article = typeof articles.$inferSelect;
export type InsertArticle = z.infer<typeof insertArticleSchema>;

export type ArticleAsset = typeof articleAssets.$inferSelect;
export type InsertArticleAsset = z.infer<typeof insertArticleAssetSchema>;

export type Locale = typeof locales.$inferSelect;
export type InsertLocale = z.infer<typeof insertLocaleSchema>;

export type SeoLog = typeof seoLogs.$inferSelect;
export type InsertSeoLog = z.infer<typeof insertSeoLogSchema>;

export type SocialPost = typeof socialPosts.$inferSelect;
export type InsertSocialPost = z.infer<typeof insertSocialPostSchema>;

export type SocialPostVariant = typeof socialPostVariants.$inferSelect;
export type InsertSocialPostVariant = z.infer<typeof insertSocialPostVariantSchema>;

export type SocialPostAsset = typeof socialPostAssets.$inferSelect;
export type InsertSocialPostAsset = z.infer<typeof insertSocialPostAssetSchema>;

export type SocialPostJob = typeof socialPostJobs.$inferSelect;
export type InsertSocialPostJob = z.infer<typeof insertSocialPostJobSchema>;

export type SocialPostLog = typeof socialPostLogs.$inferSelect;
export type InsertSocialPostLog = z.infer<typeof insertSocialPostLogSchema>;

export type ErrorLog = typeof errorLogs.$inferSelect;
export type InsertErrorLog = z.infer<typeof insertErrorLogSchema>;

export type AdminActionLog = typeof adminActionLogs.$inferSelect;
export type InsertAdminActionLog = z.infer<typeof insertAdminActionLogSchema>;

export type ArticleVersion = typeof articleVersions.$inferSelect;
export type InsertArticleVersion = z.infer<typeof insertArticleVersionSchema>;

// Admin Management Types
export type UserInvite = typeof userInvites.$inferSelect;
export type InsertUserInvite = z.infer<typeof insertUserInviteSchema>;

export type LoginHistory = typeof loginHistory.$inferSelect;
export type InsertLoginHistory = z.infer<typeof insertLoginHistorySchema>;

export type PasswordReset = typeof passwordResets.$inferSelect;
export type InsertPasswordReset = z.infer<typeof insertPasswordResetSchema>;

export type UserQuota = typeof userQuotas.$inferSelect;
export type InsertUserQuota = z.infer<typeof insertUserQuotaSchema>;

export type SystemMetric = typeof systemMetrics.$inferSelect;
export type InsertSystemMetric = z.infer<typeof insertSystemMetricSchema>;

export type MaintenanceFlag = typeof maintenanceFlags.$inferSelect;
export type InsertMaintenanceFlag = z.infer<typeof insertMaintenanceFlagSchema>;

export type CleanupJob = typeof cleanupJobs.$inferSelect;
export type InsertCleanupJob = z.infer<typeof insertCleanupJobSchema>;

export type CleanupConfig = typeof cleanupConfig.$inferSelect;
export type InsertCleanupConfig = z.infer<typeof insertCleanupConfigSchema>;

// Content Cluster Types
export type ContentCluster = typeof contentClusters.$inferSelect;
export type InsertContentCluster = z.infer<typeof insertContentClusterSchema>;

export type CoverageNode = typeof coverageNodes.$inferSelect;
export type InsertCoverageNode = z.infer<typeof insertCoverageNodeSchema>;

export type LocalAuthoritySignal = typeof localAuthoritySignals.$inferSelect;
export type InsertLocalAuthoritySignal = z.infer<typeof insertLocalAuthoritySignalSchema>;

// Extended types for API responses
export type ArticleWithAssets = Article & {
  assets: ArticleAsset[];
};

export type ArticleWithAll = Article & {
  assets: ArticleAsset[];
};

export type JobBatchWithArticles = JobBatch & {
  articles: Article[];
};

// ============================================================================
// API REQUEST/RESPONSE SCHEMAS
// ============================================================================

export const titlePoolRequestSchema = z.object({
  coreTopic: z.string().min(1, "Core topic is required"),
  numTitles: z.number().int().min(10).max(100).default(50),
  targetAudience: z.string().optional(),
  geographic: z.string().optional(),
});

export const batchSubmitSchema = z.object({
  userId: z.number().int(),
  coreTopic: z.string().min(1),
  targetUrl: z.string().url("Must be a valid URL"),
  selectedTitles: z.array(z.string()).min(1).max(50),
  wordCount: z.number().int().min(800).max(2000).default(1200),
  targetAudience: z.string().optional(),
  geographic: z.string().optional(),
});

export type TitlePoolRequest = z.infer<typeof titlePoolRequestSchema>;
export type BatchSubmitRequest = z.infer<typeof batchSubmitSchema>;
