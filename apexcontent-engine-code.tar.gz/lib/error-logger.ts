import { db } from "./db";
import { errorLogs } from "@/shared/schema";
import { eq } from "drizzle-orm";

export type ErrorType = "GEMINI" | "GPT4" | "DALLE" | "SCHEMA" | "UPLOAD" | "QUEUE" | "HERO_IMAGE";
export type Severity = "warning" | "error" | "critical";

export interface LogErrorParams {
  errorType: ErrorType;
  errorMessage: string;
  stackTrace?: string;
  severity?: Severity;
  batchId?: number;
  articleId?: number;
}

export async function logError(params: LogErrorParams): Promise<void> {
  try {
    await db.insert(errorLogs).values({
      errorType: params.errorType,
      errorMessage: params.errorMessage,
      stackTrace: params.stackTrace,
      severity: params.severity || "error",
      batchId: params.batchId,
      articleId: params.articleId,
      resolved: 0,
    });
    
    console.error(`[ERROR_LOG] ${params.errorType}: ${params.errorMessage}`);
  } catch (dbError) {
    // Fallback to console if database logging fails
    console.error("[ERROR_LOG] Failed to log error to database:", dbError);
    console.error("[ERROR_LOG] Original error:", params);
  }
}

export async function getRecentErrors(limit: number = 100) {
  return await db
    .select()
    .from(errorLogs)
    .orderBy(errorLogs.createdAt)
    .limit(limit);
}

export async function getUnresolvedErrors() {
  return await db
    .select()
    .from(errorLogs)
    .where(eq(errorLogs.resolved, 0))
    .orderBy(errorLogs.createdAt);
}
