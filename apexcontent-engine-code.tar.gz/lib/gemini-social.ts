import { GoogleGenAI } from "@google/genai";
import { 
  createBrandValidationPrompt, 
  getPlatformStructureGuidance, 
  getTargetAudience,
  PLATFORM_GUIDANCE,
  normalizePlatform
} from "./social-prompt-guidance";
import { 
  generateAdvancedSocialPrompt,
  type LocalIntelligence,
  type AuthoritySignals,
  type EEATSignals
} from "./social-prompt-guidance-advanced";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY is required for Gemini social post generation");
}

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface GeminiSocialPostRequest {
  prompt: string;
  platform: string;
  tone: string;
  mood: string;
  industry: string;
  characterLimit: number;
  location?: string;
  topic?: string;
  title?: string;
  companyName?: string;
  // TASK 7: Advanced Local SEO + Authority Signals
  localIntelligence?: LocalIntelligence;
  authoritySignals?: AuthoritySignals;
  eatSignals?: EEATSignals;
  useAdvancedPrompts?: boolean; // Flag to enable Task 7 enhancements
}

interface GeminiSocialPostResult {
  caption: string;
  wordCount: number;
  characterCount: number;
}

export async function generateSocialPostWithGemini(
  request: GeminiSocialPostRequest
): Promise<GeminiSocialPostResult> {
  const { 
    prompt, 
    platform, 
    tone, 
    mood, 
    industry, 
    characterLimit, 
    location, 
    topic, 
    title, 
    companyName,
    localIntelligence,
    authoritySignals,
    eatSignals,
    useAdvancedPrompts = false, // TASK 7: Default to legacy prompts for backward compatibility
  } = request;

  console.log(`🤖 Gemini generating ${platform} post (${tone} tone, ${mood} mood${useAdvancedPrompts ? ' [ADVANCED LOCAL SEO]' : ''})`);

  // TASK 7: Switch between legacy and advanced prompt systems
  let systemPrompt: string;

  if (useAdvancedPrompts) {
    // Use advanced local SEO + authority signal prompts
    const contentType: 'article' | 'standalone' | 'campaign' = title ? 'article' : 'standalone';
    systemPrompt = generateAdvancedSocialPrompt({
      platform,
      tone,
      mood,
      industry,
      basePrompt: prompt,
      companyName,
      localIntel: localIntelligence,
      authoritySignals,
      eatSignals,
      contentType,
    });
  } else {
    // LEGACY PROMPT SYSTEM (backward compatibility)
    // Extract city and neighborhood from location if possible
    const locationParts = location ? location.split(',').map(p => p.trim()) : [];
    const city = locationParts[0] || location || '';
    const neighborhood = locationParts[1] || '';

    // Get platform-specific guidance
    const platformKey = normalizePlatform(platform);
    const platformGuidance = PLATFORM_GUIDANCE[platformKey] || PLATFORM_GUIDANCE['x'];
    const contentSource: 'article' | 'standalone' = title ? 'article' : 'standalone';
    const targetAudience = getTargetAudience(platform, industry);
    const structureGuidance = getPlatformStructureGuidance(platform, contentSource);

    systemPrompt = `You are the social media voice of ${companyName || 'this brand'}. Create a compelling ${platformGuidance.platform} post that drives engagement and builds trust with ${targetAudience}.

${companyName ? createBrandValidationPrompt(companyName) : ''}

PLATFORM CONTEXT:
- Platform: ${platformGuidance.platform}
- Brand Voice: ${tone} tone, ${mood} mood
- Industry: ${industry}
- Character Limit: ${characterLimit} characters (STRICT MAXIMUM)
- Target Audience: ${targetAudience}
${location ? `- Location: ${location} (City: ${city}${neighborhood ? `, Neighborhood: ${neighborhood}` : ''})` : ''}
${topic ? `- Topic: ${topic}` : ''}
${title ? `- Article Title: ${title}` : ''}

PLATFORM-SPECIFIC STRATEGY (${platformGuidance.platform}):
Hook Formula: ${platformGuidance.hookFormula}
Emotional Triggers: ${platformGuidance.emotionalTriggers.slice(0, 2).join(', ')}
Brand Voice: ${platformGuidance.brandVoiceElements.slice(0, 2).join(', ')}

CRITICAL REQUIREMENTS:
1. **POWERFUL OPENING HOOK** (First 1-2 sentences)
   - ${platformGuidance.hookFormula}
   - Grab attention immediately with ${platformGuidance.emotionalTriggers[0]}
   
2. **EMOTIONAL RESONANCE** (Middle 2-3 sentences)
   - Connect through: ${platformGuidance.emotionalTriggers[1] || platformGuidance.emotionalTriggers[0]}
   - Maintain ${platformGuidance.brandVoiceElements[0]} voice
   - ${location ? `Weave in ${city} references naturally (landmarks, neighborhoods, local culture)` : 'Provide relevant context'}
   
3. **CLEAR CALL-TO-ACTION** (Final sentence)
   - ${platformGuidance.ctaPattern[0]} or ${platformGuidance.ctaPattern[1]}
   - Make it specific and actionable
   
4. **PLATFORM OPTIMIZATION**:
   - Character limit: ${characterLimit} characters MAXIMUM (enforce strictly)
   - ${tone} tone throughout
   - ${platformGuidance.platform}-native language and style
   - NO hashtags (added separately)
   - NO emojis (added separately)
   ${companyName ? `- Include "${companyName}" exactly once (verify spelling)` : ''}

DO:
${platformGuidance.dos.slice(0, 3).map(item => `- ${item}`).join('\n')}

DON'T:
${platformGuidance.donts.slice(0, 2).map(item => `- ${item}`).join('\n')}

CONTENT PROMPT:
${prompt}

${structureGuidance}

Generate ONLY the post caption text. No explanations, no metadata, just the post itself.`;
  } // Close else block for legacy prompts

  // Generate content with Gemini (shared by both prompt systems)
  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [
      {
        role: "user",
        parts: [{ text: systemPrompt }],
      },
    ],
  });
  
  const caption = (result.text || "").trim();
  
  // Defensive handling: ensure we have content
  if (!caption) {
    throw new Error(`Gemini returned empty response for ${platform} post`);
  }

  // Truncate if needed
  const truncatedCaption = caption.length > characterLimit 
    ? caption.substring(0, characterLimit - 3) + "..."
    : caption;

  const wordCount = truncatedCaption.split(/\s+/).length;
  const characterCount = truncatedCaption.length;

  console.log(`✅ Gemini generated ${platform} post (${characterCount} chars, ${wordCount} words)`);

  return {
    caption: truncatedCaption,
    wordCount,
    characterCount,
  };
}
