import { GoogleGenAI } from "@google/genai";
import { createBrandLockPromptSegment, validateBrandInOutput } from "./branding";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY is required for video script generation");
}

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface VideoScene {
  sceneNumber: number;
  timeRange: string; // e.g., "0-10s", "10-22s"
  targetDuration: number; // Target duration in seconds (10, 12, 12, 12, or 14)
  narration: string; // Voiceover text for this scene
  visualDescription: string; // What image should show
  caption: string; // Text overlay for this scene
  geoReference: string; // Location-specific reference
  seoKeywords: string[]; // Keywords for this scene
}

export interface VideoScript {
  title: string;
  totalDuration: number; // Should be 60 seconds
  scenes: VideoScene[];
  hashtags: string[];
  callToAction: string;
  companyName: string;
  location: string;
}

interface GenerateVideoScriptRequest {
  topic: string;
  title: string;
  location: string;
  tone: string;
  mood: string;
  industry: string;
  companyName: string;
  articleContent?: string; // Optional: use article content for script
  landingPageUrl?: string;
}

export async function generateVideoScript(
  request: GenerateVideoScriptRequest
): Promise<VideoScript> {
  const {
    topic,
    title,
    location,
    tone,
    mood,
    industry,
    companyName,
    articleContent,
    landingPageUrl,
  } = request;

  console.log(`🎬 Generating 60-second video script for: ${title}`);
  
  const brandLockContext = companyName ? createBrandLockPromptSegment(companyName) : "";

  const prompt = `You are a professional video script writer creating a 60-second social media video script.
${brandLockContext}

BUSINESS CONTEXT:
Company: ${companyName}
Industry: ${industry}
Topic: ${topic}
Title: ${title}
Location: ${location}
Tone: ${tone}
Mood: ${mood}
${landingPageUrl ? `Landing Page: ${landingPageUrl}` : ""}
${articleContent ? `Article Content (for reference):\n${articleContent.slice(0, 2000)}` : ""}

VIDEO STRUCTURE:
Create EXACTLY 5 scenes totaling 60 seconds (intro: 10s, body1: 12s, body2: 12s, conclusion: 12s, branded CTA: 14s).

CRITICAL NARRATION LENGTH REQUIREMENTS:
- Scene 1: Write narration that takes EXACTLY 10 seconds to speak naturally (approximately 25-30 words)
- Scene 2: Write narration that takes EXACTLY 12 seconds to speak naturally (approximately 30-35 words)
- Scene 3: Write narration that takes EXACTLY 12 seconds to speak naturally (approximately 30-35 words)
- Scene 4: Write narration that takes EXACTLY 12 seconds to speak naturally (approximately 30-35 words)
- Scene 5: Write narration that takes EXACTLY 14 seconds to speak naturally (approximately 35-40 words)
- Total narration should take 60 seconds when spoken at a natural conversational pace

SCENE REQUIREMENTS:
Scene 1 (0-10s): HOOK/INTRO - Grab attention immediately with a compelling question or statement about ${location}
Scene 2 (10-22s): PROBLEM/OPPORTUNITY - Explain the challenge or opportunity in ${industry}
Scene 3 (22-34s): SOLUTION - Show how ${companyName} solves this with specific ${location} examples
Scene 4 (34-46s): CONCLUSION - Summarize key benefits and ${location}-specific advantages
Scene 5 (46-60s): BRANDED CTA/OUTRO - Strong call-to-action with ${companyName} branding, logo-friendly composition, and memorable tagline

MANDATORY REQUIREMENTS:
✅ Include ${location} (city/neighborhood) references in EVERY scene for local SEO
✅ Use business-ready ${tone} tone throughout
✅ Match ${mood} mood in language and pacing
✅ Include ${industry}-specific terminology and examples
✅ Each scene must have: narration (spoken), visual description (what to show), and caption (text overlay)
✅ Narration should be conversational and engaging (not robotic) and MUST match the target duration for each scene
✅ DO NOT write short narration - each scene needs enough words to fill its target duration (10s, 12s, 12s, 12s, 14s)
✅ Visual descriptions should be specific and cinematic
✅ Captions should be short, punchy, and reinforce the narration (NOT generic like "CALL TO ACTION")
✅ Scene 5 caption MUST include actual call-to-action text like "Visit Us Today", "Get Started", "Learn More" plus company name
✅ Include 8-12 relevant hashtags combining SEO keywords and ${location} geo-tags
✅ Final scene MUST mention ${companyName} explicitly in both narration AND caption

SEO/GEO OPTIMIZATION:
- Weave ${location} landmarks, neighborhoods, or local references naturally into narration
- Use location-based keywords (e.g., "${location} ${industry}", "local ${industry} in ${location}")
- Include industry-specific SEO terms throughout

OUTPUT FORMAT:
Return a valid JSON object with this exact structure:
{
  "title": "Engaging video title",
  "totalDuration": 60,
  "scenes": [
    {
      "sceneNumber": 1,
      "timeRange": "0-10s",
      "targetDuration": 10,
      "narration": "Spoken voiceover text - conversational, engaging, natural hook",
      "visualDescription": "Detailed description of what image should show - specific and cinematic",
      "caption": "SHORT TEXT OVERLAY",
      "geoReference": "Specific ${location} reference in this scene",
      "seoKeywords": ["keyword1", "keyword2", "keyword3"]
    },
    {
      "sceneNumber": 2,
      "timeRange": "10-22s",
      "targetDuration": 12,
      "narration": "Problem/opportunity explanation - keep to ~12 seconds",
      "visualDescription": "Visual for problem/opportunity scene",
      "caption": "SHORT TEXT OVERLAY",
      "geoReference": "Specific ${location} reference",
      "seoKeywords": ["keyword1", "keyword2"]
    },
    {
      "sceneNumber": 3,
      "timeRange": "22-34s",
      "targetDuration": 12,
      "narration": "Solution explanation - keep to ~12 seconds",
      "visualDescription": "Visual for solution scene",
      "caption": "SHORT TEXT OVERLAY",
      "geoReference": "Specific ${location} reference",
      "seoKeywords": ["keyword1", "keyword2"]
    },
    {
      "sceneNumber": 4,
      "timeRange": "34-46s",
      "targetDuration": 12,
      "narration": "Conclusion and benefits - keep to ~12 seconds",
      "visualDescription": "Visual for conclusion scene",
      "caption": "SHORT TEXT OVERLAY",
      "geoReference": "Specific ${location} reference",
      "seoKeywords": ["keyword1", "keyword2"]
    },
    {
      "sceneNumber": 5,
      "timeRange": "46-60s",
      "targetDuration": 14,
      "narration": "Branded call-to-action with ${companyName} and memorable tagline - keep to ~14 seconds",
      "visualDescription": "Logo-friendly branded outro visual",
      "caption": "Visit Us Today | ${companyName}",
      "geoReference": "Specific ${location} reference",
      "seoKeywords": ["keyword1", "keyword2"]
    }
  ],
  "hashtags": ["#HashtagWithoutSpaces", "#Another", ...],
  "callToAction": "Visit us at [URL] or Final action statement",
  "companyName": "${companyName}",
  "location": "${location}"
}

CRITICAL: Return ONLY valid JSON. No markdown formatting, no explanations, just pure JSON.`;

  try {
    const response = await genAI.models.generateContent({
      model: "gemini-2.0-flash",
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: {
        temperature: 0.8,
        maxOutputTokens: 2000,
      },
    });

    const text = (response.text || "").trim();
    
    // Remove markdown code blocks if present
    let cleanedText = text
      .replace(/^```json\s*/i, "")
      .replace(/^```\s*/i, "")
      .replace(/```\s*$/i, "")
      .trim();

    // Auto-correct brand name case before parsing
    if (companyName) {
      console.log(`🔧 Auto-correcting brand name case: "${companyName}"`);
      const escapedBrand = companyName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const caseInsensitiveRegex = new RegExp(
        `(?<![\\p{L}\\p{N}_])${escapedBrand}(?![\\p{L}\\p{N}_])`,
        'gui'
      );
      
      cleanedText = cleanedText.replace(caseInsensitiveRegex, companyName);
      console.log(`✅ Brand name case corrected to: "${companyName}"`);
    }

    const script: VideoScript = JSON.parse(cleanedText);

    // Brand lock validation (Layer 2: Runtime Validation)
    if (companyName) {
      console.log(`🔒 Validating brand spelling: "${companyName}"`);
      const validationResult = validateBrandInOutput(cleanedText, companyName);
      
      if (!validationResult.valid) {
        const errorMsg = `Brand lock violation in video script! ${validationResult.errors.join("; ")}`;
        console.error(`❌ ${errorMsg}`);
        throw new Error(errorMsg);
      }
      
      console.log(`✅ Brand spelling validated successfully`);
    }

    // Validation
    if (!script.scenes || script.scenes.length !== 5) {
      throw new Error(`Expected 5 scenes, got ${script.scenes?.length || 0}`);
    }

    if (script.totalDuration !== 60) {
      console.warn(`⚠️ Duration mismatch: ${script.totalDuration}s, forcing to 60s`);
      script.totalDuration = 60;
    }

    console.log(`✅ Generated 60-second video script with 5 scenes (intro, body1, body2, conclusion, branded CTA)`);
    return script;
  } catch (error) {
    console.error("❌ Failed to generate video script:", error);
    throw new Error(`Video script generation failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
