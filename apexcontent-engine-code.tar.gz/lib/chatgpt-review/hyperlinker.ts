import { openaiClient, callOpenAI } from "../openai-client";

export interface HyperlinkResult {
  keywords: Array<{
    phrase: string;
    url: string;
    type: "internal" | "external";
    anchorText: string;
  }>;
  totalLinks: number;
  internalCount: number;
  externalCount: number;
  tokenUsage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

export async function generateHyperlinks(
  content: string,
  coreTopic: string,
  targetUrl: string,
  competitorUrls?: string[]
): Promise<HyperlinkResult> {
  const systemPrompt = `You are an SEO expert specializing in strategic hyperlink placement for local businesses.
Your task is to identify 18-25 long-phrase keywords in the content that should ALL be hyperlinked to the client's website for maximum SEO value and traffic generation.

Rules:
- ALL links must point to ${targetUrl} (the client's website)
- Use long-phrase keywords (3-7 words) not single words
- Identify naturally occurring phrases that would be valuable anchor text
- Prioritize high-value semantic keywords related to the business
- Select phrases that potential customers would search for
- Avoid over-optimization - ensure natural placement
- Focus on phrases that demonstrate expertise and authority`;

  const userPrompt = `Core Topic: ${coreTopic}
Target URL (ALL hyperlinks must point here): ${targetUrl}
${competitorUrls?.length ? `Competitor URLs for reference: ${competitorUrls.join(", ")}` : ""}

Content to analyze:
${content}

Identify 18-25 long-phrase keywords (3-7 words each) that naturally appear THROUGHOUT THE ENTIRE CONTENT and would be valuable anchor text for hyperlinking to ${targetUrl}.

IMPORTANT: Scan the ENTIRE article from beginning to end. Select phrases that appear at different points throughout the content, not just at the top.

Return a JSON object with a "keywords" array:
{
  "keywords": [
    {
      "phrase": "long-phrase keyword found in content",
      "url": "${targetUrl}",
      "type": "internal",
      "anchorText": "exact phrase to hyperlink"
    }
  ]
}

CRITICAL: ALL links must have "url": "${targetUrl}" and "type": "internal". Return 18-25 total links distributed throughout the article.`;

  try {
    const completion = await callOpenAI(
      (client) => client.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.3,
        max_tokens: 1500,
        response_format: { type: "json_object" },
      }),
      `Hyperlinker: ${coreTopic.substring(0, 50)}`
    );

    const responseText = completion.choices[0]?.message?.content || "{}";
    const parsed = JSON.parse(responseText);
    
    // Defensive: coerce response into array (handles all OpenAI response formats)
    const keywords = Array.isArray(parsed) 
      ? parsed 
      : Array.isArray(parsed.keywords) 
        ? parsed.keywords
        : Array.isArray(parsed.links) 
        ? parsed.links 
        : [];

    const internalCount = keywords.filter((k: any) => k.type === "internal").length;
    const externalCount = keywords.filter((k: any) => k.type === "external").length;

    return {
      keywords,
      totalLinks: keywords.length,
      internalCount,
      externalCount,
      tokenUsage: {
        promptTokens: completion.usage?.prompt_tokens || 0,
        completionTokens: completion.usage?.completion_tokens || 0,
        totalTokens: completion.usage?.total_tokens || 0,
      },
    };
  } catch (error) {
    console.error("Hyperlink generation error:", error);
    throw new Error("Failed to generate hyperlinks");
  }
}
