import { db } from "./db";
import { articles, articleAssets, jobBatches } from "../shared/schema";
import { eq } from "drizzle-orm";
import { generatePodcastScript, type PodcastScript } from "./podcast-generator";
import { mergeAudioSegments, estimateAudioDuration } from "./openai-tts";
import { objectStorageClient } from "./storage";
import { validateBrandInOutput } from "./branding";
import { uploadPodcastToDrive } from "./google-drive";

export interface PodcastGenerationJob {
  articleId: number;
  tone?: string;
  duration?: string;
}

export async function generateArticlePodcast(job: PodcastGenerationJob): Promise<void> {
  const { articleId, tone, duration } = job;
  
  try {
    console.log(`[Podcast Worker] Starting podcast generation for article ${articleId}`);
    
    const article = await db.query.articles.findFirst({
      where: eq(articles.id, articleId),
      with: {
        batch: true,
      },
    });
    
    if (!article) {
      throw new Error(`Article ${articleId} not found`);
    }
    
    if (!article.finalHtmlContent || !article.chosenTitle) {
      throw new Error(`Article ${articleId} missing content or title`);
    }
    
    const companyName = article.batch?.businessName || "our company";
    
    await db.update(articles)
      .set({ podcastStatus: 'processing' })
      .where(eq(articles.id, articleId));
    
    const textContent = article.finalHtmlContent
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    console.log(`[Podcast Worker] Generating script for article ${articleId}`);
    const script: PodcastScript = await generatePodcastScript(
      article.chosenTitle,
      textContent,
      { tone, duration, companyName }
    );
    
    console.log(`[Podcast Worker] Script generated with ${script.segments.length} segments`);
    
    // BRAND NAME VALIDATION: Ensure correct brand spelling in podcast script
    if (companyName && companyName !== "our company") {
      const scriptText = script.segments.map(s => s.text).join(' ');
      const brandValidation = validateBrandInOutput(scriptText, companyName);
      if (!brandValidation.valid) {
        console.error(`❌ Podcast script failed brand validation for article ${articleId}:`, brandValidation.errors);
        await db.update(articles)
          .set({ podcastStatus: 'failed' })
          .where(eq(articles.id, articleId));
        throw new Error(`Podcast script failed brand validation: ${brandValidation.errors.join(", ")}`);
      }
      console.log(`✅ Podcast script brand name validation passed: "${companyName}"`);
    }
    
    console.log(`[Podcast Worker] Generating audio for article ${articleId}`);
    const audioSegments = script.segments.map(seg => ({
      voice: seg.voice,
      text: seg.text,
    }));
    
    const audioBuffer = await mergeAudioSegments(audioSegments);
    console.log(`[Podcast Worker] Audio generated, size: ${audioBuffer.length} bytes`);
    
    const totalText = script.segments.map(s => s.text).join(' ');
    const estimatedDuration = estimateAudioDuration(totalText.length);
    
    const scriptSummary = {
      title: script.title,
      segmentCount: script.segments.length,
      duration: script.duration,
      generatedAt: new Date().toISOString(),
    };
    
    const fileName = `podcast-article-${articleId}-${Date.now()}.mp3`;
    const objectPath = `public/podcasts/${fileName}`;
    const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || "";
    const storageUrl = `/api/public-objects/podcasts/${fileName}`;
    
    let uploadedFile: any = null;
    
    try {
      await db.update(articles)
        .set({
          podcastDuration: estimatedDuration,
          podcastStatus: 'processing',
          podcastScriptJson: scriptSummary as any,
        })
        .where(eq(articles.id, articleId));
      
      console.log(`[Podcast Worker] Uploading to object storage: ${objectPath}`);
      const bucket = objectStorageClient.bucket(BUCKET_ID);
      const file = bucket.file(objectPath);
      uploadedFile = file;
      
      await file.save(audioBuffer, {
        contentType: "audio/mpeg",
        metadata: {
          cacheControl: "public, max-age=31536000",
        },
      });
      
      console.log(`[Podcast Worker] Object storage upload complete`);
      
      // Google Drive backup (non-blocking - don't fail if this fails)
      try {
        const driveFileId = await uploadPodcastToDrive(
          audioBuffer,
          fileName,
          {
            articleTitle: article.chosenTitle,
            articleId: String(articleId),
            duration: estimatedDuration,
          }
        );
        if (driveFileId) {
          console.log(`[Podcast Worker] ✓ Google Drive backup successful (File ID: ${driveFileId})`);
        }
      } catch (driveError) {
        console.warn(`[Podcast Worker] Google Drive backup failed (non-fatal):`, driveError);
      }
      
      let assetInserted = false;
      
      try {
        await db.insert(articleAssets).values({
          articleId: articleId,
          assetType: 'audio',
          storageUrl: storageUrl,
          altText: `Podcast: ${article.chosenTitle}`,
          fileFormat: 'mp3',
          metadataJson: {
            duration: estimatedDuration,
            segments: script.segments.length,
            generatedAt: new Date().toISOString(),
          } as any,
        });
        assetInserted = true;
        
        await db.update(articles)
          .set({
            podcastUrl: storageUrl,
            podcastStatus: 'ready',
            podcastGeneratedAt: new Date(),
          })
          .where(eq(articles.id, articleId));
      } catch (dbError) {
        console.error(`[Podcast Worker] DB write failed after upload, cleaning up:`, dbError);
        
        if (assetInserted) {
          try {
            await db.delete(articleAssets)
              .where(eq(articleAssets.storageUrl, storageUrl));
            console.log(`[Podcast Worker] Cleaned up orphaned asset record`);
          } catch (assetCleanupError) {
            console.error(`[Podcast Worker] Failed to cleanup asset record:`, assetCleanupError);
          }
        }
        
        if (uploadedFile) {
          try {
            await uploadedFile.delete();
            console.log(`[Podcast Worker] Cleaned up orphaned file: ${objectPath}`);
          } catch (fileCleanupError) {
            console.error(`[Podcast Worker] Failed to cleanup orphaned file:`, fileCleanupError);
          }
        }
        
        throw dbError;
      }
    } catch (dbOrStorageError) {
      console.error(`[Podcast Worker] DB/Storage error for article ${articleId}:`, dbOrStorageError);
      await db.update(articles)
        .set({ podcastStatus: 'failed' })
        .where(eq(articles.id, articleId));
      throw dbOrStorageError;
    }
    
    console.log(`[Podcast Worker] Podcast generated successfully for article ${articleId}`);
  } catch (error) {
    console.error(`[Podcast Worker] Error generating podcast for article ${articleId}:`, error);
    
    await db.update(articles)
      .set({ podcastStatus: 'failed' })
      .where(eq(articles.id, articleId));
    
    throw error;
  }
}
