import type PgBoss from "pg-boss";
import { db } from "./db";
import {
  socialPosts,
  socialPostVariants,
  socialPostAssets,
  socialPostJobs,
  socialPostLogs,
  errorLogs,
} from "@/shared/schema";
import { eq, and } from "drizzle-orm";
import type { SocialPostJobData } from "./queue";
import { PLATFORM_LIMITS, PLATFORM_ASPECT_RATIOS } from "./social-validation";

// Platform character limits
const CHAR_LIMITS = {
  x: 280,
  facebook: 63206,
  instagram: 2200,
  linkedin: 3000,
  pinterest: 500,
} as const;

// ============================================================================
// SEO/GEO HELPER FUNCTIONS
// ============================================================================

function generateSEOKeywords(topic: string, title: string, location: string, industry: string): string[] {
  const keywords: string[] = [];
  
  // Extract key terms from topic and title
  const topicTerms = topic.split(/\s+/).filter(t => t.length > 3);
  const titleTerms = title.split(/\s+/).filter(t => t.length > 3);
  
  // Location-based keywords
  if (location) {
    keywords.push(location);
    keywords.push(`${location} ${industry}`);
    keywords.push(`${topic} in ${location}`);
  }
  
  // Industry keywords
  if (industry) {
    keywords.push(industry);
    keywords.push(`${industry} ${topic}`);
  }
  
  // Topic keywords
  topicTerms.slice(0, 3).forEach(term => keywords.push(term.toLowerCase()));
  titleTerms.slice(0, 3).forEach(term => keywords.push(term.toLowerCase()));
  
  // Remove duplicates and return
  return Array.from(new Set(keywords)).slice(0, 15);
}

function generateGeoTags(location: string, platforms: string[]): Array<{ platform: string; tag: string }> {
  const geoTags: Array<{ platform: string; tag: string }> = [];
  
  if (!location) return geoTags;
  
  // Generate platform-specific geo-tags
  platforms.forEach(platform => {
    switch (platform) {
      case "x":
        geoTags.push({ platform, tag: `#${location.replace(/\s+/g, "")}` });
        break;
      case "instagram":
        geoTags.push({ platform, tag: `Location: ${location}` });
        break;
      case "facebook":
      case "linkedin":
      case "pinterest":
        geoTags.push({ platform, tag: location });
        break;
    }
  });
  
  return geoTags;
}

// ============================================================================
// SOCIAL POST GENERATION WORKER
// ============================================================================

export async function processSocialPostGeneration(job: PgBoss.Job<SocialPostJobData>) {
  const { socialPostId, userId, prompt, platforms, tone, mood, industry, includeImage, userEmail } = job.data;
  
  console.log(`🎭 Processing social post generation ${socialPostId} for ${platforms.length} platforms`);

  try {
    // Update status to GENERATING
    await db
      .update(socialPosts)
      .set({ status: "GENERATING", jobId: job.id })
      .where(eq(socialPosts.id, socialPostId));

    // Log generation start
    await db.insert(socialPostLogs).values({
      socialPostId,
      eventType: "GENERATION_START",
      stage: "GEMINI",
      severity: "info",
      message: `Starting social post generation for ${platforms.length} platforms`,
      payloadJson: { platforms, tone, mood, industry },
    });

    // Register job in tracking table
    await db.insert(socialPostJobs).values({
      socialPostId,
      jobId: job.id,
      jobType: "GENERATION",
      status: "ACTIVE",
      startedAt: new Date(),
    });

    // Import AI providers
    const { generateSocialPostWithGemini } = await import("./gemini-social");
    const { enhanceSocialPostWithGPT } = await import("./openai-social");
    
    // Get post details to extract location, company name for SEO/GEO and validation
    const [postDetails] = await db
      .select()
      .from(socialPosts)
      .where(eq(socialPosts.id, socialPostId));
    
    const location = postDetails?.location || "";
    const topic = postDetails?.topic || "";
    const title = postDetails?.title || "";
    const landingPageUrl = postDetails?.landingPageUrl || undefined;
    const companyName = postDetails?.companyName || undefined;
    
    // Generate SEO keywords and geo-tags
    const seoKeywords = generateSEOKeywords(topic, title, location, industry || "");
    const geoTags = generateGeoTags(location, platforms);
    
    // Update post with SEO/GEO metadata
    await db
      .update(socialPosts)
      .set({ 
        seoKeywordsJson: seoKeywords,
        geoTagsJson: geoTags,
      })
      .where(eq(socialPosts.id, socialPostId));
    
    // CONCURRENT PROCESSING: Generate posts for all platforms in parallel
    console.log(`🚀 Generating ${platforms.length} platform variants concurrently...`);
    
    const platformPromises = platforms.map(async (platform) => {
      const retryWithBackoff = async <T>(
        fn: () => Promise<T>,
        maxRetries = 3,
        platform: string
      ): Promise<T> => {
        let lastError: Error | null = null;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
          try {
            return await fn();
          } catch (error) {
            lastError = error as Error;
            console.error(`❌ Attempt ${attempt}/${maxRetries} failed for ${platform}:`, error);
            if (attempt < maxRetries) {
              const delayMs = Math.pow(2, attempt) * 1000; // 2s, 4s, 8s
              console.log(`⏳ Retrying ${platform} in ${delayMs / 1000}s...`);
              await new Promise(resolve => setTimeout(resolve, delayMs));
            }
          }
        }
        throw lastError;
      };

      try {
        console.log(`📱 Generating ${platform} post for social post ${socialPostId}`);

        // Create variant with GENERATING status
        const [variant] = await db.insert(socialPostVariants).values({
          socialPostId,
          platform,
          caption: "", // Will be updated after generation
          characterCount: 0,
          hashtagsJson: [],
          emojisJson: [],
          hyperlinksJson: [],
          characterLimit: CHAR_LIMITS[platform as keyof typeof CHAR_LIMITS],
          status: "GENERATING",
        }).returning();

        // STAGE 1: Gemini generates initial content (with retry)
        const geminiResult = await retryWithBackoff(
          () => generateSocialPostWithGemini({
            prompt,
            platform,
            tone: tone || "professional",
            mood: mood || "informative",
            industry: industry || "general",
            characterLimit: CHAR_LIMITS[platform as keyof typeof CHAR_LIMITS],
            location: location || undefined,
            topic: topic || undefined,
            title: title || undefined,
            companyName: companyName || undefined,
          }),
          3,
          platform
        );

        console.log(`✅ Gemini generated ${platform} post (${geminiResult.caption.length} chars)${location ? ` for ${location}` : ''}`);

        // STAGE 2: GPT-4 enhances with hashtags, emojis, hyperlinks (with retry)
        const gptResult = await retryWithBackoff(
          () => enhanceSocialPostWithGPT({
            caption: geminiResult.caption,
            platform,
            tone: tone || "professional",
            userEmail: userEmail || "contact@example.com",
            location: location || undefined,
            topic: topic || undefined,
            industry: industry || undefined,
            landingPageUrl: landingPageUrl || undefined,
            companyName: companyName || undefined,
          }),
          3,
          platform
        );

        console.log(`✅ GPT-4 enhanced ${platform} post with ${gptResult.hashtags.length} hashtags`);

        // Build hashtags string for easy copy-paste
        const hashtagsString = gptResult.hashtags.map(h => h.tag).join(" ");

        // Update variant with final content and READY status
        await db
          .update(socialPostVariants)
          .set({
            caption: gptResult.caption,
            characterCount: gptResult.caption.length,
            hashtags: hashtagsString,
            hashtagsJson: gptResult.hashtags,
            emojisJson: gptResult.emojis || [],
            hyperlinksJson: gptResult.hyperlinks || [],
            status: "READY",
          })
          .where(eq(socialPostVariants.id, variant.id));

        // Log platform completion
        await db.insert(socialPostLogs).values({
          socialPostId,
          eventType: "PLATFORM_GENERATED",
          stage: "GPT4",
          severity: "info",
          message: `Generated ${platform} post (${gptResult.caption.length} chars, ${gptResult.hashtags.length} hashtags)`,
          payloadJson: { 
            platform, 
            characterCount: gptResult.caption.length,
            hashtagCount: gptResult.hashtags.length,
          },
        });

        return { platform, success: true, variantId: variant.id };
      } catch (error) {
        console.error(`❌ Failed to generate ${platform} post after all retries:`, error);
        const errorMessage = error instanceof Error ? error.message : String(error);

        // Mark variant as FAILED
        await db
          .update(socialPostVariants)
          .set({
            status: "FAILED",
            errorMessage: errorMessage.slice(0, 500),
          })
          .where(and(eq(socialPostVariants.socialPostId, socialPostId), eq(socialPostVariants.platform, platform)));

        // Log error
        await db.insert(errorLogs).values({
          errorType: "SOCIAL_VARIANT",
          errorMessage: `${platform} variant generation failed: ${errorMessage}`,
          stackTrace: error instanceof Error ? error.stack : undefined,
          severity: "error",
        });

        return { platform, success: false, error: errorMessage };
      }
    });

    // Wait for all platforms to complete
    const platformResults = await Promise.all(platformPromises);
    const successfulPlatforms = platformResults.filter(r => r.success);
    const failedPlatforms = platformResults.filter(r => !r.success);

    console.log(`✅ Generated ${successfulPlatforms.length}/${platforms.length} platform variants`);
    if (failedPlatforms.length > 0) {
      console.warn(`⚠️ Failed platforms: ${failedPlatforms.map(r => r.platform).join(", ")}`);
    }

    // STAGE 3: Generate images if requested
    if (includeImage) {
      const { generateSocialImages } = await import("./gemini-social-image-generator");
      
      const imageResults = await generateSocialImages({
        socialPostId,
        prompt,
        platforms,
        industry: industry || "general",
        companyName: companyName || undefined,
      });

      console.log(`🖼️ Generated ${imageResults.length} platform-specific images`);

      // Log image generation
      await db.insert(socialPostLogs).values({
        socialPostId,
        eventType: "IMAGE_GENERATED",
        stage: "IMAGE_GEN",
        severity: "info",
        message: `Generated ${imageResults.length} images for platforms: ${platforms.join(", ")}`,
        payloadJson: { imageCount: imageResults.length },
      });
    }

    // Update status to READY
    await db
      .update(socialPosts)
      .set({ status: "READY", updatedAt: new Date() })
      .where(eq(socialPosts.id, socialPostId));

    // Mark job as completed
    await db
      .update(socialPostJobs)
      .set({ status: "COMPLETED", completedAt: new Date() })
      .where(eq(socialPostJobs.jobId, job.id));

    // Log final completion
    await db.insert(socialPostLogs).values({
      socialPostId,
      eventType: "READY",
      stage: "COMPLETE",
      severity: "info",
      message: `Social post generation completed for ${platforms.length} platforms`,
      payloadJson: { 
        platforms, 
        variantsGenerated: platforms.length,
        imagesGenerated: includeImage ? platforms.length : 0,
      },
    });

    console.log(`✅ Social post ${socialPostId} generation completed successfully`);
  } catch (error) {
    console.error(`❌ Social post generation failed for ${socialPostId}:`, error);
    const errorMessage = error instanceof Error ? error.message : String(error);

    // Update status to FAILED
    await db
      .update(socialPosts)
      .set({ 
        status: "FAILED", 
        errorMessage: errorMessage.slice(0, 500),
        updatedAt: new Date() 
      })
      .where(eq(socialPosts.id, socialPostId));

    // Mark job as failed
    await db
      .update(socialPostJobs)
      .set({ 
        status: "FAILED", 
        errorMessage: errorMessage.slice(0, 500),
        completedAt: new Date() 
      })
      .where(eq(socialPostJobs.jobId, job.id));

    // Log to error_logs table
    await db.insert(errorLogs).values({
      errorType: "SOCIAL",
      errorMessage: `Social post generation failed: ${errorMessage}`,
      stackTrace: error instanceof Error ? error.stack : undefined,
      severity: "error",
    });

    // Log failure event
    await db.insert(socialPostLogs).values({
      socialPostId,
      eventType: "FAILED",
      stage: "ERROR",
      severity: "error",
      message: `Generation failed: ${errorMessage.slice(0, 500)}`,
      payloadJson: { 
        error: errorMessage,
        platforms,
      },
    });

    throw error;
  }
}
