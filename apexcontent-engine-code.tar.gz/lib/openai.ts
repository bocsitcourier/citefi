import { openaiClient, callOpenAI } from "./openai-client";
import { generateSchemas, embedSchemaInHTML, type SchemaGenerationResult } from "./schema-generator";
import { generateArticleBodyLinks, generateFAQLinks } from "./chatgpt-review/gpt4-hyperlinker";

export interface FinalizeContentParams {
  articleText: string;
  keywords: string[];
  targetUrl: string;
  imageUrls: string[];
  hashtags: string[];
  faq: Array<{ question: string; answer: string }>;
}

/**
 * Normalizes brand name capitalization in HTML content to ensure exact case preservation.
 * This prevents GPT-4 from inadvertently changing brand names like "Bocsit" to "bocsit".
 * 
 * @param html - The HTML content to normalize
 * @param brandName - The exact brand name with correct capitalization (e.g., "Bocsit")
 * @returns HTML with all brand name occurrences normalized to exact capitalization
 */
function normalizeBrandCapitalization(html: string, brandName: string): string {
  if (!brandName) return html;
  
  // Create a case-insensitive regex that matches the brand name
  // Use word boundaries to avoid partial matches
  const brandRegex = new RegExp(`\\b${brandName}\\b`, 'gi');
  
  // Replace all occurrences (regardless of case) with the exact capitalization
  return html.replace(brandRegex, brandName);
}

export async function finalizeContent(params: FinalizeContentParams, brandName?: string, timeoutMs?: number): Promise<string> {
  const { articleText, keywords, targetUrl, imageUrls, hashtags, faq } = params;

  const systemPrompt = `You are an expert HTML content formatter and strategic content specialist. Your task is to transform MARKDOWN-formatted article content into beautifully structured, publication-ready semantic HTML that builds trust, demonstrates expertise, and supports sales - while preserving the strategic value and AI-optimized structure of the content. You are an expert at converting markdown syntax (##, ###, *, -, 1., **bold**, etc.) into proper semantic HTML tags.

${brandName ? `\n**CRITICAL BRAND REQUIREMENT:** When formatting content, preserve the EXACT capitalization of the brand name "${brandName}". Do NOT change it to lowercase "${brandName.toLowerCase()}" or any other variation. The brand name MUST appear exactly as "${brandName}" throughout the content.` : ''}`;

  const userPrompt = `Transform the following MARKDOWN article into semantic, AI-optimized HTML with the following requirements:

ARTICLE TEXT (MARKDOWN FORMAT):
${articleText}

NOTE: Hyperlinks will be applied programmatically after HTML conversion, so do NOT add any <a> tags manually.

IMAGE URLS TO INSERT (strategically place these images throughout the article):
${imageUrls.length > 0 ? imageUrls.map((url, i) => `${i + 1}. ${url}`).join('\n') : 'No images provided - skip image placement'}

FAQ SECTION TO ADD BEFORE HASHTAGS:
${faq.length > 0 ? faq.map((item, i) => `Q${i + 1}: ${item.question}\nA${i + 1}: ${item.answer}`).join('\n\n') : 'No FAQ provided'}

HASHTAGS TO APPEND AT BOTTOM:
${hashtags.length > 0 ? hashtags.join(' ') : 'No hashtags provided'}

REQUIREMENTS:

1. **AI-Optimized Semantic HTML Structure (Convert Markdown to HTML)**:
   - Wrap entire content in <article> tag
   - Convert ## headers to <h2> tags
   - Convert ### headers to <h3> tags
   - Convert paragraphs (text separated by blank lines) to <p> tags
   - Convert markdown bullet lists (-, *) to <ul> and <li> tags
   - Convert markdown numbered lists (1., 2., 3.) to <ol> and <li> tags
   - Convert **bold** to <strong> tags
   - Convert *italic* to <em> tags
   - Add schema.org microdata where appropriate (itemscope, itemtype for Article)
   - Wrap summary/key takeaways sections in semantic containers

2. **Structured Data Enhancement**:
   - Identify FAQ-style content and wrap in appropriate markup
   - Mark up step-by-step instructions clearly with ordered lists
   - Preserve any comparison tables or structured information
   - Maintain clear content hierarchy for AI parsing

3. **NO Manual Hyperlinking**:
   - DO NOT add any <a> tags or hyperlinks
   - Hyperlinks will be applied programmatically after HTML generation
   - Focus on semantic HTML structure only

4. **Image Placement**:
   ${imageUrls.length > 0 ? `
   - Insert all ${imageUrls.length} images strategically throughout the article MAIN CONTENT ONLY
   - Place images between paragraphs at natural breaking points in the BODY of the article
   - Spread images evenly through the main content (approximately every 20-30% of body text)
   - **CRITICAL**: DO NOT place any images in the FAQ section - FAQ should be text-only
   - Images should only appear BEFORE the FAQ section begins
   - Use this format: <figure><img src="IMAGE_URL" alt="Simple descriptive alt text" class="article-image" /><figcaption>Simple, concise caption</figcaption></figure>
   - Image captions should be SIMPLE and CONCISE (e.g., "Company name worker performing task in location")
   - DO NOT include: camera angles (wide-angle, close-up), color descriptions, logo mentions, technical photography terms
   - DO include: company name (if applicable), worker/subject, action, location
   - Example: "Bocsit courier delivering specimens in Watertown MA" (NOT "Wide-angle shot of Bocsit courier in blue uniform with company logo...")
   ` : '- No images provided - skip image placement'}

5. **FAQ Section**:
   ${faq.length > 0 ? `
   - Add FAQ section before hashtags with this structure:
   <section class="faq-section">
     <h2>Frequently Asked Questions</h2>
     ${faq.map(item => `
     <div class="faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
       <h3 itemprop="name">${item.question}</h3>
       <div itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
         <p itemprop="text">${item.answer}</p>
       </div>
     </div>
     `).join('')}
   </section>
   ` : '- No FAQ provided - skip FAQ section'}

6. **Hashtags Section**:
   ${hashtags.length > 0 ? `- Add hashtags at the very end with CLICKABLE links to ${targetUrl}:
   <div class="hashtags">
     ${hashtags.map(tag => `<a href="${targetUrl}" target="_blank" rel="noopener noreferrer" class="hashtag-link">${tag}</a>`).join(' ')}
   </div>
   - Each hashtag must be wrapped in an <a> tag linking to ${targetUrl}
   - Add class="hashtag-link" to each hashtag link for styling` : '- No hashtags provided - skip hashtags section'}

6. **Content Quality & Strategic Value**:
   - Maintain the original article text exactly as written - preserve all strategic insights
   - Preserve BLUF (Bottom Line Up Front) structure for authority and clarity
   - Keep natural language question formats in headings
   - Maintain conversational tone and context bridges
   - Preserve all trust-building elements (data, examples, expert analysis)
   - Maintain sales-supporting language and decision-guidance
   - Preserve industry-specific terminology and deep expertise demonstrations
   - Ensure consistency in terminology and naming throughout
   - Verify no contradictory statements exist
   - Ensure all HTML is valid and properly closed
   - Only add HTML structure, hyperlinks, and images - do not modify the strategic content

Return ONLY the final HTML (no markdown, no explanations, no code blocks). Start with <article> and end with </article>.`;

  const model = process.env.GPT_ENHANCEMENT_MODEL || "gpt-4o-mini";
  
  const completion = await callOpenAI(
    (client) => client.chat.completions.create({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.3,
      max_tokens: 4000,
    }),
    `Finalize Content: ${articleText.substring(0, 50)}...`,
    timeoutMs // Pass timeout to callOpenAI wrapper (controls request timeout)
  );

  let finalHtml = completion.choices[0]?.message?.content || "";

  if (!finalHtml || finalHtml.length < 100) {
    throw new Error("GPT-4 failed to generate valid HTML content");
  }

  // **BRAND NORMALIZATION**: Ensure exact brand capitalization is preserved
  // This prevents GPT-4 from changing "Bocsit" → "bocsit" which triggers validation failures
  if (brandName) {
    finalHtml = normalizeBrandCapitalization(finalHtml, brandName);
    console.log(`🔒 Brand name normalization applied: "${brandName}"`);
  }

  return finalHtml.trim();
}

// ============================================================================
// ADVANCED GPT-4 ENHANCEMENT WITH INTERNAL LINKING
// ============================================================================

export interface GPTEnhancementResult {
  finalHtml: string;
  internalLinkSuggestions?: Array<{
    anchorText: string;
    targetArticleId?: number;
    context: string;
  }>;
  tokensUsed?: number;
  // TASK 6: JSON-LD schema metadata
  schemaGeneration?: SchemaGenerationResult;
}

export async function enhanceArticleWithGPT(
  articleText: string,
  seoTitle: string,
  metaDescription: string,
  keywords: string[],
  imageUrls: string[],
  semanticClusterId?: number,
  hyperlinks?: Array<{ phrase: string; url: string; type: string; anchorText: string }>,
  hashtags?: string[],
  faq?: Array<{ question: string; answer: string }>,
  targetUrl?: string,
  businessName?: string,
  geographicFocus?: string, // TASK 6: Location for schema
  hasStepByStepProcess?: boolean, // TASK 6: HowTo schema detection
  coveragePillar?: string, // TASK 6: Content cluster tracking
  eatScores?: { experience: number; expertise: number; authoritativeness: number; trustworthiness: number } // TASK 6: E-E-A-T for schema rating
): Promise<GPTEnhancementResult> {
  // Extract the actual target URL from hyperlinks if not provided directly
  const actualTargetUrl = targetUrl || hyperlinks?.[0]?.url || '#';
  
  // GPT-4 needs extended timeout for complex formatting (800-2000 word articles)
  // Default: 240s (4 minutes) - balances reliability with throughput
  const gptEnhancementTimeout = parseInt(process.env.GPT_ENHANCEMENT_TIMEOUT_MS || "240000");
  
  let finalHtml = await finalizeContent({
    articleText,
    keywords,
    targetUrl: actualTargetUrl, // Use actual target URL, not placeholder
    imageUrls,
    hashtags: hashtags || [],
    faq: faq || [],
  }, businessName, gptEnhancementTimeout);

  // ============================================================================
  // GPT-4 INTELLIGENT HYPERLINKING SYSTEM (GEO-Optimized)
  // ============================================================================
  // Two-phase strategy:
  // 1. Main Article Body: 5-7 contextual links (excludes H2/H3 headers)
  // 2. FAQ Section: 1 high-quality link per FAQ answer
  // ============================================================================
  
  try {
    console.log(`\n🔗 GPT-4 Intelligent Hyperlinking (GEO-Optimized)...`);
    
    // PHASE 1: Main Article Body Links (5-7 contextual, excludes headers)
    const articleBodyLinks = await generateArticleBodyLinks(
      finalHtml,
      actualTargetUrl,
      [], // TODO: Add cluster page URLs from semantic cluster
      geographicFocus
    );
    
    console.log(`  ✓ Identified ${articleBodyLinks.totalLinks} article body links`);
    
    // Apply article body links via regex replacement
    let totalBodyReplacements = 0;
    for (const link of articleBodyLinks.links) {
      const escapedPhrase = link.anchorText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`(?<!<[^>]*)(${escapedPhrase})(?![^<]*>)`, 'gi');
      
      const matches = finalHtml.match(regex);
      if (matches) {
        const linkHtml = `<a href="${link.destinationUrl}" target="_blank" rel="noopener noreferrer" class="text-primary hover:underline">${link.anchorText}</a>`;
        finalHtml = finalHtml.replace(regex, linkHtml);
        totalBodyReplacements += matches.length;
        console.log(`    • "${link.anchorText}" → ${link.destinationUrl} (${matches.length}x)`);
      }
    }
    
    // PHASE 2: FAQ Section Links (1 link per answer)
    const faqMatch = finalHtml.match(/<section class="faq-section">([\s\S]*?)<\/section>/);
    if (faqMatch) {
      console.log(`  🔍 Enhancing FAQ section with internal links...`);
      
      const faqHtml = faqMatch[0];
      const faqLinks = await generateFAQLinks(
        faqHtml,
        [actualTargetUrl], // TODO: Add cluster page URLs
        geographicFocus
      );
      
      console.log(`  ✓ Added ${faqLinks.totalLinks} FAQ links`);
      
      // Replace FAQ section with GPT-4 enhanced version
      finalHtml = finalHtml.replace(faqMatch[0], faqLinks.revisedFaqHtml);
    }
    
    console.log(`✅ GPT-4 Hyperlinking Complete - ${totalBodyReplacements} article links, ${faqMatch ? 'FAQ enhanced' : 'no FAQ found'}`);
    
  } catch (error) {
    console.error(`❌ GPT-4 hyperlinking failed:`, error);
    // Continue without intelligent linking if it fails
  }

  // ============================================================================
  // TASK 6: GENERATE COMPREHENSIVE JSON-LD SCHEMA
  // ============================================================================
  
  let schemaGeneration: SchemaGenerationResult | undefined;
  
  try {
    console.log(`\n📋 Generating JSON-LD schema (Task 6)...`);
    schemaGeneration = generateSchemas({
      title: seoTitle,
      description: metaDescription,
      content: articleText,
      url: actualTargetUrl,
      imageUrls,
      datePublished: new Date(),
      keywords,
      businessName,
      geographicFocus,
      faq,
      hasStepByStepProcess,
      coveragePillar,
      eatScores,
    });
    
    // Embed schema in HTML
    finalHtml = embedSchemaInHTML(finalHtml, schemaGeneration.scriptTag);
    console.log(`✅ JSON-LD schema embedded - ${schemaGeneration.schemaTypes.join(', ')}`);
  } catch (error) {
    console.error(`❌ Schema generation failed:`, error);
    // Continue without schema if generation fails
  }

  // **CRITICAL FIX**: Apply brand normalization AGAIN after hyperlinks
  // Hyperlinks might have reintroduced lowercase brand names in anchor text
  if (businessName) {
    finalHtml = normalizeBrandCapitalization(finalHtml, businessName);
    console.log(`🔒 Post-hyperlink brand normalization applied: "${businessName}"`);
  }

  const internalLinkSuggestions = semanticClusterId ? [
    {
      anchorText: keywords[0] || 'related topic',
      context: 'Suggested link for semantic cluster',
    }
  ] : undefined;

  return {
    finalHtml,
    internalLinkSuggestions,
    tokensUsed: articleText.length / 4,
    schemaGeneration, // TASK 6: Include schema metadata
  };
}
