import type PgBoss from "pg-boss";
import {
  getPgBoss,
  BATCH_GENERATION_QUEUE,
  ARTICLE_GENERATION_QUEUE,
  SOCIAL_POST_GENERATION_QUEUE,
  IMAGE_GENERATION_QUEUE,
  REFORMAT_QUEUE,
  SOCIAL_VIDEO_GENERATION_QUEUE,
  CLEANUP_QUEUE,
  type BatchJobData,
  type ArticleJobData,
  type SocialPostJobData,
  type ImageGenerationJobData,
  type ReformatJobData,
  type SocialVideoJobData,
  type CleanupJobData,
  addArticleJob,
  addSocialPostJob,
  addImageGenerationJob,
} from "./queue";
import { db } from "./db";
import { jobBatches, articles, seoLogs, socialPosts, socialPostLogs, errorLogs } from "@/shared/schema";
import { eq, and } from "drizzle-orm";
import { generateArticleWithGemini } from "./gemini";
import { enhanceArticleWithGPT } from "./openai";
import { validateBrandInOutput } from "./branding";

// Utility to truncate strings to max length (for database varchar constraints)
function truncate(str: string | null | undefined, maxLength: number): string | null {
  if (!str) return null;
  if (str.length <= maxLength) return str;
  return str.substring(0, maxLength - 3) + "...";
}

// Utility to enforce hard timeout on async operations
async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number,
  operation: string
): Promise<T> {
  let timeoutHandle: NodeJS.Timeout;
  
  const timeoutPromise = new Promise<T>((_, reject) => {
    timeoutHandle = setTimeout(
      () => reject(new Error(`${operation} exceeded hard timeout of ${timeoutMs / 1000}s`)),
      timeoutMs
    );
  });
  
  return Promise.race([
    promise.finally(() => clearTimeout(timeoutHandle)),
    timeoutPromise
  ]);
}

console.log("🔧 Initializing pg-boss workers...");

// ============================================================================
// WORKER REGISTRATION
// ============================================================================

export async function registerWorkers() {
  const boss = await getPgBoss();

  // ============================================================================
  // BATCH GENERATION WORKER
  // ============================================================================

  await boss.work<BatchJobData>(
    BATCH_GENERATION_QUEUE,
    { batchSize: 1 },
    async (jobs) => {
      for (const job of jobs) {
        console.log(`📦 Processing batch generation job ${job.id}`);
        const { batchId, selectedTitles, targetUrl, tone, wordCountMin, wordCountMax, geographicFocus, audience, competitorUrls, semanticClusterId, serpFeatureTarget, businessName, companyLogoUrl } = job.data;

      try {
        await db
          .update(jobBatches)
          .set({ 
            status: "RUNNING",
            numArticlesRequested: selectedTitles.length
          })
          .where(eq(jobBatches.id, batchId));

        // Log batch start event
        const { jobEvents } = await import("@/shared/schema");
        await db.insert(jobEvents).values({
          batchId,
          eventType: "BATCH_STARTED",
          stage: "ORCHESTRATION",
          severity: "info",
          message: `Batch started with ${selectedTitles.length} articles${serpFeatureTarget ? ` targeting ${serpFeatureTarget}` : ''}`,
          payloadJson: { selectedTitles, tone, wordCountMin, wordCountMax, serpFeatureTarget, semanticClusterId }
        });

        for (let i = 0; i < selectedTitles.length; i++) {
          const title = selectedTitles[i];
          
          const [article] = await db
            .insert(articles)
            .values({
              batchId,
              chosenTitle: title,
              articleStatus: "PENDING",
            })
            .returning();

          // Generate unique run ID for this article job
          const runId = crypto.randomUUID();
          
          await addArticleJob({
            articleId: article.id,
            batchId,
            runId, // UUID for duplicate detection and cache lookup
            title,
            targetUrl,
            tone,
            wordCountMin,
            wordCountMax,
            geographicFocus,
            audience,
            businessName,
            companyLogoUrl,
            competitorUrls,
            semanticClusterId,
            serpFeatureTarget,
          });
        }

        console.log(`✅ Batch ${batchId} spawned ${selectedTitles.length} article jobs - staying in RUNNING status`);
      } catch (error) {
        console.error(`❌ Batch generation failed for batch ${batchId}:`, error);
        const errorMessage = error instanceof Error ? error.message : String(error);
        
        // Log to error_logs table
        await db.insert(errorLogs).values({
          batchId,
          errorType: "QUEUE",
          errorMessage: `Batch orchestration failed: ${errorMessage}`,
          stackTrace: error instanceof Error ? error.stack : undefined,
          severity: "error",
        });
        
        // Log batch failure event
        const { jobEvents } = await import("@/shared/schema");
        await db.insert(jobEvents).values({
          batchId,
          eventType: "BATCH_FAILED",
          stage: "ORCHESTRATION",
          severity: "error",
          message: `Batch orchestration failed: ${errorMessage.slice(0, 500)}`,
          payloadJson: { 
            batchId,
            selectedTitlesCount: selectedTitles.length,
            stackTrace: error instanceof Error ? error.stack?.slice(0, 1000) : undefined
          }
        });
        
        try {
          await db
            .update(jobBatches)
            .set({ status: "FAILED" })
            .where(eq(jobBatches.id, batchId));
        } catch (dbError) {
          console.error(`❌ Failed to update batch status:`, dbError);
        }

        throw error;
      }
      }
    }
  );

  // ============================================================================
  // ARTICLE GENERATION WORKER
  // ============================================================================

  // CONFIGURABLE CONCURRENT PROCESSING
  // Workers match Gemini API rate limit for optimal resource usage
  // 10 workers to prevent overwhelming Gemini 30 RPM rate limit and causing 429 cascades
  const CONCURRENT_WORKERS = parseInt(process.env.ARTICLE_WORKER_CONCURRENCY || "10");
  
  for (let workerNum = 1; workerNum <= CONCURRENT_WORKERS; workerNum++) {
    boss.work<ArticleJobData>(
      ARTICLE_GENERATION_QUEUE,
      { 
        batchSize: 1,          // Each worker pulls 1 job at a time
      },
      async (jobs) => {
      // Process each job sequentially
      for (const job of jobs) {
        console.log(`📝 Processing article generation job ${job.id}`);
        const { articleId, batchId, runId, title, targetUrl, tone, wordCountMin, wordCountMax, geographicFocus, audience, competitorUrls, semanticClusterId, serpFeatureTarget, businessName, companyLogoUrl, customInstructions } = job.data;

      try {
        // STEP 1: Check article_runs for existing run records (duplicate detection & cache lookup)
        const { articleRuns } = await import("@/shared/schema");
        const [existingRun] = await db
          .select()
          .from(articleRuns)
          .where(and(
            eq(articleRuns.articleId, articleId),
            eq(articleRuns.runId, runId)
          ))
          .limit(1);
        
        // STEP 2: Handle existing runs based on status
        if (existingRun) {
          if (existingRun.status === 'completed' && existingRun.cachedGeminiOutput) {
            console.log(`♻️ CACHE HIT: Article ${articleId} run ${runId.slice(0,8)} already completed - reusing cached outputs`);
            // TODO: Short-circuit and mark article as complete using cached data
            // For now, log and continue normally (allows retries to proceed)
          } else if (existingRun.status === 'running') {
            // Update heartbeat timestamp to show this worker is actively processing
            // This allows legitimate pg-boss retries to resume work instead of getting stuck
            console.log(`🔄 RESUMING: Article ${articleId} run ${runId.slice(0,8)} continuing from previous attempt`);
            await db
              .update(articleRuns)
              .set({ startedAt: new Date() }) // Heartbeat update
              .where(eq(articleRuns.id, existingRun.id));
          } else if (existingRun.status === 'failed') {
            // Previous run failed - retry with fresh attempt
            console.log(`🔁 RETRY: Article ${articleId} run ${runId.slice(0,8)} retrying after previous failure`);
            await db
              .update(articleRuns)
              .set({ status: 'running', startedAt: new Date() })
              .where(eq(articleRuns.id, existingRun.id));
          }
        } else {
          // STEP 3: Create new run record
          await db.insert(articleRuns).values({
            articleId,
            runId,
            status: 'running',
            runType: customInstructions ? 'regeneration' : 'generation',
          });
          console.log(`🆕 Created article run record: article ${articleId}, runId ${runId.slice(0,8)}`);
        }
        
        // Check current article status to resume from previous stage if needed
        const [currentArticle] = await db
          .select()
          .from(articles)
          .where(eq(articles.id, articleId));
        
        let geminiResult: any;
        let skipGeminiUpdate = false;
        
        // RESUME LOGIC: Skip Gemini if already complete (preserve expensive work)
        if (currentArticle?.articleStatus === "GEMINI_COMPLETE" && currentArticle?.finalHtmlContent) {
          console.log(`♻️ RESUMING: Article ${articleId} already has Gemini content, skipping to ChatGPT review`);
          
          // Hydrate geminiResult from EXISTING saved metadata (reuse everything as-is)
          geminiResult = {
            rawContent: currentArticle.finalHtmlContent!,
            seoTitle: currentArticle.seoTitle!,
            metaDescription: currentArticle.metaDescription!,
            slug: currentArticle.slug!, // Always reuse existing slug - never regenerate
            keywords: (currentArticle.keywordsJson as string[]) || [],
            hashtags: (currentArticle.hashtagsJson as string[]) || [],
            faq: (currentArticle.faqJson as Array<{question: string, answer: string}>) || [],
            imagePrompts: (currentArticle.imagePromptsJson as string[]) || [],
            wordCount: currentArticle.wordCount || 0,
          };
          
          // Skip the database update since data already exists
          skipGeminiUpdate = true;
        } else {
          // Update status to IN_PROGRESS
          await db
            .update(articles)
            .set({ articleStatus: "IN_PROGRESS" })
            .where(eq(articles.id, articleId));

          // Log article generation start
          const { jobEvents } = await import("@/shared/schema");
          await db.insert(jobEvents).values({
            articleId,
            batchId,
            eventType: "ARTICLE_STARTED",
            stage: "GEMINI_GENERATION",
            severity: "info",
            message: `Generating article: "${title}"`,
            payloadJson: { title, wordCountMin, wordCountMax, tone, serpFeatureTarget }
          });

          // STAGE 1: Generate content with Gemini
          console.log(`🤖 Stage 1: Gemini generating article ${articleId}${businessName ? ` for ${businessName}` : ''}${customInstructions ? ' (with custom instructions)' : ''}...`);
          
          // HARD TIMEOUT: Force-fail if Gemini call hangs for >10 minutes
          const GEMINI_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes
          
          geminiResult = await withTimeout(
            generateArticleWithGemini(
              title,
              targetUrl,
              wordCountMin || 800,
              wordCountMax || 2000,
              tone || "professional",
              geographicFocus,
              audience,
              competitorUrls,
              serpFeatureTarget,
              businessName,
              customInstructions,
              companyLogoUrl,
              batchId // OPTIMIZATION: Pass batch ID for SEO cache lookup
            ),
            GEMINI_TIMEOUT_MS,
            `Gemini Generation (Article ${articleId})`
          );
          
          // CRITICAL: Validate image prompts for brand safety IMMEDIATELY after generation
          // Prevents generic placeholders like "company name" from entering the system
          if (geminiResult.imagePrompts && geminiResult.imagePrompts.length > 0 && businessName) {
            const { validateImagePromptBranding } = await import("@/lib/branding");
            const promptValidation = validateImagePromptBranding(
              geminiResult.imagePrompts,
              businessName
            );
            
            if (!promptValidation.valid) {
              const errorMsg = `Brand safety validation FAILED for article ${articleId}: ${promptValidation.errors.join('; ')}`;
              console.error(`❌ ${errorMsg}`);
              console.error(`📋 Invalid image prompts:`, geminiResult.imagePrompts);
              
              // Log detailed error event for debugging
              const { jobEvents } = await import("@/shared/schema");
              await db.insert(jobEvents).values({
                articleId,
                batchId,
                eventType: "ARTICLE_FAILED",
                stage: "GEMINI_GENERATION",
                severity: "error",
                message: errorMsg,
                payloadJson: { 
                  validationErrors: promptValidation.errors,
                  invalidPrompts: geminiResult.imagePrompts
                }
              });
              
              throw new Error(errorMsg);
            }
            
            console.log(`✅ Image prompt brand validation passed for article ${articleId}`);
          }
        }

        // Only update database if we generated new Gemini content (not resuming)
        if (!skipGeminiUpdate) {
          // Ensure slug uniqueness by appending article ID if duplicate
          let uniqueSlug = geminiResult.slug;
          const existingSlug = await db
            .select({ id: articles.id })
            .from(articles)
            .where(eq(articles.slug, geminiResult.slug))
            .limit(1);
          
          if (existingSlug.length > 0 && existingSlug[0].id !== articleId) {
            uniqueSlug = `${geminiResult.slug}-${articleId}`;
            console.log(`⚠️ Slug collision detected - using unique slug: ${uniqueSlug}`);
          }

          // Update with Gemini content
          await db
            .update(articles)
            .set({
              articleStatus: "GEMINI_COMPLETE",
              finalHtmlContent: geminiResult.rawContent,
              seoTitle: truncate(geminiResult.seoTitle, 60),
              metaDescription: truncate(geminiResult.metaDescription, 160),
              slug: uniqueSlug,
              keywordsJson: geminiResult.keywords || [],
              hashtagsJson: geminiResult.hashtags || [],
              faqJson: geminiResult.faq || [],
              imagePromptsJson: geminiResult.imagePrompts || [],
              wordCount: geminiResult.wordCount,
            })
            .where(eq(articles.id, articleId));
        } else {
          console.log(`✓ Using existing Gemini metadata - no database update needed`);
        }

        // STAGE 2: ChatGPT Review & Enrichment (ENABLED BY DEFAULT)
        // Set DISABLE_CHATGPT_REVIEW=true to skip for speed testing
        const disableChatGPTReview = process.env.DISABLE_CHATGPT_REVIEW === "true";
        let hyperlinksForGPT: any[] = [];
        
        if (disableChatGPTReview) {
          console.log(`⏩ Skipping Stage 2 ChatGPT review (manually disabled) - article ${articleId}`);
        } else {
          console.log(`🔍 Stage 2: ChatGPT reviewing article ${articleId}...`);
        
        if (!disableChatGPTReview) {
        try {
          // Import BATCHED ChatGPT review function (combines 4 API calls into 1)
          const { batchedChatGPTReview } = await import("@/lib/chatgpt-review/batched-review");

          // Execute batched ChatGPT enrichment with retry logic
          let lastError: Error | null = null;
          let batchedResult;
          
          for (let attempt = 1; attempt <= 3; attempt++) {
            try {
              console.log(`🔍 Batched ChatGPT review attempt ${attempt}/3 for article ${articleId}...`);
              
              // HARD TIMEOUT: Force-fail if ChatGPT review hangs
              // Allow time for 3 retry attempts (90s each) + retry delays (2s + 4s)
              // Total needed: 90s × 3 + 6s = 276s, so use 5 minutes to be safe
              const CHATGPT_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes
              
              // ULTRA-FAST: Run all 4 ChatGPT enrichment tasks in 1 API call
              // This reduces 4 API calls to 1 call (~75% reduction in API overhead)
              batchedResult = await withTimeout(
                batchedChatGPTReview({
                  content: geminiResult.rawContent,
                  title,
                  seoTitle: geminiResult.seoTitle,
                  metaDescription: geminiResult.metaDescription,
                  keywords: geminiResult.keywords || [],
                  targetUrl,
                  geographicFocus,
                  businessName,
                  audience,
                  competitorUrls,
                }),
                CHATGPT_TIMEOUT_MS,
                `ChatGPT Review (Article ${articleId})`
              );
              
              console.log(`✅ Batched ChatGPT review successful on attempt ${attempt}`);
              lastError = null;
              break;
            } catch (retryError) {
              lastError = retryError as Error;
              console.error(`❌ Batched ChatGPT review attempt ${attempt}/3 failed:`, retryError);
              
              if (attempt < 3) {
                const delayMs = Math.pow(2, attempt) * 1000; // Exponential backoff: 2s, 4s
                console.log(`⏳ Retrying in ${delayMs / 1000}s...`);
                await new Promise(resolve => setTimeout(resolve, delayMs));
              }
            }
          }
          
          // If all retries failed, STOP the pipeline but PRESERVE intermediate work
          if (lastError) {
            console.error(`❌ Batched ChatGPT review failed after 3 attempts for article ${articleId}`);
            console.log(`💾 Preserving Gemini content at GEMINI_COMPLETE status for recovery`);
            
            await db.insert(errorLogs).values({
              articleId,
              batchId,
              errorType: "CHATGPT_REVIEW",
              errorMessage: `Batched ChatGPT review failed after 3 retries (work preserved at GEMINI_COMPLETE for recovery): ${lastError.message}`,
              stackTrace: lastError.stack,
              severity: "error",
            });
            
            // LEAVE STATUS AT GEMINI_COMPLETE instead of FAILED
            // This preserves the Gemini content and allows manual review/regeneration
            // The article is still queryable and the work is not lost
            
            throw new Error(`Batched ChatGPT review failed after 3 attempts: ${lastError.message}`);
          }

          console.log(`✅ Batched ChatGPT review complete for article ${articleId} - SEO Score: ${batchedResult!.seo.seoScore}/100`);
          console.log(`  📎 Generated ${batchedResult!.hyperlinks.totalLinks} hyperlinks, ${batchedResult!.hashtags.totalCount} hashtags`);
          console.log(`  💰 Saved ${batchedResult!.tokenUsage.totalTokens} tokens (${batchedResult!.tokenUsage.promptTokens}p + ${batchedResult!.tokenUsage.completionTokens}c)`);
          
          // Store hyperlinks for GPT-4 to apply
          hyperlinksForGPT = batchedResult!.hyperlinks.keywords || [];
          
          // Build meta enrichment object
          const metaEnrichment = {
            socialSnippets: batchedResult!.socialSnippets,
            hashtags: batchedResult!.hashtags.hashtags,
            hashtagCategories: batchedResult!.hashtags.categories,
            readability: batchedResult!.seo.readability,
            localSignals: batchedResult!.seo.localSignals,
          };

          await db
            .update(articles)
            .set({
              articleStatus: "CHATGPT_REVIEWED",
              seoScore: batchedResult!.seo.seoScore,
              hyperlinkedKeywordsJson: batchedResult!.hyperlinks.keywords || [],
              metaEnrichment,
            })
            .where(eq(articles.id, articleId));
        } catch (reviewError) {
          console.error(`❌ CRITICAL: ChatGPT review error for article ${articleId}:`, reviewError);
          console.log(`💾 Preserving Gemini content at GEMINI_COMPLETE status for recovery`);
          
          // Log detailed error for diagnosis
          await db.insert(errorLogs).values({
            articleId,
            batchId,
            errorType: "CHATGPT_REVIEW_CRITICAL",
            errorMessage: `ChatGPT review failed (work preserved at GEMINI_COMPLETE for recovery): ${reviewError instanceof Error ? reviewError.message : String(reviewError)}`,
            stackTrace: reviewError instanceof Error ? reviewError.stack : undefined,
            severity: "error",
          });
          
          // LEAVE STATUS AT GEMINI_COMPLETE instead of FAILED
          // This preserves the Gemini content and allows manual review/regeneration
          // The article is still queryable and the work is not lost
          
          throw reviewError; // Re-throw to stop article processing
        }
        } // End if (!disableChatGPTReview)
        } // End if (!disableChatGPTReview) else block

        // STAGE 3: GPT-4 Enhancement (ENABLED BY DEFAULT)
        // Set DISABLE_GPT_ENHANCEMENT=true to skip for speed testing
        const disableGPTEnhancement = process.env.DISABLE_GPT_ENHANCEMENT === "true";
        
        if (disableGPTEnhancement) {
          console.log(`⚡ Skipping Stage 3 GPT-4 enhancement (manually disabled) - article ${articleId}`);
          
          // Use raw Gemini content directly for blazing fast generation
          await db
            .update(articles)
            .set({
              articleStatus: "COMPLETE",
              finalHtmlContent: `<article>${geminiResult.rawContent.replace(/\n/g, '<br>')}</article>`,
            })
            .where(eq(articles.id, articleId));
          
          console.log(`⚡ Article ${articleId} completed in SPEED MODE (Gemini-only)`);
        } else {
          console.log(`🎨 Stage 3: GPT-4 enhancing article ${articleId}...`);
          
          // Note: Images will be generated in background AFTER article completes
          // So we pass empty array to GPT-4 for now (images added post-publication)
          const imageUrls: string[] = [];
          
          // HARD TIMEOUT: Force-fail if GPT-4 call hangs for >20 minutes
          // (Normal: 3 min timeout × 5 retries = ~16 min max)
          const GPT_TIMEOUT_MS = 20 * 60 * 1000; // 20 minutes
          
          const gptResult = await withTimeout(
            enhanceArticleWithGPT(
              geminiResult.rawContent,
              geminiResult.seoTitle,
              geminiResult.metaDescription,
              geminiResult.keywords,
              imageUrls,
              semanticClusterId,
              hyperlinksForGPT,
              geminiResult.hashtags || [],
              geminiResult.faq || [],
              targetUrl,  // Pass actual target URL to GPT-4
              businessName // Pass business name for brand normalization
            ),
            GPT_TIMEOUT_MS,
            `GPT-4 Enhancement (Article ${articleId})`
          );

          // Mark as GPT4_ENHANCED before final completion
          await db
            .update(articles)
            .set({
              articleStatus: "GPT4_ENHANCED",
              finalHtmlContent: gptResult.finalHtml,
            })
            .where(eq(articles.id, articleId));

          console.log(`✨ Article ${articleId} GPT-4 enhancement complete`);
          
          // CRITICAL VALIDATION: Verify enrichment data before marking COMPLETE
          // NOTE: Images are generated in BACKGROUND after COMPLETE, so we don't validate them here
          const [verifyArticle] = await db
            .select()
            .from(articles)
            .where(eq(articles.id, articleId));
          
          const hasKeywords = Array.isArray(verifyArticle.keywordsJson) && verifyArticle.keywordsJson.length > 0;
          const hasHashtags = Array.isArray(verifyArticle.hashtagsJson) && verifyArticle.hashtagsJson.length > 0;
          const hasFaq = Array.isArray(verifyArticle.faqJson) && verifyArticle.faqJson.length > 0;
          const hasHyperlinks = Array.isArray(verifyArticle.hyperlinkedKeywordsJson) && verifyArticle.hyperlinkedKeywordsJson.length > 0;
          
          if (!hasKeywords || !hasHashtags || !hasFaq || !hasHyperlinks) {
            const missing = [];
            if (!hasKeywords) missing.push("keywords");
            if (!hasHashtags) missing.push("hashtags");
            if (!hasFaq) missing.push("FAQ");
            if (!hasHyperlinks) missing.push("hyperlinks");
            
            console.error(`❌ Article ${articleId} missing required enrichment: ${missing.join(", ")}`);
            
            await db
              .update(articles)
              .set({ articleStatus: "FAILED" })
              .where(eq(articles.id, articleId));
            
            await db.insert(errorLogs).values({
              articleId,
              batchId,
              errorType: "VALIDATION",
              errorMessage: `Article missing required enrichment fields: ${missing.join(", ")}`,
              severity: "error",
            });
            
            throw new Error(`Article ${articleId} failed validation - missing: ${missing.join(", ")}`);
          }
          
          // BRAND NAME VALIDATION: Ensure correct brand spelling in output
          if (businessName) {
            const brandValidation = validateBrandInOutput(gptResult.finalHtml, businessName);
            if (!brandValidation.valid) {
              console.error(`❌ Article ${articleId} failed brand validation:`, brandValidation.errors);
              
              await db
                .update(articles)
                .set({ articleStatus: "FAILED" })
                .where(eq(articles.id, articleId));
              
              await db.insert(errorLogs).values({
                articleId,
                batchId,
                errorType: "BRAND_VALIDATION",
                errorMessage: `Brand name validation failed: ${brandValidation.errors.join(", ")}`,
                severity: "error",
              });
              
              throw new Error(`Article ${articleId} failed brand validation: ${brandValidation.errors.join(", ")}`);
            }
            console.log(`✅ Article ${articleId} brand name validation passed: "${businessName}"`);
          }
          
          // Mark article as COMPLETE only after validation passes
          await db
            .update(articles)
            .set({
              articleStatus: "COMPLETE",
            })
            .where(eq(articles.id, articleId));
          
          console.log(`✅ Article ${articleId} validation passed - marked COMPLETE`);
        }

        // STAGE 4: Queue Images for Background Generation (non-blocking)
        // Images generate AFTER article completes, so they don't block the next article
        console.log(`🔍 DEBUG: Checking image prompts for article ${articleId}...`);
        console.log(`   geminiResult.imagePrompts exists: ${!!geminiResult.imagePrompts}`);
        console.log(`   geminiResult.imagePrompts length: ${geminiResult.imagePrompts?.length || 0}`);
        
        if (geminiResult.imagePrompts && geminiResult.imagePrompts.length > 0) {
          console.log(`📸 Queueing ${geminiResult.imagePrompts.length} images for background generation (article ${articleId})${businessName ? ` with brand lock: "${businessName}"` : ''}`);
          
          // SECONDARY VALIDATION: Soft check for legacy data or any prompts that slipped through
          // Prevents generating images from invalid prompts without failing the article
          let shouldQueueImages = true;
          if (businessName) {
            const { validateImagePromptBranding } = await import("@/lib/branding");
            const promptValidation = validateImagePromptBranding(
              geminiResult.imagePrompts,
              businessName
            );
            
            if (!promptValidation.valid) {
              console.warn(`⚠️ Secondary brand validation failed - skipping image generation for article ${articleId}`);
              console.warn(`   Validation errors:`, promptValidation.errors);
              console.warn(`   Invalid prompts:`, geminiResult.imagePrompts);
              
              // Log warning event for observability (not a hard failure)
              const { jobEvents: jobEventsSchema } = await import("@/shared/schema");
              await db.insert(jobEventsSchema).values({
                articleId,
                batchId,
                eventType: "IMAGE_VALIDATION_FAILED",
                stage: "IMAGE_GENERATION",
                severity: "warning",
                message: `Skipped image generation due to brand validation: ${promptValidation.errors.join('; ')}`,
                payloadJson: {
                  validationErrors: promptValidation.errors,
                  invalidPrompts: geminiResult.imagePrompts
                }
              });
              
              // Log to error_logs for operator visibility
              await db.insert(errorLogs).values({
                articleId,
                batchId,
                errorType: "IMAGE_BRAND_VALIDATION",
                errorMessage: `Image prompts contain brand safety violations: ${promptValidation.errors.join('; ')}`,
                severity: "warning", // warning level - article is still complete
              });
              
              shouldQueueImages = false;
            }
          }
          
          if (shouldQueueImages) {
            try {
              await addImageGenerationJob({
                articleId,
                batchId,
                imagePrompts: geminiResult.imagePrompts,
                businessName, // Pass business name for brand lock in images
              });
              console.log(`✅ Image generation job queued - article ${articleId} can continue`);
            } catch (imageError) {
              console.warn(`⚠️ Failed to queue images for article ${articleId}:`, imageError);
              // Continue even if image queueing fails
            }
          }
        } else {
          console.warn(`⚠️ No image prompts found for article ${articleId} - skipping image generation`);
        }

        console.log(`✅ Article ${articleId} completed successfully`);

        // Log completion event
        const { jobEvents: jobEventsSchema } = await import("@/shared/schema");
        await db.insert(jobEventsSchema).values({
          articleId,
          batchId,
          eventType: "ARTICLE_COMPLETED",
          stage: "GPT_ENHANCEMENT",
          severity: "info",
          message: `Article completed: "${title}"`,
          payloadJson: { articleId, wordCount: geminiResult.wordCount }
        });

        // Check if all articles in batch are complete
        await checkBatchCompletion(batchId);

      } catch (error) {
        console.error(`❌ Article generation failed for article ${articleId}:`, error);
        const errorMessage = error instanceof Error ? error.message : String(error);
        
        // Log to error_logs table
        await db.insert(errorLogs).values({
          articleId,
          batchId,
          errorType: "GENERATION",
          errorMessage: `Article generation failed: ${errorMessage}`,
          stackTrace: error instanceof Error ? error.stack : undefined,
          severity: "error",
        });
        
        // Log article failure event
        const { jobEvents } = await import("@/shared/schema");
        await db.insert(jobEvents).values({
          articleId,
          batchId,
          eventType: "ARTICLE_FAILED",
          stage: "GENERATION",
          severity: "error",
          message: `Article failed: ${errorMessage.slice(0, 500)}`,
          payloadJson: { 
            articleId,
            title,
            stackTrace: error instanceof Error ? error.stack?.slice(0, 1000) : undefined
          }
        });
        
        try {
          await db
            .update(articles)
            .set({ articleStatus: "FAILED" })
            .where(eq(articles.id, articleId));
        } catch (dbError) {
          console.error(`❌ Failed to update article status:`, dbError);
        }

        // Check batch completion even on failure
        await checkBatchCompletion(batchId);

        throw error;
      }
      }  // Close for loop over jobs
    }
    );
  }  // Close for loop over workers
  
  const geminiRateLimit = parseInt(process.env.GEMINI_RATE_LIMIT || "10");
  console.log(`✅ Registered ${CONCURRENT_WORKERS} concurrent article workers (Gemini API: ${geminiRateLimit} req/min throttle)`);
  console.log(`   💡 Architecture: ${CONCURRENT_WORKERS} workers match ${geminiRateLimit} API slots for optimal concurrency`);

  // ============================================================================
  // STANDALONE SOCIAL POST GENERATION WORKER (Phase 10)
  // ============================================================================

  try {
    console.log(`🎭 Registering social post generation worker for queue: "${SOCIAL_POST_GENERATION_QUEUE}"`);
    
    const { processSocialPostGeneration } = await import("./social-worker");
    
    await boss.work<SocialPostJobData>(
      SOCIAL_POST_GENERATION_QUEUE,
      { batchSize: 1 },
      async (jobs) => {
        for (const job of jobs) {
          await processSocialPostGeneration(job);
        }
      }
    );
    
    console.log(`✅ Social post generation worker registered successfully`);
  } catch (error) {
    console.error(`❌ CRITICAL: Failed to register social post worker:`, error);
    throw error; // Re-throw to see the error
  }

  // ============================================================================
  // IMAGE GENERATION WORKER (Background, concurrent)
  // ============================================================================
  
  // LIGHTNING-FAST: 10 concurrent image generation workers
  // Each job generates 5 images in parallel (10 concurrent DALL-E calls per job)
  const IMAGE_WORKERS = 10;
  
  try {
    console.log(`🖼️ Registering ${IMAGE_WORKERS} image generation workers for queue: "${IMAGE_GENERATION_QUEUE}"`);
    
    for (let workerNum = 1; workerNum <= IMAGE_WORKERS; workerNum++) {
      await boss.work<ImageGenerationJobData>(
        IMAGE_GENERATION_QUEUE,
        { 
          batchSize: 1,  // Each worker processes 1 article's images at a time
        },
        async (jobs) => {
          for (const job of jobs) {
            // Skip test jobs created during queue initialization
            if ((job.data as any).__test || (job.data as any).__queue_initialization) {
              console.log(`⏭️ Skipping test job ${job.id} (queue initialization)`);
              continue;
            }

            console.log(`🖼️ [Worker ${workerNum}] Processing image generation job ${job.id}`);
            const { articleId, batchId, imagePrompts, businessName: jobBusinessName } = job.data;

            try {
              // CRITICAL: Validate businessName from job data first (new batches)
              let businessName = jobBusinessName;
              
              // Fallback to batch for legacy jobs (backwards compatibility)
              if (!businessName || businessName.trim().length === 0) {
                const [batch] = await db
                  .select()
                  .from(jobBatches)
                  .where(eq(jobBatches.id, batchId));
                
                businessName = batch?.businessName;
              }
              
              // HARD STOP: Fail if still no businessName (prevents AI hallucination)
              if (!businessName || businessName.trim().length === 0) {
                const errorMsg = `CRITICAL: Cannot generate images for article ${articleId} without businessName. This prevents AI hallucination of company names.`;
                console.error(`❌ [Worker ${workerNum}] ${errorMsg}`);
                throw new Error(errorMsg);
              }
              
              console.log(`🔒 [Worker ${workerNum}] Brand lock active: "${businessName}"`);
              
              const { generateImagesForArticle } = await import("@/lib/gemini-image-generator");
              const imageResults = await generateImagesForArticle(articleId, imagePrompts, businessName);
              console.log(`✅ [Worker ${workerNum}] Generated ${imageResults.length}/${imagePrompts.length} images for article ${articleId}`);
            } catch (error) {
              console.error(`❌ [Worker ${workerNum}] Image generation failed for article ${articleId}:`, error);
              // Don't throw - images are optional, article is already complete
            }
          }
        }
      );
    }
    
    console.log(`✅ Registered ${IMAGE_WORKERS} image generation workers successfully`);
  } catch (error) {
    console.error(`❌ CRITICAL: Failed to register image generation workers:`, error);
    throw error; // Re-throw to see the error
  }

  // ============================================================================
  // REFORMAT WORKER (Background HTML formatting)
  // ============================================================================

  try {
    console.log(`🔄 Registering reformat worker for queue: "${REFORMAT_QUEUE}"`);
    
    await boss.work<ReformatJobData>(
      REFORMAT_QUEUE,
      { batchSize: 1 },
      async (jobs) => {
        for (const job of jobs) {
          console.log(`🔄 Processing reformat job ${job.id} for article ${job.data.articleId}`);
          const { articleId } = job.data;

          try {
            // Get the article
            const [article] = await db
              .select()
              .from(articles)
              .where(eq(articles.id, articleId));

            if (!article) {
              console.error(`❌ Article ${articleId} not found - skipping reformat`);
              continue;
            }

            // Get the batch to retrieve targetUrl and businessName
            const [batch] = await db
              .select()
              .from(jobBatches)
              .where(eq(jobBatches.id, article.batchId));
            
            const targetUrl = batch?.targetUrl || "";
            const businessName = batch?.businessName || undefined;
            const rawContent = article.finalHtmlContent || "";
            const hyperlinks = Array.isArray(article.hyperlinkedKeywordsJson) 
              ? article.hyperlinkedKeywordsJson 
              : [];

            // Re-run GPT-4 formatting with brand normalization
            const gptResult = await enhanceArticleWithGPT(
              rawContent,
              article.seoTitle || "",
              article.metaDescription || "",
              Array.isArray(article.keywordsJson) ? article.keywordsJson : [],
              [], // Images handled separately
              undefined, // No semantic cluster
              hyperlinks,
              Array.isArray(article.hashtagsJson) ? article.hashtagsJson : [],
              Array.isArray(article.faqJson) ? article.faqJson : [],
              targetUrl,
              businessName // Pass business name for brand normalization
            );

            // Update article with formatted HTML
            await db
              .update(articles)
              .set({
                finalHtmlContent: gptResult.finalHtml,
                articleStatus: "GPT4_ENHANCED",
              })
              .where(eq(articles.id, articleId));

            console.log(`✅ Article ${articleId} reformatted successfully`);

          } catch (error) {
            console.error(`❌ Reformat failed for article ${articleId}:`, error);
            // Don't throw - let user retry if needed
          }
        }
      }
    );
    
    console.log(`✅ Reformat worker registered successfully`);
  } catch (error) {
    console.error(`❌ CRITICAL: Failed to register reformat worker:`, error);
    throw error;
  }

  // ============================================================================
  // SOCIAL VIDEO GENERATION WORKER
  // ============================================================================

  try {
    console.log(`🎬 Registering social video generation worker...`);
    
    // Health check: Verify FFmpeg and ffprobe binaries are available and executable
    const { getFFmpegPath } = await import("./social-video-compositor");
    const fs = await import("fs/promises");
    
    const ffmpegPath = getFFmpegPath();
    if (!ffmpegPath) {
      throw new Error("❌ FATAL: FFmpeg binary not found. Video generation will fail. Please ensure ffmpeg-static is installed.");
    }
    
    // Verify FFmpeg is executable
    try {
      await fs.access(ffmpegPath, (await import("fs")).constants.X_OK);
      console.log(`✅ FFmpeg health check passed: ${ffmpegPath}`);
    } catch (accessError) {
      throw new Error(`❌ FATAL: FFmpeg binary found but not executable: ${ffmpegPath}. Check file permissions.`);
    }
    
    // Verify ffprobe is available and executable
    const ffprobePackage = await import("@ffprobe-installer/ffprobe");
    const ffprobePath = ffprobePackage.default?.path;
    if (!ffprobePath) {
      throw new Error("❌ FATAL: ffprobe binary not found. Video duration detection will fail. Please ensure @ffprobe-installer/ffprobe is installed.");
    }
    
    try {
      await fs.access(ffprobePath, (await import("fs")).constants.X_OK);
      console.log(`✅ ffprobe health check passed: ${ffprobePath}`);
    } catch (accessError) {
      throw new Error(`❌ FATAL: ffprobe binary found but not executable: ${ffprobePath}. Check file permissions.`);
    }
    
    // CRITICAL FIX: Explicitly create the queue to ensure partition table exists
    console.log(`📋 Creating queue partition for: ${SOCIAL_VIDEO_GENERATION_QUEUE}`);
    await boss.createQueue(SOCIAL_VIDEO_GENERATION_QUEUE);
    console.log(`✅ Queue partition created/verified`);

    await boss.work<SocialVideoJobData>(
      SOCIAL_VIDEO_GENERATION_QUEUE,
      { batchSize: 1 }, // Process one video at a time (resource intensive)
      async (jobs) => {
        for (const job of jobs) {
          console.log(`🎬 Processing social video generation job ${job.id}`);
          const { socialPostId, platform } = job.data;

          try {
            const { generateSocialVideo } = await import("./social-video-generator");
            
            const result = await generateSocialVideo({
              socialPostId,
              platform: platform || "tiktok",
            });

            console.log(`✅ Video generated successfully for social post ${socialPostId}`);
            console.log(`   URL: ${result.videoUrl}`);
            console.log(`   Duration: ${result.duration}s`);
            console.log(`   Resolution: ${result.resolution}`);
          } catch (error) {
            console.error(`❌ Video generation failed for social post ${socialPostId}:`, error);
            throw error; // Let pg-boss handle retries
          }
        }
      }
    );

    console.log(`✅ Social video generation worker registered successfully`);
  } catch (error) {
    console.error(`❌ CRITICAL: Failed to register social video worker:`, error);
    throw error;
  }

  // ============================================================================
  // CLEANUP WORKER
  // ============================================================================

  console.log("🧹 Registering cleanup worker for queue:", CLEANUP_QUEUE);
  
  try {
    await boss.work<CleanupJobData>(
      CLEANUP_QUEUE,
      { batchSize: 1, teamConcurrency: 1 }, // Process one cleanup job at a time
      async (jobs) => {
        for (const job of jobs) {
          console.log(`🧹 Processing cleanup job ${job.id}: type=${job.data.jobType}, dryRun=${job.data.dryRun || false}`);
          
          try {
            await runCleanupJob(job.data);
            console.log(`✅ Cleanup job ${job.id} completed successfully`);
          } catch (error) {
            console.error(`❌ Cleanup job ${job.id} failed:`, error);
            throw error; // Re-throw for pg-boss retry logic
          }
        }
      }
    );
    
    console.log("✅ Cleanup worker registered successfully");
  } catch (error) {
    console.error("❌ CRITICAL: Failed to register cleanup worker:", error);
    throw error;
  }

  console.log("✅ Workers registered - pg-boss will process jobs automatically");
}

// ============================================================================
// CLEANUP EXECUTION
// ============================================================================

async function runCleanupJob(data: CleanupJobData) {
  const { cleanupJobs, activityLogs } = await import("@/shared/schema");
  const { getEffectiveRetention } = await import("./cleanup-policy");
  const { sub } = await import("date-fns");
  const { and, isNotNull, lt, eq, inArray } = await import("drizzle-orm");
  
  // Create cleanup job record
  const [jobRecord] = await db
    .insert(cleanupJobs)
    .values({
      jobType: data.jobType,
      status: "RUNNING",
      dryRun: data.dryRun ? 1 : 0,
    })
    .returning();

  try {
    // Get effective retention policy
    const policy = await getEffectiveRetention(
      data.teamId,
      data.jobType,
      data.retentionDays
    );

    console.log(`📋 Cleanup policy: ${policy.retentionDays} days (source: ${policy.source})`);

    // Route to appropriate cleanup handler
    let result: { itemsProcessed: number; itemsDeleted: number };

    switch (data.jobType) {
      case "media":
        result = await cleanupMedia(data, policy.retentionDays);
        break;
      case "logs":
        result = await cleanupLogs(data, policy.retentionDays);
        break;
      case "orphans":
        result = await cleanupOrphans(data, policy.retentionDays);
        break;
      case "sessions":
        result = await cleanupSessions(data, policy.retentionDays);
        break;
      default:
        throw new Error(`Unknown cleanup type: ${data.jobType}`);
    }

    const { itemsProcessed, itemsDeleted } = result;

    // Update job record as complete
    await db
      .update(cleanupJobs)
      .set({
        status: "COMPLETE",
        itemsProcessed,
        itemsDeleted,
        completedAt: new Date(),
      })
      .where(eq(cleanupJobs.id, jobRecord.id));

    // Log to activity logs for operational visibility
    await db
      .insert(activityLogs)
      .values({
        userId: null, // System-initiated
        teamId: data.teamId || null,
        action: "cleanup_executed",
        resource: "cleanup",
        targetType: data.jobType,
        details: {
          jobId: jobRecord.id,
          jobType: data.jobType,
          dryRun: data.dryRun || false,
          itemsProcessed,
          itemsDeleted,
          retentionDays: policy.retentionDays,
          policySource: policy.source,
        },
        severity: "info",
      })
      .catch((err) => {
        console.error("Failed to log cleanup to activity logs:", err);
        // Don't fail the job if activity logging fails
      });

    console.log(`✅ Cleanup ${data.jobType}: processed=${itemsProcessed}, deleted=${itemsDeleted}, dryRun=${data.dryRun || false}`);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    
    // Update job record as failed
    await db
      .update(cleanupJobs)
      .set({
        status: "FAILED",
        errorMessage,
        completedAt: new Date(),
      })
      .where(eq(cleanupJobs.id, jobRecord.id));

    // Log failure to activity logs
    await db
      .insert(activityLogs)
      .values({
        userId: null, // System-initiated
        teamId: data.teamId || null,
        action: "cleanup_failed",
        resource: "cleanup",
        targetType: data.jobType,
        details: {
          jobId: jobRecord.id,
          jobType: data.jobType,
          error: errorMessage,
        },
        severity: "error",
      })
      .catch((err) => {
        console.error("Failed to log cleanup failure to activity logs:", err);
        // Don't cascade failures
      });

    throw error;
  }
}

async function cleanupMedia(data: CleanupJobData, retentionDays: number) {
  const { articleAssets } = await import("@/shared/schema");
  const { sub } = await import("date-fns");
  const { and, isNotNull, lt, eq, inArray } = await import("drizzle-orm");
  
  const cutoffDate = sub(new Date(), { days: retentionDays });
  const BATCH_SIZE = 100;
  const MAX_PER_RUN = 500;
  
  let itemsProcessed = 0;
  let itemsDeleted = 0;
  let consecutiveEmptyBatches = 0;

  while (itemsProcessed < MAX_PER_RUN) {
    // Build query conditions
    const conditions = [
      isNotNull(articleAssets.deletedAt),
      lt(articleAssets.deletedAt, cutoffDate),
    ];
    
    if (data.teamId) {
      conditions.push(eq(articleAssets.teamId, data.teamId));
    }

    // Fetch batch
    const batch = await db
      .select()
      .from(articleAssets)
      .where(and(...conditions))
      .limit(BATCH_SIZE);

    if (batch.length === 0) {
      consecutiveEmptyBatches++;
      if (consecutiveEmptyBatches >= 2) break; // Safety: break if no records found twice
      continue;
    }

    consecutiveEmptyBatches = 0;
    itemsProcessed += batch.length;

    if (!data.dryRun) {
      // Delete from database (object storage cleanup TBD)
      const deletedCount = await db
        .delete(articleAssets)
        .where(inArray(articleAssets.id, batch.map(b => b.id)));
      
      // Safety: If delete returns 0, break to prevent infinite loop
      if (deletedCount === 0 || (Array.isArray(deletedCount) && deletedCount.length === 0)) {
        console.warn(`⚠️ Media cleanup: delete returned 0 rows for batch of ${batch.length}, breaking to prevent infinite loop`);
        break;
      }
      
      itemsDeleted += batch.length;
    }
  }

  return { itemsProcessed, itemsDeleted };
}

async function cleanupLogs(data: CleanupJobData, retentionDays: number) {
  const { activityLogs } = await import("@/shared/schema");
  const { sub } = await import("date-fns");
  const { and, lt, eq, inArray } = await import("drizzle-orm");
  
  const cutoffDate = sub(new Date(), { days: retentionDays });
  const BATCH_SIZE = 100;
  const MAX_PER_RUN = 500;
  
  let itemsProcessed = 0;
  let itemsDeleted = 0;
  let consecutiveEmptyBatches = 0;

  while (itemsProcessed < MAX_PER_RUN) {
    const conditions = [lt(activityLogs.timestamp, cutoffDate)];
    
    if (data.teamId) {
      conditions.push(eq(activityLogs.teamId, data.teamId));
    }

    const batch = await db
      .select()
      .from(activityLogs)
      .where(and(...conditions))
      .limit(BATCH_SIZE);

    if (batch.length === 0) {
      consecutiveEmptyBatches++;
      if (consecutiveEmptyBatches >= 2) break; // Safety: break if no records found twice
      continue;
    }

    consecutiveEmptyBatches = 0;
    itemsProcessed += batch.length;

    if (!data.dryRun) {
      const deletedCount = await db
        .delete(activityLogs)
        .where(inArray(activityLogs.id, batch.map(b => b.id)));
      
      // Safety: If delete returns 0, break to prevent infinite loop
      if (deletedCount === 0 || (Array.isArray(deletedCount) && deletedCount.length === 0)) {
        console.warn(`⚠️ Log cleanup: delete returned 0 rows for batch of ${batch.length}, breaking to prevent infinite loop`);
        break;
      }
      
      itemsDeleted += batch.length;
    }
  }

  return { itemsProcessed, itemsDeleted };
}

async function cleanupOrphans(data: CleanupJobData, retentionDays: number) {
  const { articleAssets, articles } = await import("@/shared/schema");
  const { sub } = await import("date-fns");
  const { and, lt, eq, inArray, isNull, sql } = await import("drizzle-orm");
  
  const cutoffDate = sub(new Date(), { days: retentionDays });
  const BATCH_SIZE = 100;
  const MAX_PER_RUN = 500;
  
  let itemsProcessed = 0;
  let itemsDeleted = 0;
  let consecutiveEmptyBatches = 0;

  while (itemsProcessed < MAX_PER_RUN) {
    // Use LEFT JOIN to find orphaned assets efficiently
    // This avoids loading all article IDs into memory
    const conditions = [lt(articleAssets.createdAt, cutoffDate)];
    
    if (data.teamId) {
      conditions.push(eq(articleAssets.teamId, data.teamId));
    }

    const batch = await db
      .select({
        id: articleAssets.id,
        articleId: articleAssets.articleId,
      })
      .from(articleAssets)
      .leftJoin(articles, eq(articleAssets.articleId, articles.id))
      .where(and(...conditions, isNull(articles.id))) // article doesn't exist
      .limit(BATCH_SIZE);

    if (batch.length === 0) {
      consecutiveEmptyBatches++;
      if (consecutiveEmptyBatches >= 2) break; // Safety: break if no records found twice
      continue;
    }

    consecutiveEmptyBatches = 0;
    itemsProcessed += batch.length;

    if (!data.dryRun) {
      const deletedCount = await db
        .delete(articleAssets)
        .where(inArray(articleAssets.id, batch.map(b => b.id)));
      
      // Safety: If delete returns 0, break to prevent infinite loop
      if (deletedCount === 0 || (Array.isArray(deletedCount) && deletedCount.length === 0)) {
        console.warn(`⚠️ Orphan cleanup: delete returned 0 rows for batch of ${batch.length}, breaking to prevent infinite loop`);
        break;
      }
      
      itemsDeleted += batch.length;
    }
  }

  return { itemsProcessed, itemsDeleted };
}

async function cleanupSessions(data: CleanupJobData, retentionDays: number) {
  const { sessions } = await import("@/shared/schema");
  const { sub } = await import("date-fns");
  const { and, or, lt, eq, inArray } = await import("drizzle-orm");
  
  const cutoffDate = sub(new Date(), { days: retentionDays });
  const BATCH_SIZE = 100;
  const MAX_PER_RUN = 500;
  
  let itemsProcessed = 0;
  let itemsDeleted = 0;
  let consecutiveEmptyBatches = 0;

  while (itemsProcessed < MAX_PER_RUN) {
    // Find inactive or expired sessions
    const batch = await db
      .select()
      .from(sessions)
      .where(
        or(
          and(eq(sessions.isActive, 0), lt(sessions.lastActivityAt, cutoffDate)),
          lt(sessions.expiresAt, new Date())
        )
      )
      .limit(BATCH_SIZE);

    if (batch.length === 0) {
      consecutiveEmptyBatches++;
      if (consecutiveEmptyBatches >= 2) break; // Safety: break if no records found twice
      continue;
    }

    consecutiveEmptyBatches = 0;
    itemsProcessed += batch.length;

    if (!data.dryRun) {
      const deletedCount = await db
        .delete(sessions)
        .where(inArray(sessions.id, batch.map(b => b.id)));
      
      // Safety: If delete returns 0, break to prevent infinite loop
      if (deletedCount === 0 || (Array.isArray(deletedCount) && deletedCount.length === 0)) {
        console.warn(`⚠️ Session cleanup: delete returned 0 rows for batch of ${batch.length}, breaking to prevent infinite loop`);
        break;
      }
      
      itemsDeleted += batch.length;
    }
  }

  return { itemsProcessed, itemsDeleted };
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

async function checkBatchCompletion(batchId: number) {
  const batchArticles = await db
    .select()
    .from(articles)
    .where(eq(articles.batchId, batchId));

  const totalArticles = batchArticles.length;
  const completedArticles = batchArticles.filter(a => a.articleStatus === "COMPLETE").length;
  const failedArticles = batchArticles.filter(a => a.articleStatus === "FAILED").length;
  const pendingArticles = batchArticles.filter(a => a.articleStatus === "PENDING").length;
  const inProgressArticles = batchArticles.filter(a => 
    a.articleStatus === "IN_PROGRESS" || 
    a.articleStatus === "GEMINI_COMPLETE" ||
    a.articleStatus === "CHATGPT_REVIEWED" ||
    a.articleStatus === "GPT4_ENHANCED"
  ).length;

  console.log(`📊 Batch ${batchId} progress: ${completedArticles}/${totalArticles} complete, ${failedArticles} failed, ${inProgressArticles} in progress, ${pendingArticles} pending`);

  // SAFETY CHECK: Only mark batch as terminal if NO articles are pending or in progress
  const nonTerminalArticles = pendingArticles + inProgressArticles;
  
  if (nonTerminalArticles > 0) {
    console.log(`⏳ Batch ${batchId} still has ${nonTerminalArticles} unfinished articles - keeping RUNNING status`);
    // Ensure batch is in RUNNING state if it has unfinished articles
    await db
      .update(jobBatches)
      .set({ status: "RUNNING", completedAt: null })
      .where(eq(jobBatches.id, batchId));
    return;
  }

  // All articles are in terminal state (COMPLETE or FAILED)
  if (completedArticles + failedArticles === totalArticles) {
    let finalStatus: string;
    if (completedArticles === totalArticles) {
      finalStatus = "COMPLETE";
    } else if (completedArticles > 0) {
      finalStatus = "PARTIAL_COMPLETE";
    } else {
      finalStatus = "FAILED";
    }

    await db
      .update(jobBatches)
      .set({ 
        status: finalStatus,
        completedAt: new Date()
      })
      .where(eq(jobBatches.id, batchId));

    console.log(`✅ Batch ${batchId} finished with status: ${finalStatus}`);

    // Log batch completion event
    const { jobEvents } = await import("@/shared/schema");
    await db.insert(jobEvents).values({
      batchId,
      eventType: finalStatus === "COMPLETE" ? "BATCH_COMPLETED" : "BATCH_PARTIAL_COMPLETE",
      stage: "ORCHESTRATION",
      severity: finalStatus === "COMPLETE" ? "info" : "warning",
      message: `Batch finished: ${completedArticles} completed, ${failedArticles} failed`,
      payloadJson: { totalArticles, completedArticles, failedArticles }
    });
  }
}
