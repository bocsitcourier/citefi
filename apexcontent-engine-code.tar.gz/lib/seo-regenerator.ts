import { GoogleGenAI } from "@google/genai";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY is required");
}

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// ============================================================================
// INDIVIDUAL SEO FIELD REGENERATORS
// ============================================================================

export async function regenerateSeoTitle(
  currentTitle: string,
  articleContent: string
): Promise<string> {
  // Ensure articleContent is a valid string
  const safeContent = (articleContent || currentTitle || "").substring(0, 2000);
  
  const prompt = `You are an SEO title expert. Based on the article content below, generate ONE compelling SEO title that:
- Is 50-60 characters (max 70)
- Includes primary keyword naturally
- Creates urgency or curiosity
- Is more engaging than the current title

CURRENT TITLE: ${currentTitle}

ARTICLE CONTENT (first 500 words):
${safeContent}

Return ONLY the new SEO title, nothing else.`;

  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });
  
  const responseText = result.response?.text() || result.text || "";
  const newTitle = responseText.trim();
  if (!newTitle || newTitle.length < 10) {
    throw new Error("Failed to generate valid SEO title");
  }
  return newTitle;
}

export async function regenerateMetaDescription(
  currentMeta: string,
  articleContent: string
): Promise<string> {
  // Ensure articleContent is a valid string
  const safeContent = (articleContent || currentMeta || "").substring(0, 2000);
  
  const prompt = `You are an SEO meta description expert. Based on the article content below, generate ONE compelling meta description that:
- Is 140-160 characters (max 160)
- Includes primary keyword
- Has a clear call-to-action or value proposition
- Is more engaging than the current meta description

CURRENT META: ${currentMeta}

ARTICLE CONTENT (first 500 words):
${safeContent}

Return ONLY the new meta description, nothing else.`;

  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });
  
  const responseText = result.response?.text() || result.text || "";
  const newMeta = responseText.trim();
  if (!newMeta || newMeta.length < 50) {
    throw new Error("Failed to generate valid meta description");
  }
  return newMeta;
}

export async function regenerateSlug(
  currentSlug: string,
  title: string
): Promise<string> {
  const prompt = `You are an SEO slug expert. Based on the title below, generate ONE URL-friendly slug that:
- Is lowercase with hyphens (no spaces, no special characters)
- Is 3-7 words maximum
- Includes primary keyword
- Is concise and descriptive

CURRENT SLUG: ${currentSlug}
TITLE: ${title}

Return ONLY the new slug (e.g., "best-seo-tips-2025"), nothing else.`;

  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });
  
  const responseText = result.response?.text() || result.text || "";
  const rawSlug = responseText.trim();
  const newSlug = rawSlug
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '');
  if (!newSlug || newSlug.length < 3) {
    throw new Error("Failed to generate valid slug");
  }
  return newSlug;
}

export async function regenerateKeywords(
  currentKeywords: string[],
  articleContent: string
): Promise<string[]> {
  // Ensure articleContent is a valid string
  const safeContent = (articleContent || "").substring(0, 2000);
  
  const prompt = `You are an SEO keyword expert. Based on the article content below, generate 5 LONG-PHRASE keywords (3-5 words each) that:
- Are natural language phrases people actually search
- Have high search intent
- Are different from current keywords
- Mix question-based and topic-based phrases

CURRENT KEYWORDS: ${currentKeywords.join(", ")}

ARTICLE CONTENT (first 500 words):
${safeContent}

Return ONLY 5 keywords as a JSON array, nothing else.
Example format: ["how to improve seo rankings", "best seo tools for beginners", "local seo optimization guide", "content marketing strategies 2025", "search engine optimization tips"]`;

  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });
  
  const responseText = result.response?.text() || result.text || "";
  const rawText = responseText.trim();
  
  // Extract JSON array from response
  const jsonMatch = rawText.match(/\[.*\]/s);
  if (jsonMatch) {
    const keywords = JSON.parse(jsonMatch[0]);
    return keywords.slice(0, 5);
  }
  
  throw new Error("Failed to generate keywords");
}

export async function regenerateHashtags(
  currentHashtags: string[],
  articleContent: string,
  geographicFocus?: string
): Promise<string[]> {
  // Ensure articleContent is a valid string
  const safeContent = (articleContent || "").substring(0, 2000);
  const geoContext = geographicFocus ? `\nGEOGRAPHIC FOCUS: ${geographicFocus}` : '';

  const prompt = `You are a social media hashtag expert. Based on the article content below, generate 10-15 hashtags that:
- Mix SEO, geographic, brand, and trending tags
- Are relevant to the content
- Include location-specific tags if geographic focus is provided
- Are different from current hashtags
- Use proper hashtag format (#LowerCamelCase)

CURRENT HASHTAGS: ${currentHashtags.join(", ")}${geoContext}

ARTICLE CONTENT (first 500 words):
${safeContent}

Return ONLY hashtags as a JSON array, nothing else.
Example format: ["#SEO", "#ContentMarketing", "#DigitalMarketing", "#SEOTips", "#MarketingStrategy"]`;

  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });
  
  const responseText = result.response?.text() || result.text || "";
  const rawText = responseText.trim();
  
  // Extract JSON array from response
  const jsonMatch = rawText.match(/\[.*\]/s);
  if (jsonMatch) {
    const hashtags = JSON.parse(jsonMatch[0]);
    return hashtags.slice(0, 15);
  }
  
  throw new Error("Failed to generate hashtags");
}

export async function regenerateFAQ(
  currentFaq: Array<{ question: string; answer: string }>,
  articleContent: string
): Promise<Array<{ question: string; answer: string }>> {
  // Ensure articleContent is a valid string
  const safeContent = (articleContent || "").substring(0, 2000);
  
  const prompt = `You are an FAQ expert. Based on the article content below, generate 5-8 FAQ items that:
- Address common questions related to the topic
- Have concise, helpful answers (50-100 words each)
- Are different from current FAQ items
- Cover different aspects of the topic

CURRENT FAQ:
${currentFaq.map((item, i) => `Q${i + 1}: ${item.question}\nA${i + 1}: ${item.answer}`).join('\n\n')}

ARTICLE CONTENT (first 500 words):
${safeContent}

Return ONLY a JSON array of FAQ objects with "question" and "answer" fields, nothing else.
Example format: [{"question": "What is SEO?", "answer": "SEO stands for Search Engine Optimization..."}]`;

  const result = await genAI.models.generateContent({
    model: "gemini-2.0-flash",
    contents: [{ role: "user", parts: [{ text: prompt }] }],
  });
  
  const responseText = result.response?.text() || result.text || "";
  const rawText = responseText.trim();
  
  // Extract JSON array from response
  const jsonMatch = rawText.match(/\[.*\]/s);
  if (jsonMatch) {
    const faq = JSON.parse(jsonMatch[0]);
    return faq.slice(0, 8);
  }
  
  throw new Error("Failed to generate FAQ");
}
