# ApexContent Engine - Advanced Local SEO Powerhouse

## Overview
ApexContent Engine is a dual-AI SEO content generation platform that creates scalable, high-quality, SEO-optimized content. It uses a 4-stage asynchronous pipeline with Gemini 2.5 Pro/Flash and GPT-4/4o-mini. The platform emphasizes mandatory location-based SEO in all generated content, integrating deep local intelligence (ZIP codes, neighborhoods, regulations, authority entities). It incorporates E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) signals and answer-first optimization for AI citations, following methodologies from Lily Ray, Mike King, and Kevin Indig.

## User Preferences
- **Communication style:** Simple, everyday language
- **Development approach:** Get core working first, then expand features incrementally
- **Lesson learned:** First app failed because it was too ambitious - prioritize working functionality

## System Architecture

### System Design Choices
- **Tech Stack:** Next.js 14 (App Router), TypeScript, React 18, shadcn/ui + Tailwind CSS, PostgreSQL (Neon serverless), Drizzle ORM, pg-boss, Gemini 2.5 Pro/Flash, GPT-4/GPT-4o-mini, TanStack Query, React Hook Form with Zod, Replit Object Storage.
- **Database Schema:** Supports multi-tenant team management, geo-specific features, and admin management with tables for users, teams, job batches, articles, and various supporting entities. Includes UUID public identifiers and soft delete support.
- **Multi-Tenant Team Architecture:** Implements team and team member tables with circular FK relationships, team isolation for content, and performance optimizations via indexing.
- **Activity Logging System:** API endpoints for activity logs with team filtering, pagination, and severity filters, tracking team_id and target public_id.
- **Cleanup Infrastructure:** A `CleanupPolicy` service with hierarchical policy resolution and a `pg-boss` worker for item batch processing. Includes safety mechanisms, activity logging, and API endpoints for management, with dry-run support.
- **Mandatory Location-Based SEO:** All content generation inherently integrates location metadata.
- **UI/UX:** Frontend built with Next.js, shadcn/ui, and Tailwind CSS, featuring real-time monitoring, content export, media library, and robust error handling.
- **Brand Lock System:** A three-layer system prevents company name misspellings in text and images through AI prompt enforcement, runtime validation, and user regeneration flows.
- **Logo Upload & Brand-Aware Image Generation:** Allows users to upload logos for branding integration into AI image prompts.
- **Batch SEO Caching:** Reduces API calls by generating and reusing shared SEO context (location analysis, competitor insights, semantic clusters) per batch.
- **Cache Reuse Short-Circuit:** Prevents redundant API calls during article regeneration by restoring from cached pipeline outputs.
- **Run ID Tracking & Cache System:** Uses a `run_id` for each article generation attempt to prevent duplicate jobs and enable intelligent cache reuse.
- **OpenAI Rate Limiting & Batching:** Manages OpenAI API concurrency with `p-limit` and exponential backoff, batching API calls.
- **Admin Management System:** Comprehensive admin panel with user invite system, role management, force logout, and detailed action logging.
- **Team Isolation & API Security:** Enhanced authentication middleware loads `teamId` from the `team_members` table, protecting all high-risk mutation routes and core content routes with defense-in-depth patterns. All social_posts endpoints enforce `requireTeamMember()` with `teamId` filtering for complete team isolation. Admin endpoints protected with `requireAdmin()`. Legacy unauthenticated routes removed (November 2025).
- **Database Cascade Delete Integrity:** All 4 delete flows (batch delete, article delete, social post single delete, social post batch delete) implement uniform hard delete with proper cascade order: socialPostLogs → socialPostVariants → socialPostAssets → socialPostJobs → socialPosts. Prevents foreign key violations and orphaned child records. All deletions verify team ownership before execution (November 2025).
- **Batch Generation Integrity & Error Handling:** Comprehensive fix of batch submission flow (November 2025). Title-pool endpoint corrected to use `userId` from `requireTeamMember()` helper (was incorrectly destructuring `id`), resolving 404 authentication failures. Batch-submit validates job queue success before returning HTTP 200, preventing silent failures when `pg-boss` returns null. Reddit research cache preserved through `generationParams` merge (not overwrite) during submission. Playwright graceful degradation handles missing system dependencies. Legacy batches backfilled with correct `teamId` for team isolation enforcement. All endpoints audited for correct `requireTeamMember()` usage.
- **Comprehensive JSON-LD Schema Generation:** A `Schema Generator` module supports 6 schema.org types (Article, FAQPage, HowTo, LocalBusiness, BreadcrumbList, Organization) with citation optimization, E-E-A-T ratings, and coverage metrics including a citation score.
- **Content Cluster Architecture:** A `Cluster Service` creates a pillar + spoke structure for topical authority using 8 subtopic categories and 7 coverage pillars. It tracks cluster planning, article linkage, health metrics, and link intelligence, with robust location parsing.
- **Advanced Local SEO Transformation:** Full pipeline enhancement with E-E-A-T signals, AI citation optimization, and content cluster architecture. Includes database extensions, enhanced batch SEO cache with deep local intelligence, upgraded title generation, and article drafting methodologies integrating Lily Ray, Mike King, and Kevin Indig's approaches.
- **Phase 1 Intent Consolidation (v3.0):** Two-phase Reddit research workflow transforms raw discussions into structured AEO-compliant outlines. Phase 1 uses Gemini to analyze Reddit data, cluster into 5-7 H2 question themes with authentic experience proof, map to coverage pillars, and output structured JSON. Article drafting (Phase 2) consumes pre-optimized H2 questions with integrated E-E-A-T proof, ensuring answer-first content structure.
- **Strict GEO/AEO Formatting Constraints (v3.1):** Enhanced AI prompts enforce strict answer-first optimization for maximum AI citation potential. Stage 2 (Gemini) requires 40-60 word direct answers immediately after each H2/H3, explicit author entity integration for E-E-A-T signals, and coverage pillar mapping. Stage 3 (GPT-4o-mini) validates meta title (strict 60 char limit) and meta description (strict 160 char limit) with automatic scoring penalties for violations (-5 points per 5 chars over title limit, -5 points per 10 chars over description limit). All prompts align with GEO methodology from Lily Ray, Mike King, and Kevin Indig.
- **GPT-4 Intelligent Hyperlinking System:** Two-phase GEO-optimized linking strategy replaces simple regex replacement. Article body receives 5-7 contextual links (excludes H2/H3 headers) via GPT-4 analysis. FAQ section receives 1 high-quality link per answer. Both phases use GPT-4 to ensure natural placement and semantic relevance (December 2025).
- **Reddit JSON API + Expert Discovery:** Upgraded from Playwright web scraping to direct Reddit JSON API for faster, more reliable intent research. Added Expert Discovery module using Brave Search API to identify SMEs and thought leaders, improving E-E-A-T signals. Both modules integrate into batch SEO cache generation (December 2025).
- **GPT-4 Content Audit System:** Retroactive quality analysis tool for existing articles using GPT-4 to score content on 6 AEO/GEO compliance criteria: (1) Direct Answer Compliance (40-60 word answers after H2/H3), (2) Entity Salience (location, business, authority entities), (3) E-E-A-T Signals (Experience, Expertise, Authoritativeness, Trust), (4) Passage Quality (answer-first structure, citation-readiness), (5) Schema Readiness (JSON-LD compatibility), (6) GEO Optimization (local signals, AI citation potential). Each criterion scored 1-5 with detailed rationale and suggested edits. Includes Internal Link Discovery module that uses GPT-4 to identify 3-5 contextual linking opportunities from team's article library with relevance scoring. Accessible via SEO Tools page with team-scoped article selection. Enables optimization of existing content archives using latest GEO/AEO insights (November 2025).

### 4-Stage Content Pipeline
1.  **Title Pool Generation:** Gemini generates 50 location-optimized SEO titles with answer-first framing and coverage pillar mapping across 7 categories.
2.  **Content & Image Generation:** Gemini produces 800-2000 word articles using a composite methodology that integrates deep local intelligence.
3.  **ChatGPT Review & Enrichment:** GPT-4o-mini performs batched review including SEO analysis, hashtag generation, social snippets, and advanced content validation (answer-first structure, E-E-A-T signals, local signal density, passage quality, schema readiness, evidence density).
4.  **GPT-4 Enhancement & Intelligent Hyperlinking:** GPT-4 applies two-phase GEO-optimized hyperlinking (5-7 contextual article body links excluding headers, 1 link per FAQ answer), integrates images, embeds comprehensive JSON-LD schema markup (6 types) with AI citation optimization, validates content quality, and finalizes with semantic HTML.

### Modules
- **Multi-City Title Generation:** Generates location-specific title pools for multiple cities.
- **Standalone Social Media Module:** Generates platform-optimized business content with mandatory location-based SEO/GEO targeting using a dual-AI pipeline, platform-specific voice strategies, and advanced local SEO prompts.
- **AI Podcast Module:** Creates conversational two-voice podcast summaries of articles using AI-powered script generation and OpenAI TTS.
- **60-Second Social Video Module:** Generates landscape marketing videos with a 5-scene AI-scripted structure, cinematic images, OpenAI TTS voiceover, and dynamic caption timing, including logo overlay.

### Job Queue Architecture
- `pg-boss` manages `title-pool`, `batch-generation`, and `article-generation` queues.
- Configured for Tier 1 concurrent processing with dynamic rate limiting, including robust features for stuck job prevention, auto-retry, and resume logic.

## External Dependencies

### Active Integrations
-   **Google AI:** Gemini 2.5 Pro, Gemini 2.5 Flash Image, Gemini 2.0 Flash
-   **OpenAI:** GPT-4, GPT-4o-mini, DALL-E 3, OpenAI TTS
-   **Neon Database:** PostgreSQL hosting
-   **pg-boss:** Job queueing system
-   **Replit Object Storage:** Permanent media storage