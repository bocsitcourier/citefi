#!/usr/bin/env python3
"""
Super Bowl Ad Script Generator from Articles
Generates 8-segment scripts optimized for Veo 8-second generation
"""

import json
import re
from datetime import datetime
from typing import List, Dict, Optional
import random

class SuperBowlScriptGenerator:
    """
    Transforms boring articles into award-winning Super Bowl ad scripts
    """
    
    def __init__(self):
        self.humor_styles = [
            "absurdist",
            "self-aware",
            "celebrity-surprise",
            "dramatic-mundane",
            "meta-commercial",
            "unexpected-twist"
        ]
        
        self.transition_types = [
            "match-cut",
            "whip-pan",
            "freeze-frame",
            "crash-zoom",
            "jump-cut",
            "cross-fade"
        ]
        
    def extract_key_points(self, article_text: str) -> Dict:
        """
        Extract the essential elements from an article
        """
        # Simple extraction - in production, use NLP
        key_points = {
            "main_topic": self._extract_main_topic(article_text),
            "problem": self._extract_problem(article_text),
            "solution": self._extract_solution(article_text),
            "key_stat": self._extract_key_stat(article_text),
            "target_audience": self._identify_audience(article_text)
        }
        return key_points
    
    def _extract_main_topic(self, text: str) -> str:
        """Extract the main topic/product from article"""
        # Look for repeated nouns (simplified)
        words = text.split()
        word_freq = {}
        for word in words:
            if len(word) > 4:  # Skip small words
                word_freq[word.lower()] = word_freq.get(word.lower(), 0) + 1
        
        # Get most frequent substantial word
        if word_freq:
            return max(word_freq, key=word_freq.get)
        return "product"
    
    def _extract_problem(self, text: str) -> str:
        """Find the problem the article discusses"""
        problem_indicators = ["problem", "issue", "challenge", "difficult", "struggle", "pain point"]
        
        sentences = text.split('.')
        for sentence in sentences:
            if any(indicator in sentence.lower() for indicator in problem_indicators):
                return sentence.strip()
        
        return "everyday frustrations"
    
    def _extract_solution(self, text: str) -> str:
        """Find the solution mentioned"""
        solution_indicators = ["solution", "solve", "fix", "answer", "revolutionary", "breakthrough"]
        
        sentences = text.split('.')
        for sentence in sentences:
            if any(indicator in sentence.lower() for indicator in solution_indicators):
                return sentence.strip()
        
        return "our innovative product"
    
    def _extract_key_stat(self, text: str) -> str:
        """Extract any impressive statistic"""
        # Look for percentages or numbers
        import re
        
        patterns = [
            r'\d+%',
            r'\d+x faster',
            r'\$[\d,]+',
            r'\d+ out of \d+',
            r'\d+ million',
            r'\d+ billion'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group()
        
        return "97% effective"  # Default impressive stat
    
    def _identify_audience(self, text: str) -> str:
        """Identify target audience from article"""
        audiences = {
            "millennials": ["app", "social", "tech", "startup"],
            "parents": ["family", "kids", "children", "safety"],
            "professionals": ["business", "office", "productivity", "career"],
            "everyone": ["everyone", "anyone", "all", "universal"]
        }
        
        text_lower = text.lower()
        for audience, keywords in audiences.items():
            if any(keyword in text_lower for keyword in keywords):
                return audience
        
        return "everyone"
    
    def generate_superbowl_script(self, article_text: str, brand_name: str, 
                                 humor_style: Optional[str] = None) -> Dict:
        """
        Generate a complete 60-second Super Bowl ad script in 8 segments
        """
        
        if not humor_style:
            humor_style = random.choice(self.humor_styles)
        
        key_points = self.extract_key_points(article_text)
        
        # Generate script based on humor style
        if humor_style == "absurdist":
            segments = self._generate_absurdist_script(key_points, brand_name)
        elif humor_style == "self-aware":
            segments = self._generate_meta_script(key_points, brand_name)
        elif humor_style == "celebrity-surprise":
            segments = self._generate_celebrity_script(key_points, brand_name)
        elif humor_style == "dramatic-mundane":
            segments = self._generate_dramatic_mundane_script(key_points, brand_name)
        else:
            segments = self._generate_unexpected_twist_script(key_points, brand_name)
        
        return {
            "brand": brand_name,
            "style": humor_style,
            "duration": "60 seconds",
            "segments": segments,
            "key_points": key_points,
            "generated_at": datetime.now().isoformat()
        }
    
    def _generate_absurdist_script(self, key_points: Dict, brand: str) -> List[Dict]:
        """
        Generate script in absurdist humor style (Old Spice style)
        """
        topic = key_points['main_topic']
        problem = key_points['problem']
        stat = key_points['key_stat']
        
        segments = [
            {
                "segment": 1,
                "duration": "0:00-0:08",
                "scene": f"Normal person using {topic}, suddenly everything explodes into diamonds",
                "dialogue": f"Your {topic} is weak. Mine is made of eagles.",
                "veo_prompt": f"Person holding {topic}, sudden explosion of sparkling diamonds and eagles flying out, surreal lighting, slow motion",
                "music": "Epic orchestral hit",
                "transition": "Diamonds form into muscular figure"
            },
            {
                "segment": 2,
                "duration": "0:07-0:15",
                "scene": "Muscular figure riding a bear through an office",
                "dialogue": f"While you struggle with {problem}, I'm solving world hunger.",
                "veo_prompt": "Muscular person in suit riding grizzly bear through modern office, papers flying, slow motion, workers diving away",
                "music": "Dramatic drums",
                "transition": "Bear transforms into motorcycle"
            },
            {
                "segment": 3,
                "duration": "0:14-0:22",
                "scene": "Motorcycle flies through space, lands on moon",
                "dialogue": f"Statistics show {stat}. I am the statistic.",
                "veo_prompt": "Motorcycle launching into space, rider planting flag on moon with brand logo, Earth in background",
                "music": "Space odyssey theme",
                "transition": "Moon explodes into confetti"
            },
            {
                "segment": 4,
                "duration": "0:21-0:29",
                "scene": "Confetti becomes tiny versions of product raining down",
                "dialogue": "Look at your product. Now look at mine. Sadly, yours isn't mine.",
                "veo_prompt": "Thousands of miniature products raining from sky like confetti, people catching them joyfully, golden hour lighting",
                "music": "Whimsical percussion",
                "transition": "Products form giant statue"
            },
            {
                "segment": 5,
                "duration": "0:28-0:36",
                "scene": "Giant product statue comes alive, high-fives city",
                "dialogue": f"With {brand}, you're not just buying {topic}. You're buying confidence.",
                "veo_prompt": "50-foot tall product statue coming alive, giving high-fives to skyscrapers, birds forming heart shape",
                "music": "Triumphant fanfare",
                "transition": "Statue shrinks to normal size"
            },
            {
                "segment": 6,
                "duration": "0:35-0:43",
                "scene": "Product in elegant setting, surrounded by admirers",
                "dialogue": "Even my grandmother wants this. She's a shark.",
                "veo_prompt": "Product on pedestal, literal shark wearing glasses and pearl necklace admiring it, fancy gallery setting",
                "music": "Sophisticated jazz",
                "transition": "Shark winks at camera"
            },
            {
                "segment": 7,
                "duration": "0:42-0:50",
                "scene": "Entire cast dancing in synchronized celebration",
                "dialogue": f"Join the {stat} who've already ascended.",
                "veo_prompt": "Bear, shark, eagles, and people in synchronized dance number, product multiplying in background, confetti cannons",
                "music": "Dance beat drops",
                "transition": "Everyone freezes mid-dance"
            },
            {
                "segment": 8,
                "duration": "0:49-0:60",
                "scene": "Original person from segment 1, now transformed",
                "dialogue": f"{brand}. Because normal is a sandwich. And you're a dragon.",
                "veo_prompt": "Original person now confident, riding dragon made of product logos, winking at camera, epic sunset, logo reveal",
                "music": "Signature jingle with whistle",
                "transition": "Fade to logo with sparkle"
            }
        ]
        
        return segments
    
    def _generate_meta_script(self, key_points: Dict, brand: str) -> List[Dict]:
        """
        Generate self-aware/meta commercial script (Deadpool style)
        """
        topic = key_points['main_topic']
        
        segments = [
            {
                "segment": 1,
                "duration": "0:00-0:08",
                "scene": "Actor breaks fourth wall immediately",
                "dialogue": "Oh hi! Yeah, this is a commercial. For 60 seconds. Buckle up.",
                "veo_prompt": "Actor in living room looking directly at camera, shrugging, TV remote in hand, casual clothes",
                "music": "Record scratch, then silence",
                "transition": "Walks toward camera"
            },
            {
                "segment": 2,
                "duration": "0:07-0:15",
                "scene": "Actor shows traditional commercial setup",
                "dialogue": f"Usually now I'd tell you about {topic} problems. But you know them.",
                "veo_prompt": "Actor gesturing at obvious commercial set with fake family, everyone frozen mid-smile, actor eye-rolling",
                "music": "Cheesy commercial music starts and stops",
                "transition": "Pushes over fake wall"
            },
            {
                "segment": 3,
                "duration": "0:14-0:22",
                "scene": "Behind the scenes of commercial shoot",
                "dialogue": "Jim! We're still rolling! Whatever, here's the product.",
                "veo_prompt": "Commercial set collapses, crew visible, director facepalming, actor holding product casually",
                "music": "Backstage chaos sounds",
                "transition": "Trips over cable"
            },
            {
                "segment": 4,
                "duration": "0:21-0:29",
                "scene": "Actor in different commercials trying to escape",
                "dialogue": "Wait, why am I in a paper towel ad now? HELP!",
                "veo_prompt": "Actor appearing in various commercial settings - paper towels, cars, cereal - looking confused",
                "music": "Channel changing sounds",
                "transition": "Jumps through TV screen"
            },
            {
                "segment": 5,
                "duration": "0:28-0:36",
                "scene": "Lands in competitor's commercial",
                "dialogue": f"Their product sucks. Buy {brand}. There, I said it.",
                "veo_prompt": "Actor in competitor's commercial set, other actors shocked, pointing at superior product",
                "music": "Competitor jingle glitches",
                "transition": "Security chases actor"
            },
            {
                "segment": 6,
                "duration": "0:35-0:43",
                "scene": "Running through commercial history montage",
                "dialogue": "Is this the 1950s? Why is everything black and white?!",
                "veo_prompt": "Actor running through vintage commercials, different decades flashing by, costume changes mid-run",
                "music": "Era-appropriate music mashup",
                "transition": "Crashes into present"
            },
            {
                "segment": 7,
                "duration": "0:42-0:50",
                "scene": "Back in original room, exhausted",
                "dialogue": "Look, just... it's good. Trust me. My mom uses it.",
                "veo_prompt": "Actor exhausted on couch, product next to them, actual mom walks in and waves",
                "music": "Gentle piano",
                "transition": "Mom picks up product"
            },
            {
                "segment": 8,
                "duration": "0:49-0:60",
                "scene": "Mom becomes spokesperson",
                "dialogue": f"Mom: {brand}. Because my kid needs the paycheck.",
                "veo_prompt": "Mom professionally presenting product, actor in background giving thumbs up, logo appears",
                "music": "Professional jingle",
                "transition": "Wink to camera, fade to logo"
            }
        ]
        
        return segments
    
    def _generate_celebrity_script(self, key_points: Dict, brand: str) -> List[Dict]:
        """
        Generate celebrity surprise script
        """
        # Note: In production, you'd have actual celebrity names
        celebrities = ["Action Star", "Pop Icon", "Chef Celebrity", "Tech Billionaire"]
        chosen_celeb = random.choice(celebrities)
        
        segments = [
            {
                "segment": 1,
                "duration": "0:00-0:08",
                "scene": "Regular person in everyday situation",
                "dialogue": "Just another Tuesday, making breakfast...",
                "veo_prompt": "Average person in kitchen making toast, morning light, suburban home, yawning",
                "music": "Soft morning ambience",
                "transition": "Toaster dings"
            },
            {
                "segment": 2,
                "duration": "0:07-0:15",
                "scene": f"Toast pops up, {chosen_celeb} emerges from toaster",
                "dialogue": f"{chosen_celeb}: 'Heard you needed help with breakfast?'",
                "veo_prompt": f"{chosen_celeb} impossibly emerging from toaster, full glamorous outfit, person shocked",
                "music": "Dramatic sting",
                "transition": "Person drops coffee"
            },
            {
                "segment": 3,
                "duration": "0:14-0:22",
                "scene": "Celebrity demonstrates product while dancing",
                "dialogue": f"When I'm not [celebrity activity], I use {brand}!",
                "veo_prompt": f"{chosen_celeb} using product while performing signature moves, kitchen transforming into stage",
                "music": "Celebrity's hit song instrumental",
                "transition": "Spin transition"
            },
            {
                "segment": 4,
                "duration": "0:21-0:29",
                "scene": "Neighbor celebrities start appearing",
                "dialogue": "Wait, is that...? They ALL use it?",
                "veo_prompt": "Multiple celebrities casually entering through windows and doors, each with product",
                "music": "Building excitement",
                "transition": "Doorbell rings"
            },
            {
                "segment": 5,
                "duration": "0:28-0:36",
                "scene": "Delivery person is also celebrity",
                "dialogue": "Delivery Celeb: 'Someone order success?'",
                "veo_prompt": "Famous athlete as delivery person, package glowing, neighbors peering from windows",
                "music": "Triumphant sports theme",
                "transition": "Package opens"
            },
            {
                "segment": 6,
                "duration": "0:35-0:43",
                "scene": "Product emerges in slow motion glory",
                "dialogue": "All Celebrities: 'We all switched!'",
                "veo_prompt": "Product floating in air, celebrities posing around it, lens flares, hero lighting",
                "music": "Choir of angels",
                "transition": "Regular person faints"
            },
            {
                "segment": 7,
                "duration": "0:42-0:50",
                "scene": "Person wakes up, celebrities gone, product remains",
                "dialogue": "Was that real? (Looks at product) Oh, it's real.",
                "veo_prompt": "Person alone again, product on counter, celebrity signatures appear on it magically",
                "music": "Mysterious chimes",
                "transition": "Reaches for product"
            },
            {
                "segment": 8,
                "duration": "0:49-0:60",
                "scene": "Using product, becomes celebrity-confident",
                "dialogue": f"{brand}. Join the famous club. (Wink)",
                "veo_prompt": "Person using product, sudden confidence, paparazzi appear outside, logo with celebrity silhouettes",
                "music": "Swagger anthem",
                "transition": "Freeze frame high-five with logo"
            }
        ]
        
        return segments
    
    def _generate_dramatic_mundane_script(self, key_points: Dict, brand: str) -> List[Dict]:
        """
        Generate dramatic treatment of mundane activities script
        """
        topic = key_points['main_topic']
        
        segments = [
            {
                "segment": 1,
                "duration": "0:00-0:08",
                "scene": "Epic war drums as person approaches task",
                "dialogue": "(Whispering) The mission... begins...",
                "veo_prompt": "Person approaching simple task like opening jar, filmed like approach to bomb defusal, sweat beads",
                "music": "Hans Zimmer-style tension",
                "transition": "Zoom on determined eyes"
            },
            {
                "segment": 2,
                "duration": "0:07-0:15",
                "scene": "Slow motion preparation sequence",
                "dialogue": "Years of training... for this moment...",
                "veo_prompt": "Hands stretching, neck cracking, putting on kitchen gloves like tactical gear, dramatic angles",
                "music": "Building orchestral tension",
                "transition": "Lightning flash transition"
            },
            {
                "segment": 3,
                "duration": "0:14-0:22",
                "scene": "The attempt begins, filmed like action sequence",
                "dialogue": "(Screaming) NOT TODAY, JAR!",
                "veo_prompt": "Wrestling with jar, spinning moves, Matrix-like bullet time, kitchen utensils flying",
                "music": "Action movie score",
                "transition": "Jar won't budge, devastation"
            },
            {
                "segment": 4,
                "duration": "0:21-0:29",
                "scene": "Defeat and despair montage",
                "dialogue": "I've... failed... everyone...",
                "veo_prompt": "Dramatic collapse, rain inside kitchen, black and white flashbacks of happy jar-opening times",
                "music": "Sad violin",
                "transition": "Single tear, then hope"
            },
            {
                "segment": 5,
                "duration": "0:28-0:36",
                "scene": f"{brand} appears like holy grail",
                "dialogue": "Wait... the ancient texts spoke of this...",
                "veo_prompt": "Product descending from heavens with god rays, choir of angels, person reaching up",
                "music": "Heavenly chorus",
                "transition": "Grasps product heroically"
            },
            {
                "segment": 6,
                "duration": "0:35-0:43",
                "scene": "Using product in epic slow motion",
                "dialogue": "WITH THIS POWER, I AM UNSTOPPABLE!",
                "veo_prompt": "Product working perfectly, jar lid flying off in explosion of light, victory pose",
                "music": "Triumphant orchestra",
                "transition": "Explosion of success"
            },
            {
                "segment": 7,
                "duration": "0:42-0:50",
                "scene": "Celebrating like won the World Cup",
                "dialogue": "Tell my children... I did it...",
                "veo_prompt": "Person lifted by crowd of kitchen appliances, confetti, trophy made of jar lid",
                "music": "Victory fanfare",
                "transition": "Calms to normal kitchen"
            },
            {
                "segment": 8,
                "duration": "0:49-0:60",
                "scene": "Casual product shot with wink",
                "dialogue": f"{brand}. For life's epic battles.",
                "veo_prompt": "Normal person holding product and opened jar, subtle wink, logo with epic music sting",
                "music": "Subtle epic theme",
                "transition": "Fade to logo with lens flare"
            }
        ]
        
        return segments
    
    def _generate_unexpected_twist_script(self, key_points: Dict, brand: str) -> List[Dict]:
        """
        Generate unexpected twist script (M. Night Shyamalan style)
        """
        segments = [
            {
                "segment": 1,
                "duration": "0:00-0:08",
                "scene": "Typical family dinner scene",
                "dialogue": "Pass the salt, honey.",
                "veo_prompt": "Perfect family dinner, too perfect, uncanny valley feeling, slightly off lighting",
                "music": "Eerie normalcy",
                "transition": "Salt shaker freezes mid-pass"
            },
            {
                "segment": 2,
                "duration": "0:07-0:15",
                "scene": "Family continues eating, one person notices oddity",
                "dialogue": "Did... did anyone else see that?",
                "veo_prompt": "Family eating mechanically, one person looking concerned, objects slightly glitching",
                "music": "Subtle distortion",
                "transition": "Stands up suddenly"
            },
            {
                "segment": 3,
                "duration": "0:14-0:22",
                "scene": "Discovers they're in a commercial",
                "dialogue": "We're... we're not real... we're in an ad!",
                "veo_prompt": "Camera pulls back showing studio lights, family still acting normal, one person panicking",
                "music": "Reality breaking sound",
                "transition": "Runs to window"
            },
            {
                "segment": 4,
                "duration": "0:21-0:29",
                "scene": "Outside is just more commercial sets",
                "dialogue": "It's commercials all the way down!",
                "veo_prompt": "Window reveals infinite commercial sets, different products, all actors, dystopian",
                "music": "Overwhelming revelation theme",
                "transition": "Turns back to family"
            },
            {
                "segment": 5,
                "duration": "0:28-0:36",
                "scene": "Family reveals they knew all along",
                "dialogue": "Family: We know. We've always known. Join us.",
                "veo_prompt": "Family turning heads unnaturally, smiling too wide, holding product ominously",
                "music": "Creepy music box",
                "transition": "Product glows mysteriously"
            },
            {
                "segment": 6,
                "duration": "0:35-0:43",
                "scene": "Person accepts fate, picks up product",
                "dialogue": "If you can't beat them...",
                "veo_prompt": "Person reluctantly picking up product, instant transformation to happy actor, smile spreading",
                "music": "Transformation sound",
                "transition": "Smile becomes genuine"
            },
            {
                "segment": 7,
                "duration": "0:42-0:50",
                "scene": "Twist: They're actually happy",
                "dialogue": "You know what? This is actually great!",
                "veo_prompt": "Genuine joy using product, family becomes real, warm lighting returns, authentic moment",
                "music": "Warm resolution",
                "transition": "Camera pulls back again"
            },
            {
                "segment": 8,
                "duration": "0:49-0:60",
                "scene": "Viewer realizes they're watching this",
                "dialogue": f"{brand}. You're already part of the story.",
                "veo_prompt": "TV in living room showing this commercial, YOUR living room, product on YOUR table, logo appears",
                "music": "Meta sting",
                "transition": "Cut to black with logo"
            }
        ]
        
        return segments
    
    def export_for_veo(self, script: Dict, output_file: str = "veo_prompts.json"):
        """
        Export script in Veo-ready format
        """
        veo_data = {
            "project": f"{script['brand']}_SuperBowl_Ad",
            "total_duration": 60,
            "segments": []
        }
        
        for segment in script['segments']:
            veo_segment = {
                "id": segment['segment'],
                "duration_seconds": 8,
                "prompt": segment['veo_prompt'],
                "style_notes": "Cinematic, high production value, 4K, shallow depth of field",
                "transition_out": segment.get('transition', 'cut'),
                "audio_notes": {
                    "dialogue": segment['dialogue'],
                    "music": segment['music']
                }
            }
            veo_data['segments'].append(veo_segment)
        
        with open(output_file, 'w') as f:
            json.dump(veo_data, f, indent=2)
        
        print(f"✅ Veo prompts exported to {output_file}")
        return output_file
    
    def create_stitch_instructions(self, script: Dict) -> str:
        """
        Generate FFmpeg commands for stitching
        """
        instructions = """
# Video Stitching Instructions

## Step 1: Prepare segments
Place all 8 video files in a folder named 'segments/'
Name them: segment_1.mp4, segment_2.mp4, ..., segment_8.mp4

## Step 2: Create input file list
```bash
for i in {1..8}; do echo "file 'segments/segment_$i.mp4'" >> input.txt; done
```

## Step 3: Basic concatenation (no transitions)
```bash
ffmpeg -f concat -safe 0 -i input.txt -c copy output_basic.mp4
```

## Step 4: Advanced stitching with transitions
```bash
ffmpeg \\
"""
        
        # Generate complex filter
        filter_parts = []
        for i in range(8):
            if i == 0:
                filter_parts.append(f"-i segments/segment_{i+1}.mp4 \\")
            else:
                filter_parts.append(f"-i segments/segment_{i+1}.mp4 \\")
        
        instructions += "\n".join(filter_parts)
        
        instructions += """
-filter_complex "\\
[0:v][1:v]xfade=transition=fade:duration=1:offset=7[v01];\\
[v01][2:v]xfade=transition=fade:duration=1:offset=14[v02];\\
[v02][3:v]xfade=transition=fade:duration=1:offset=21[v03];\\
[v03][4:v]xfade=transition=fade:duration=1:offset=28[v04];\\
[v04][5:v]xfade=transition=fade:duration=1:offset=35[v05];\\
[v05][6:v]xfade=transition=fade:duration=1:offset=42[v06];\\
[v06][7:v]xfade=transition=fade:duration=1:offset=49[outv]" \\
-map "[outv]" \\
-c:v libx264 -crf 18 -preset slow \\
final_superbowl_ad.mp4
```

## Step 5: Add audio track
```bash
ffmpeg -i final_superbowl_ad.mp4 -i audio.mp3 -c:v copy -c:a aac -shortest final_with_audio.mp4
```

## Step 6: Add logo watermark
```bash
ffmpeg -i final_with_audio.mp4 -i logo.png \\
-filter_complex "[1:v]scale=100:-1[logo];[0:v][logo]overlay=W-w-10:H-h-10" \\
final_complete.mp4
```
"""
        return instructions


def main():
    """
    Example usage
    """
    # Sample article text
    sample_article = """
    Revolutionary Smart Coffee Mug Changes Morning Routines Forever
    
    Tech startup MugLife has created a smart coffee mug that maintains perfect temperature,
    tracks caffeine intake, and even orders refills automatically. The $49 device has
    already sold 2 million units, with 97% of users reporting better mornings.
    
    The problem with traditional coffee mugs is temperature loss. Within 10 minutes,
    your perfect brew becomes lukewarm disappointment. MugLife solves this with
    proprietary heating technology and an AI that learns your preferences.
    
    CEO Sarah Chen says, "We're not just selling a mug. We're selling the perfect
    morning, every morning." The mug connects to your phone, integrates with smart
    home devices, and even has a social feature where you can 'cheers' with friends
    remotely.
    """
    
    # Initialize generator
    generator = SuperBowlScriptGenerator()
    
    # Generate scripts in different styles
    styles = ["absurdist", "self-aware", "celebrity-surprise", "dramatic-mundane", "unexpected-twist"]
    
    for style in styles:
        print(f"\n{'='*60}")
        print(f"Generating {style.upper()} style script...")
        print('='*60)
        
        script = generator.generate_superbowl_script(
            article_text=sample_article,
            brand_name="MugLife",
            humor_style=style
        )
        
        # Export for Veo
        veo_file = generator.export_for_veo(script, f"veo_prompts_{style}.json")
        
        # Print first two segments as preview
        print("\nPreview of first two segments:")
        for segment in script['segments'][:2]:
            print(f"\nSegment {segment['segment']}:")
            print(f"  Scene: {segment['scene']}")
            print(f"  Dialogue: {segment['dialogue']}")
            print(f"  Veo Prompt: {segment['veo_prompt'][:100]}...")
    
    # Generate stitching instructions
    instructions = generator.create_stitch_instructions(script)
    with open("stitching_instructions.md", "w") as f:
        f.write(instructions)
    
    print("\n✅ All scripts generated successfully!")
    print("📁 Files created:")
    print("  - veo_prompts_*.json (5 files)")
    print("  - stitching_instructions.md")
    print("\n🎬 Next steps:")
    print("  1. Feed prompts to Veo AI (8 seconds each)")
    print("  2. Download generated videos")
    print("  3. Follow stitching_instructions.md")
    print("  4. Add music and final polish")
    print("  5. Submit to Cannes Lions 🏆")


if __name__ == "__main__":
    main()