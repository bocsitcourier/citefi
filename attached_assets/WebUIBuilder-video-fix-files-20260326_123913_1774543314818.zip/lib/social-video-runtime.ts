import path from "path";

export type SocialVideoProvider = "slideshow" | "veo";

export interface SocialVideoRuntimeContext {
  socialPostId: number;
  jobId?: string;
  provider: SocialVideoProvider;
  attemptId: string;
  workDir: string;
  imageDir: string;
  audioDir: string;
}

function sanitizeSegment(value: string): string {
  return value.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 64);
}

export function normalizeSocialVideoProvider(
  provider?: string | null,
): SocialVideoProvider {
  const candidate = (provider || process.env.SOCIAL_VIDEO_PROVIDER || "slideshow")
    .trim()
    .toLowerCase();

  return candidate === "veo" ? "veo" : "slideshow";
}

export function buildSocialVideoJobKey(socialPostId: number): string {
  return `social-video:${socialPostId}`;
}

export function getSocialVideoJobExpireSeconds(): number {
  const value = Number.parseInt(
    process.env.SOCIAL_VIDEO_JOB_EXPIRE_SECONDS || "2700",
    10,
  );

  if (!Number.isFinite(value) || value < 900) {
    return 2700;
  }

  return value;
}

export function getSocialVideoStaleMinutes(): number {
  return Math.max(
    15,
    Math.ceil(getSocialVideoJobExpireSeconds() / 60),
  );
}

export function createSocialVideoRuntimeContext(input: {
  socialPostId: number;
  jobId?: string;
  provider?: string | null;
}): SocialVideoRuntimeContext {
  const provider = normalizeSocialVideoProvider(input.provider);
  const attemptSeed = input.jobId
    ? sanitizeSegment(input.jobId)
    : sanitizeSegment(`${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  const workDir = path.join(
    "/tmp",
    "social-video",
    String(input.socialPostId),
    attemptSeed,
  );

  return {
    socialPostId: input.socialPostId,
    jobId: input.jobId,
    provider,
    attemptId: attemptSeed,
    workDir,
    imageDir: path.join(workDir, "images"),
    audioDir: path.join(workDir, "audio"),
  };
}
