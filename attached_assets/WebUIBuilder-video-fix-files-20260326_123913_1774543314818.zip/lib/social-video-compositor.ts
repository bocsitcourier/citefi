import { spawn } from "child_process";
import { objectStorageClient } from "./storage";
import type { VideoScene } from "./gemini-video-script-generator";
import type { VideoImageResult } from "./social-video-image-generator";
import type { TTSResult } from "./social-video-tts-generator";
import { getSocialVideoPlatformConfig } from "./social-video-platforms";
import type { SocialVideoRuntimeContext } from "./social-video-runtime";
import ffmpegPath from "ffmpeg-static";
import ffprobePath from "@ffprobe-installer/ffprobe";

function summarizeFfmpegOutput(stderr: string): string {
  const meaningfulLines = stderr
    .split("\n")
    .map((line) => line.trimEnd())
    .filter(Boolean)
    .filter((line) => {
      const trimmed = line.trim();
      return (
        !trimmed.startsWith("ffmpeg version") &&
        !trimmed.startsWith("built with") &&
        !trimmed.startsWith("configuration:") &&
        !/^lib[a-z0-9]+\s+\d/.test(trimmed)
      );
    });

  const summary = meaningfulLines.slice(-25).join("\n").trim();
  if (summary) {
    return summary.slice(-2000);
  }

  return stderr.trim().slice(-2000);
}

// Safe FFmpeg execution using bundled static binary
async function execFFmpeg(args: string[]): Promise<void> {
  if (!ffmpegPath) {
    throw new Error("FFmpeg binary not found. Please ensure ffmpeg-static is installed.");
  }

  const binaryPath: string = ffmpegPath;
  const fullArgs = ["-hide_banner", ...args];

  return new Promise((resolve, reject) => {
    console.log(`  🎬 Executing FFmpeg: ${binaryPath} ${fullArgs.slice(0, 6).join(" ")}...`);
    const ffmpeg = spawn(binaryPath, fullArgs);
    
    let stderr = '';
    let stdout = '';
    
    ffmpeg.stdout?.on('data', (data: Buffer) => {
      stdout += data.toString();
    });
    
    ffmpeg.stderr?.on('data', (data: Buffer) => {
      stderr += data.toString();
    });
    
    ffmpeg.on('close', (code: number | null) => {
      if (code === 0) {
        resolve();
      } else {
        const summary = summarizeFfmpegOutput(stderr);
        console.error(`❌ FFmpeg failed with exit code ${code}`);
        console.error(`❌ FFmpeg details:\n${summary}`);
        reject(new Error(`FFmpeg failed with code ${code}: ${summary}`));
      }
    });
    
    ffmpeg.on('error', (err: Error) => {
      console.error(`❌ FFmpeg process error:`, err);
      reject(new Error(`FFmpeg process error: ${err.message}. This usually means the FFmpeg binary is missing or cannot be executed.`));
    });
  });
}

// Get FFmpeg binary path for health checks
export function getFFmpegPath(): string | null {
  return ffmpegPath;
}

export interface VideoCompositorRequest {
  socialPostId: number;
  images: VideoImageResult[]; // 4 images (one per scene)
  audio: TTSResult; // Voiceover audio
  scenes: VideoScene[]; // Script with captions
  companyLogoPath?: string; // Optional logo overlay
  companyName: string;
  platform: string; // Determines output format
  runtime: SocialVideoRuntimeContext;
}

export interface VideoCompositorResult {
  videoUrl: string; // Permanent storage URL
  localPath: string; // Temporary local path
  duration: number; // Actual video duration in seconds
  fileSize: number; // File size in bytes
  resolution: string; // e.g., "1080x1920"
}

export async function composeVideo(
  request: VideoCompositorRequest
): Promise<VideoCompositorResult> {
  const {
    socialPostId,
    images,
    audio,
    scenes,
    companyLogoPath,
    companyName,
    platform,
    runtime,
  } = request;

  console.log(`🎬 Composing 60-second video with FFmpeg`);

  const resolution = getSocialVideoPlatformConfig(platform);
  const { width, height } = resolution;

  try {
    const fs = await import("fs/promises");
    const path = await import("path");

    // Prepare temp directory
    const tempDir = runtime.workDir;
    await fs.mkdir(tempDir, { recursive: true });

    // Sort images by scene number
    const sortedImages = [...images].sort((a, b) => a.sceneNumber - b.sceneNumber);

    // CRITICAL: Validate and fix image dimensions before FFmpeg processing
    console.log(`  🔍 Validating image dimensions...`);
    const sharp = (await import("sharp")).default;
    for (const img of sortedImages) {
      const metadata = await sharp(img.localPath).metadata();
      console.log(`    Scene ${img.sceneNumber}: ${metadata.width}x${metadata.height} (expected: ${width}x${height})`);
      
      if (metadata.width !== width || metadata.height !== height) {
        console.warn(`    ⚠️ Scene ${img.sceneNumber}: DIMENSION MISMATCH! Emergency resize required.`);
        // Emergency resize to exact target dimensions
        const fixedPath = img.localPath.replace('.jpg', '-fixed.jpg');
        await sharp(img.localPath)
          .resize(width, height, {
            fit: "cover",
            position: "centre"
          })
          .jpeg({ quality: 95, chromaSubsampling: '4:4:4' })
          .toFile(fixedPath);
        
        // Update the path to use fixed image
        img.localPath = fixedPath;
        console.log(`    ✅ Scene ${img.sceneNumber}: Emergency resize complete → ${width}x${height}`);
      }
    }
    console.log(`  ✅ All images validated and dimensionally correct`);

    // Get durations from scene metadata
    const totalScenes = scenes.length;
    const sceneDurations = scenes.map(scene => scene.targetDuration || 12); // Fallback to 12s
    
    // Validate scene count
    if (totalScenes !== 5 || sortedImages.length !== 5) {
      console.warn(`⚠️ Expected 5 scenes, got ${totalScenes} scenes and ${sortedImages.length} images.`);
    }

    // Normalize durations to ensure total is EXACTLY 60 seconds
    const totalDuration = sceneDurations.reduce((sum, d) => sum + d, 0);
    let normalizedDurations: number[];
    
    if (totalDuration > 0) {
      // Calculate precise floating point values
      const preciseValues = sceneDurations.map(d => (d / totalDuration) * 60);
      // Round each value
      normalizedDurations = preciseValues.map(v => Math.round(v));
      // Calculate rounding error
      const currentTotal = normalizedDurations.reduce((a, b) => a + b, 0);
      const delta = 60 - currentTotal;
      // Distribute rounding error to the last scene (branded CTA)
      if (delta !== 0) {
        normalizedDurations[normalizedDurations.length - 1] += delta;
      }
    } else {
      normalizedDurations = [10, 12, 12, 12, 14]; // Fallback
    }
    
    console.log(`  ⏱️ Scene durations: ${normalizedDurations.join('s, ')}s (total: ${normalizedDurations.reduce((a,b)=>a+b,0)}s exactly)`);

    // Create a concat file for FFmpeg with dynamic timing per scene
    // IMPORTANT: Last image must be specified twice - once with duration, once without
    // This ensures the final scene plays completely instead of cutting off
    const concatFilePath = path.join(tempDir, "concat.txt");
    const concatLines: string[] = [];
    
    sortedImages.forEach((img, idx) => {
      const duration = normalizedDurations[idx] || 12;
      concatLines.push(`file '${img.localPath}'`);
      concatLines.push(`duration ${duration}`);
    });
    
    // Add final image again without duration to ensure it displays fully
    const lastImage = sortedImages[sortedImages.length - 1];
    concatLines.push(`file '${lastImage.localPath}'`);
    
    const concatContent = concatLines.join("\n");
    await fs.writeFile(concatFilePath, concatContent);

    // Output video path
    const outputVideoPath = path.join(tempDir, `output-${socialPostId}.mp4`);

    console.log(`  🎥 Creating slideshow without audio first...`);

    // Step 1: Create video slideshow only (no audio yet)
    const slideshowOnlyPath = path.join(tempDir, "slideshow-only.mp4");
    
    // CRITICAL: Proper scale+crop logic to eliminate black bars
    // For landscape 16:9 (1920x1080):
    // - If input aspect > 16/9 (wider): scale height to 1080, width auto
    // - If input aspect < 16/9 (taller): scale width to 1920, height auto
    // - Then center crop to exact 1920:1080
    const aspectRatio = width / height; // 1.777... for 16:9
    // Following the pattern: scale='if(gt(a,16/9),-2,1920)':'if(gt(a,16/9),1080,-2)'
    const scaleFilter = `scale='if(gt(a,${aspectRatio}),-2,${width})':'if(gt(a,${aspectRatio}),${height},-2)'`;
    const initialCropFilter = `crop=${width}:${height}`;
    
    console.log(`  📐 Using smart scale+crop: ${scaleFilter},${initialCropFilter}`);
    
    await execFFmpeg([
      '-y',
      '-f', 'concat',
      '-safe', '0',
      '-i', concatFilePath,
      // CRITICAL: Conditional scale + center crop for full-screen edge-to-edge
      '-vf', `${scaleFilter},${initialCropFilter},fps=30`,
      '-c:v', 'libx264',
      '-pix_fmt', 'yuv420p',
      '-preset', 'ultrafast',
      '-an', // No audio in this step
      slideshowOnlyPath
    ]);
    console.log(`  ✅ Slideshow created with full-screen scaling (no black bars)`);

    // Step 2: CROPDETECT to find any remaining black bars
    console.log(`  🔍 Running cropdetect to find any black bars...`);
    let cropFilter: string | null = null;
    
    if (!ffmpegPath) {
      throw new Error("FFmpeg binary not found for cropdetect");
    }
    
    const ffmpegBinary: string = ffmpegPath;
    
    try {
      const cropdetectOutput = await new Promise<string>((resolve, reject) => {
        let stderr = '';
        const detectProcess = spawn(ffmpegBinary, [
          '-hide_banner',
          '-i', slideshowOnlyPath,
          '-vf', 'cropdetect=limit=0.01:round=16',
          '-f', 'null',
          '-'
        ]);
        
        detectProcess.stderr?.on('data', (data: Buffer) => {
          stderr += data.toString();
        });
        
        detectProcess.on('close', (code: number | null) => {
          resolve(stderr);
        });
        
        detectProcess.on('error', (err: Error) => {
          reject(err);
        });
      });
      
      // Extract crop filter from stderr (e.g., crop=1080:1920:0:0)
      const cropMatch = cropdetectOutput.match(/crop=(\d+:\d+:\d+:\d+)/g);
      if (cropMatch && cropMatch.length > 0) {
        // Get the last crop detection (most stable)
        cropFilter = cropMatch[cropMatch.length - 1];
        console.log(`  ✅ Detected crop filter: ${cropFilter}`);
      } else {
        console.log(`  ℹ️ No black bars detected - video is already full-frame`);
      }
    } catch (err) {
      console.log(`  ⚠️ Cropdetect skipped (not critical): ${err}`);
    }

    // Step 3: Apply detected crop (if any) + add audio with COPY codec
    console.log(`  🎵 Adding audio with crop fix...`);
    const slideshowWithAudioPath = path.join(tempDir, "slideshow-audio.mp4");
    
    const videoFilters: string[] = [];
    if (cropFilter && cropFilter !== 'crop=1080:1920:0:0') {
      // Only apply crop if it's different from target dimensions
      videoFilters.push(cropFilter);
      videoFilters.push(`scale=${width}:${height}:force_original_aspect_ratio=increase`);
      videoFilters.push(`crop=${width}:${height}`);
      console.log(`  🔧 Applying cropdetect filter: ${cropFilter}`);
    }
    
    const ffmpegArgs = [
      '-y',
      '-i', slideshowOnlyPath,
      '-i', audio.localPath,
    ];
    
    if (videoFilters.length > 0) {
      ffmpegArgs.push('-vf', videoFilters.join(','));
    } else {
      ffmpegArgs.push('-c:v', 'copy'); // No video re-encode needed
    }
    
    ffmpegArgs.push(
      '-c:a', 'copy', // CRITICAL: Copy audio to prevent cutoffs
      '-map', '0:v:0', // Map video from slideshow
      '-map', '1:a:0', // Map audio from TTS
      slideshowWithAudioPath
    );
    
    await execFFmpeg(ffmpegArgs);
    console.log(`  ✅ Slideshow + audio combined (audio preserved with copy codec)`);

    // OPTIMIZATION: Combine captions + logo + final optimization in one pass
    console.log(`  📝 Adding captions + logo + final encoding (OPTIMIZED: 1 pass)...`);
    const outputPath = outputVideoPath;

    // Build drawtext filters for captions with readable background boxes
    // Use normalized timing based on scene durations
    let currentTime = 0;
    const captionFilters = scenes
      .map((scene, idx) => {
        const duration = normalizedDurations[idx] || 12;
        const startTime = currentTime;
        const endTime = currentTime + duration;
        currentTime = endTime;
        
        const caption = scene.caption.replace(/'/g, "'\\''");
        // IMPROVED: Add semi-transparent black box behind text for readability on any background
        // Scene 5 (branded CTA) gets slightly larger, bolder treatment
        const fontSize = idx === 4 ? 60 : 52;
        return `drawtext=text='${caption}':fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:fontsize=${fontSize}:fontcolor=white:box=1:boxcolor=black@0.7:boxborderw=20:x=(w-text_w)/2:y=(h-text_h)*0.88:enable='between(t,${startTime},${endTime})'`;
      })
      .join(",");

    if (companyLogoPath) {
      // CRITICAL: Logo positioned at BOTTOM RIGHT with padding
      // Filter chain: Scale logo to fit → Overlay at bottom right → Add captions
      // Logo max size: 300px wide, 150px tall (smaller for bottom corner placement)
      const filterComplex = `[1:v]scale=w='min(300,iw)':h='min(150,ih)':force_original_aspect_ratio=decrease[logo];[0:v][logo]overlay=W-w-30:H-h-30[withlogo];[withlogo]${captionFilters}`;
      
      await execFFmpeg([
        '-y',
        '-i', slideshowWithAudioPath,
        '-i', companyLogoPath,
        '-filter_complex', filterComplex,
        '-metadata', `title=${companyName} - Social Video`,
        '-metadata', 'description=Generated by ApexContent Engine',
        '-c:v', 'libx264',
        '-preset', 'medium', // Use medium for final output quality
        '-crf', '23',
        '-c:a', 'copy',
        outputPath
      ]);
      console.log(`  ✅ Logo (max 300x150px, bottom right corner) + captions applied`);
    } else {
      // Just captions + final optimization
      await execFFmpeg([
        '-y',
        '-i', slideshowWithAudioPath,
        '-vf', captionFilters,
        '-metadata', `title=${companyName} - Social Video`,
        '-metadata', 'description=Generated by ApexContent Engine',
        '-c:v', 'libx264',
        '-preset', 'medium', // Use medium for final output quality
        '-crf', '23',
        '-c:a', 'copy',
        outputPath
      ]);
      console.log(`  ✅ Captions + optimization done in 1 pass`);
    }

    const optimizedPath = outputPath;

    // Get file stats
    const stats = await fs.stat(optimizedPath);
    const fileSize = stats.size;

    // Get actual duration using ffprobe (bundled static binary)
    const duration = await new Promise<number>((resolve, reject) => {
      if (!ffprobePath.path) {
        reject(new Error("ffprobe binary not found. Please ensure @ffprobe-installer/ffprobe is installed."));
        return;
      }

      const probeBinaryPath: string = ffprobePath.path;
      console.log(`  🔍 Running ffprobe to get video duration...`);
      const ffprobe = spawn(probeBinaryPath, [
        '-v', 'error',
        '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1',
        optimizedPath
      ]);

      let stdout = '';
      let stderr = '';
      
      ffprobe.stdout?.on('data', (data: Buffer) => {
        stdout += data.toString();
      });

      ffprobe.stderr?.on('data', (data: Buffer) => {
        stderr += data.toString();
      });

      ffprobe.on('close', (code: number | null) => {
        if (code === 0) {
          resolve(Math.ceil(parseFloat(stdout.trim())));
        } else {
          console.error(`❌ ffprobe failed with code ${code}`);
          console.error(`❌ ffprobe stderr: ${stderr}`);
          reject(new Error(`ffprobe failed with code ${code}: ${stderr}`));
        }
      });

      ffprobe.on('error', (err: Error) => {
        console.error(`❌ ffprobe process error:`, err);
        reject(new Error(`ffprobe process error: ${err.message}`));
      });
    });

    console.log(`  ✅ Final video: ${width}x${height}, ${duration}s, ${(fileSize / 1024 / 1024).toFixed(2)}MB`);

    // Upload to Replit Object Storage
    console.log(`  ☁️ Uploading to permanent storage...`);
    const videoBuffer = await fs.readFile(optimizedPath);

    const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || "";
    const timestamp = Date.now();
    const fileName = `social-video-${socialPostId}-${timestamp}.mp4`;
    const objectPath = `public/social-videos/${fileName}`;

    const bucket = objectStorageClient.bucket(BUCKET_ID);
    const file = bucket.file(objectPath);

    await file.save(videoBuffer, {
      contentType: "video/mp4",
      metadata: {
        cacheControl: "public, max-age=31536000",
        companyName,
        platform,
        duration: duration.toString(),
      },
    });

    const videoUrl = `/api/public-objects/social-videos/${fileName}`;

    console.log(`✅ Video uploaded to permanent storage`);

    // Clean up temp files (keep local path for immediate access)
    try {
      await fs.rm(path.join(tempDir, "slideshow-audio.mp4"));
    } catch (cleanupError) {
      console.warn("⚠️ Cleanup warning:", cleanupError);
    }

    return {
      videoUrl,
      localPath: optimizedPath,
      duration,
      fileSize,
      resolution: `${width}x${height}`,
    };
  } catch (error) {
    console.error("❌ Video composition failed:", error);
    throw new Error(`FFmpeg composition failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}

// Cleanup function to remove temporary files after video generation
export async function cleanupTempFiles(
  target: number | SocialVideoRuntimeContext,
): Promise<void> {
  try {
    const fs = await import("fs/promises");
    const tempDir =
      typeof target === "number" ? `/tmp/video-${target}` : target.workDir;
    await fs.rm(tempDir, { recursive: true, force: true });
    console.log(
      `🧹 Cleaned up temp files for video ${
        typeof target === "number" ? target : target.socialPostId
      }`,
    );
  } catch (error) {
    console.warn("⚠️ Cleanup warning:", error);
  }
}
