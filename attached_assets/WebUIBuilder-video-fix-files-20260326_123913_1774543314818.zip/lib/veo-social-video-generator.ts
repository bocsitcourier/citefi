import { spawn } from "child_process";
import { GoogleGenAI } from "@google/genai";
import { db } from "./db";
import { objectStorageClient } from "./storage";
import type { VideoScript } from "./gemini-video-script-generator";
import { socialPosts } from "@/shared/schema";
import { eq } from "drizzle-orm";
import { getSocialVideoPlatformConfig } from "./social-video-platforms";
import type { SocialVideoRuntimeContext } from "./social-video-runtime";
import type { VideoCompositorResult } from "./social-video-compositor";
import ffprobePath from "@ffprobe-installer/ffprobe";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY is required for Veo video generation");
}

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) as any;

interface GenerateVeoSocialVideoRequest {
  socialPostId: number;
  platform: string;
  companyName: string;
  topic: string;
  title: string;
  location: string;
  tone: string;
  mood: string;
  industry: string;
  script: VideoScript;
  runtime: SocialVideoRuntimeContext;
}

async function updateVideoProgress(
  socialPostId: number,
  videoStage: string,
  videoProgress: number,
): Promise<void> {
  await db
    .update(socialPosts)
    .set({
      videoStage,
      videoProgress,
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));
}

function buildVeoPrompt(request: GenerateVeoSocialVideoRequest): string {
  const sceneSummary = request.script.scenes
    .map(
      (scene) =>
        `Scene ${scene.sceneNumber}: ${scene.visualDescription}. Narration tone: ${scene.narration}`,
    )
    .join(" ");

  return [
    `Create a polished branded short-form business video for ${request.companyName}.`,
    `Topic: ${request.topic || request.title}.`,
    `Location: ${request.location}.`,
    `Industry: ${request.industry}.`,
    `Tone: ${request.tone}. Mood: ${request.mood}.`,
    `Use cinematic camera movement, clean composition, realistic lighting, and business-appropriate visuals.`,
    `Avoid text overlays, subtitles, watermarks, and UI chrome.`,
    `Keep the brand presentation credible and grounded in real business environments.`,
    `Storyboard: ${sceneSummary}`,
  ].join(" ");
}

async function wait(ms: number): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function downloadGeneratedVideo(
  generatedVideo: any,
  localPath: string,
): Promise<void> {
  const fileRef =
    generatedVideo?.video?.name ||
    generatedVideo?.video?.uri ||
    generatedVideo?.name ||
    generatedVideo?.uri;

  if (fileRef && genAI.files?.download) {
    try {
      await genAI.files.download({
        file: fileRef,
        downloadPath: localPath,
      });
      return;
    } catch (error) {
      console.warn("⚠️ Veo file download via SDK failed, falling back to fetch:", error);
    }
  }

  const downloadUrl =
    generatedVideo?.video?.downloadUri ||
    generatedVideo?.video?.uri ||
    generatedVideo?.downloadUri ||
    generatedVideo?.uri;

  if (!downloadUrl) {
    throw new Error("Veo response did not include a downloadable video reference.");
  }

  const response = await fetch(downloadUrl);
  if (!response.ok) {
    throw new Error(`Failed to download generated Veo video: ${response.status} ${response.statusText}`);
  }

  const fs = await import("fs/promises");
  const buffer = Buffer.from(await response.arrayBuffer());
  await fs.writeFile(localPath, buffer);
}

async function probeVideo(localPath: string): Promise<{
  duration: number;
  width: number;
  height: number;
}> {
  return new Promise((resolve, reject) => {
    if (!ffprobePath.path) {
      reject(new Error("ffprobe binary not found"));
      return;
    }

    const ffprobe = spawn(ffprobePath.path, [
      "-v",
      "error",
      "-show_entries",
      "format=duration:stream=width,height",
      "-of",
      "json",
      localPath,
    ]);

    let stdout = "";
    let stderr = "";

    ffprobe.stdout?.on("data", (data: Buffer) => {
      stdout += data.toString();
    });

    ffprobe.stderr?.on("data", (data: Buffer) => {
      stderr += data.toString();
    });

    ffprobe.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`ffprobe failed: ${stderr.trim()}`));
        return;
      }

      try {
        const parsed = JSON.parse(stdout);
        const videoStream = (parsed.streams || []).find(
          (stream: any) => stream.width && stream.height,
        );
        resolve({
          duration: Math.ceil(Number.parseFloat(parsed.format?.duration || "8")) || 8,
          width: Number(videoStream?.width || 0),
          height: Number(videoStream?.height || 0),
        });
      } catch (error) {
        reject(error);
      }
    });

    ffprobe.on("error", reject);
  });
}

export async function generateVeoSocialVideo(
  request: GenerateVeoSocialVideoRequest,
): Promise<VideoCompositorResult> {
  const { socialPostId, platform, companyName, runtime } = request;
  const fs = await import("fs/promises");
  const path = await import("path");
  const platformConfig = getSocialVideoPlatformConfig(platform);
  const localPath = path.join(runtime.workDir, `veo-${runtime.attemptId}.mp4`);

  await fs.mkdir(runtime.workDir, { recursive: true });
  await updateVideoProgress(socialPostId, "veo_submitted", 35);

  const prompt = buildVeoPrompt(request);
  const numberOfVideos = 1;
  const operation = await genAI.models.generateVideos({
    model: process.env.VEO_MODEL || "veo-2.0-generate-001",
    prompt,
    config: {
      numberOfVideos,
      aspectRatio: platformConfig.aspectRatio,
      personGeneration: "allow_adult",
    },
  });

  let currentOperation = operation;
  let polls = 0;
  const pollIntervalMs = Number.parseInt(
    process.env.VEO_POLL_INTERVAL_MS || "10000",
    10,
  );
  const timeoutMs = Number.parseInt(
    process.env.VEO_TIMEOUT_MS || "900000",
    10,
  );
  const startedAt = Date.now();

  while (!currentOperation?.done) {
    if (Date.now() - startedAt > timeoutMs) {
      throw new Error(`Veo generation timed out after ${Math.round(timeoutMs / 1000)} seconds`);
    }

    polls += 1;
    const heartbeatProgress = Math.min(35 + polls * 5, 80);
    await updateVideoProgress(socialPostId, "veo_rendering", heartbeatProgress);
    await wait(pollIntervalMs);
    currentOperation = await genAI.operations.getVideosOperation({
      operation: currentOperation,
    });
  }

  const generatedVideo =
    currentOperation?.response?.generatedVideos?.[0] ||
    currentOperation?.generatedVideos?.[0];

  if (!generatedVideo) {
    throw new Error("Veo completed without returning a generated video.");
  }

  await updateVideoProgress(socialPostId, "veo_downloading", 85);
  await downloadGeneratedVideo(generatedVideo, localPath);

  const stats = await fs.stat(localPath);
  const metadata = await probeVideo(localPath).catch(() => ({
    duration: 8,
    width: platformConfig.width,
    height: platformConfig.height,
  }));

  const videoBuffer = await fs.readFile(localPath);
  const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || "";
  const timestamp = Date.now();
  const fileName = `veo-social-video-${socialPostId}-${timestamp}.mp4`;
  const objectPath = `public/social-videos/${fileName}`;
  const bucket = objectStorageClient.bucket(BUCKET_ID);
  const file = bucket.file(objectPath);

  await file.save(videoBuffer, {
    contentType: "video/mp4",
    metadata: {
      cacheControl: "public, max-age=31536000",
      companyName,
      platform,
      provider: "veo",
    },
  });

  return {
    videoUrl: `/api/public-objects/social-videos/${fileName}`,
    localPath,
    duration: metadata.duration,
    fileSize: stats.size,
    resolution:
      metadata.width && metadata.height
        ? `${metadata.width}x${metadata.height}`
        : `${platformConfig.width}x${platformConfig.height}`,
  };
}
