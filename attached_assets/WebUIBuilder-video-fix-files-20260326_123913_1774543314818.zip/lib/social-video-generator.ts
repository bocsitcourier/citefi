import { db } from "./db";
import { socialPostAssets, socialPosts, type SocialPost } from "@/shared/schema";
import { eq } from "drizzle-orm";
import { generateVideoScript } from "./gemini-video-script-generator";
import { generateVideoImages } from "./social-video-image-generator";
import { generateVideoTTS } from "./social-video-tts-generator";
import {
  cleanupTempFiles,
  composeVideo,
  type VideoCompositorResult,
} from "./social-video-compositor";
import {
  createSocialVideoRuntimeContext,
  normalizeSocialVideoProvider,
  type SocialVideoProvider,
  type SocialVideoRuntimeContext,
} from "./social-video-runtime";
import { generateVeoSocialVideo } from "./veo-social-video-generator";

export interface GenerateSocialVideoRequest {
  socialPostId: number;
  platform?: string;
  provider?: string;
  jobId?: string;
}

export interface GenerateSocialVideoResult {
  videoUrl: string;
  duration: number;
  resolution: string;
  fileSize: number;
  scriptSummary: {
    title: string;
    scenes: number;
    hashtags: string[];
  };
}

async function loadArticleContent(articleId?: number | null): Promise<string | undefined> {
  if (!articleId) {
    return undefined;
  }

  const { articles } = await import("@/shared/schema");
  const [article] = await db
    .select()
    .from(articles)
    .where(eq(articles.id, articleId))
    .limit(1);

  if (!article?.finalHtmlContent) {
    return undefined;
  }

  return article.finalHtmlContent.replace(/<[^>]*>/g, " ").slice(0, 2000);
}

async function downloadCompanyLogo(
  companyLogoUrl: string | null,
  workDir: string,
): Promise<string | undefined> {
  if (!companyLogoUrl || !companyLogoUrl.startsWith("/api/public-objects/")) {
    return undefined;
  }

  try {
    const fs = await import("fs/promises");
    const path = await import("path");
    await fs.mkdir(workDir, { recursive: true });

    const logoFileName = companyLogoUrl.split("/").pop() || "logo";
    const logoPath = path.join(workDir, `logo-${logoFileName}`);
    const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || "";
    const { objectStorageClient } = await import("./storage");
    const bucket = objectStorageClient.bucket(BUCKET_ID);
    const objectPath = companyLogoUrl.replace("/api/public-objects/", "public/");
    const file = bucket.file(objectPath);
    const [buffer] = await file.download();

    await fs.writeFile(logoPath, buffer);
    return logoPath;
  } catch (error) {
    console.warn("⚠️ Could not load company logo:", error);
    return undefined;
  }
}

async function finalizeVideo(
  socialPostId: number,
  platform: string,
  promptSummary: string,
  altText: string,
  video: VideoCompositorResult,
): Promise<void> {
  await db
    .update(socialPosts)
    .set({
      videoUrl: video.videoUrl,
      videoStatus: "READY",
      videoProgress: 100,
      videoStage: "complete",
      videoDuration: video.duration,
      videoGeneratedAt: new Date(),
      errorMessage: null,
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  await db.insert(socialPostAssets).values({
    socialPostId,
    platform,
    assetType: "video",
    promptUsed: promptSummary,
    storageUrl: video.videoUrl,
    altText,
    aspectRatio: video.resolution,
    fileFormat: "mp4",
    videoDuration: video.duration,
    videoResolution: video.resolution,
  });
}

async function runSlideshowVideoGeneration(input: {
  socialPostId: number;
  platform: string;
  post: SocialPost;
  articleContent?: string;
  runtime: SocialVideoRuntimeContext;
}): Promise<{ video: VideoCompositorResult; script: Awaited<ReturnType<typeof generateVideoScript>> }> {
  const { socialPostId, platform, post, articleContent, runtime } = input;

  console.log(`\n📝 Step 2/5: Generating video script with Gemini...`);
  const script = await generateVideoScript({
    topic: post.topic,
    title: post.title,
    location: post.location,
    tone: post.tone || "Professional",
    mood: post.mood || "Informative",
    industry: post.industry || "Business",
    companyName: post.companyName!,
    articleContent,
    landingPageUrl: post.landingPageUrl || undefined,
  });

  await db
    .update(socialPosts)
    .set({
      videoScriptJson: script as any,
      videoProgress: 20,
      videoStage: "script_complete",
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  await db
    .update(socialPosts)
    .set({
      videoProgress: 25,
      videoStage: "parallel_generation",
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  const [images, audio] = await Promise.all([
    generateVideoImages({
      socialPostId,
      scenes: script.scenes,
      industry: post.industry || "Business",
      companyName: post.companyName!,
      platform,
      runtime,
    }),
    generateVideoTTS({
      socialPostId,
      scenes: script.scenes,
      tone: post.tone || "Professional",
      companyName: post.companyName!,
      runtime,
    }),
  ]);

  await db
    .update(socialPosts)
    .set({
      videoProgress: 65,
      videoStage: "assets_complete",
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  for (const image of images) {
    const scene = script.scenes.find((item) => item.sceneNumber === image.sceneNumber);
    await db.insert(socialPostAssets).values({
      socialPostId,
      platform,
      assetType: "image",
      promptUsed: scene?.visualDescription || "Video scene image",
      storageUrl: image.storageUrl,
      altText: `Scene ${image.sceneNumber}: ${scene?.caption || ""}`,
      aspectRatio: image.aspectRatio,
      fileFormat: "jpg",
    });
  }

  console.log(`\n🎬 Step 5/5: Composing final video with FFmpeg...`);
  const companyLogoPath = await downloadCompanyLogo(post.companyLogoUrl, runtime.workDir);
  const video = await composeVideo({
    socialPostId,
    images,
    audio,
    scenes: script.scenes,
    companyLogoPath,
    companyName: post.companyName!,
    platform,
    runtime,
  });

  await db
    .update(socialPosts)
    .set({
      videoProgress: 90,
      videoStage: "composition_complete",
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  return { video, script };
}

async function runVeoVideoGeneration(input: {
  socialPostId: number;
  platform: string;
  post: SocialPost;
  articleContent?: string;
  runtime: SocialVideoRuntimeContext;
}): Promise<{ video: VideoCompositorResult; script: Awaited<ReturnType<typeof generateVideoScript>> }> {
  const { socialPostId, platform, post, articleContent, runtime } = input;

  const script = await generateVideoScript({
    topic: post.topic,
    title: post.title,
    location: post.location,
    tone: post.tone || "Professional",
    mood: post.mood || "Informative",
    industry: post.industry || "Business",
    companyName: post.companyName!,
    articleContent,
    landingPageUrl: post.landingPageUrl || undefined,
  });

  await db
    .update(socialPosts)
    .set({
      videoScriptJson: script as any,
      videoProgress: 20,
      videoStage: "script_complete",
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  const video = await generateVeoSocialVideo({
    socialPostId,
    platform,
    companyName: post.companyName!,
    topic: post.topic,
    title: post.title,
    location: post.location,
    tone: post.tone || "Professional",
    mood: post.mood || "Informative",
    industry: post.industry || "Business",
    script,
    runtime,
  });

  await db
    .update(socialPosts)
    .set({
      videoProgress: 95,
      videoStage: "composition_complete",
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));

  return { video, script };
}

export async function generateSocialVideo(
  request: GenerateSocialVideoRequest,
): Promise<GenerateSocialVideoResult> {
  const socialPostId = request.socialPostId;
  const platform = request.platform || "tiktok";
  const provider: SocialVideoProvider = normalizeSocialVideoProvider(request.provider);
  const runtime = createSocialVideoRuntimeContext({
    socialPostId,
    jobId: request.jobId,
    provider,
  });

  console.log(`\n🎬 Starting ${provider} video generation for Social Post ${socialPostId}`);
  console.log(`Platform: ${platform}`);

  try {
    const [post] = await db
      .select()
      .from(socialPosts)
      .where(eq(socialPosts.id, socialPostId))
      .limit(1);

    if (!post) {
      throw new Error(`Social post ${socialPostId} not found`);
    }

    if (!post.companyName) {
      await db
        .update(socialPosts)
        .set({
          videoStatus: "FAILED",
          errorMessage:
            "Company name is required for video generation. Please edit this post to add your company name.",
          updatedAt: new Date(),
        })
        .where(eq(socialPosts.id, socialPostId));

      throw new Error(
        "Company name is required for video generation. Please edit this post to add your company name.",
      );
    }

    await db
      .update(socialPosts)
      .set({
        videoStatus: "GENERATING",
        videoStage: "initializing",
        errorMessage: null,
        updatedAt: new Date(),
      })
      .where(eq(socialPosts.id, socialPostId));

    const articleContent = await loadArticleContent(post.articleId);
    const pipelineResult =
      provider === "veo"
        ? await runVeoVideoGeneration({
            socialPostId,
            platform,
            post,
            articleContent,
            runtime,
          })
        : await runSlideshowVideoGeneration({
            socialPostId,
            platform,
            post,
            articleContent,
            runtime,
          });

    await finalizeVideo(
      socialPostId,
      platform,
      provider === "veo"
        ? `Veo social video: ${pipelineResult.script.title}`
        : `60-second video: ${pipelineResult.script.title}`,
      pipelineResult.script.title,
      pipelineResult.video,
    );

    await cleanupTempFiles(runtime);

    return {
      videoUrl: pipelineResult.video.videoUrl,
      duration: pipelineResult.video.duration,
      resolution: pipelineResult.video.resolution,
      fileSize: pipelineResult.video.fileSize,
      scriptSummary: {
        title: pipelineResult.script.title,
        scenes: pipelineResult.script.scenes.length,
        hashtags: pipelineResult.script.hashtags,
      },
    };
  } catch (error) {
    console.error(`\n❌ Video generation failed for Social Post ${socialPostId}:`, error);

    await db
      .update(socialPosts)
      .set({
        videoStatus: "FAILED",
        videoStage: null,
        errorMessage: error instanceof Error ? error.message : String(error),
        updatedAt: new Date(),
      })
      .where(eq(socialPosts.id, socialPostId));

    await cleanupTempFiles(runtime);
    throw error;
  }
}
