export interface SocialVideoPlatformConfig {
  aspectRatio: "9:16" | "16:9";
  width: number;
  height: number;
}

const PLATFORM_CONFIGS: Record<string, SocialVideoPlatformConfig> = {
  tiktok: { aspectRatio: "9:16", width: 1080, height: 1920 },
  youtube: { aspectRatio: "9:16", width: 1080, height: 1920 },
  shorts: { aspectRatio: "9:16", width: 1080, height: 1920 },
  instagram: { aspectRatio: "9:16", width: 1080, height: 1920 },
  facebook: { aspectRatio: "16:9", width: 1920, height: 1080 },
  linkedin: { aspectRatio: "16:9", width: 1920, height: 1080 },
  x: { aspectRatio: "16:9", width: 1920, height: 1080 },
  twitter: { aspectRatio: "16:9", width: 1920, height: 1080 },
  pinterest: { aspectRatio: "16:9", width: 1920, height: 1080 },
  default: { aspectRatio: "16:9", width: 1920, height: 1080 },
};

export function getSocialVideoPlatformConfig(
  platform?: string | null,
): SocialVideoPlatformConfig {
  const key = (platform || "").trim().toLowerCase();
  return PLATFORM_CONFIGS[key] || PLATFORM_CONFIGS.default;
}
