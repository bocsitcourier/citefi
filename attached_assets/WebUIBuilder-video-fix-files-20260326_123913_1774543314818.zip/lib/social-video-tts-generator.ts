import { openaiClient, callOpenAI } from "./openai-client";
import type { VideoScene } from "./gemini-video-script-generator";
import { objectStorageClient } from "./storage";
import type { SocialVideoRuntimeContext } from "./social-video-runtime";

// Map business tones to OpenAI TTS voices
const TONE_VOICE_MAP: Record<string, "alloy" | "echo" | "fable" | "onyx" | "nova" | "shimmer"> = {
  Professional: "nova", // Clear, professional female voice
  Authoritative: "onyx", // Deep, confident male voice
  "Friendly-Professional": "alloy", // Warm, balanced voice
  Insightful: "nova", // Thoughtful female voice
  Executive: "onyx", // Strong, commanding male voice
  Motivational: "echo", // Energetic male voice
  Analytical: "alloy", // Neutral, clear voice
  default: "nova", // Default to nova (professional female)
};

export interface TTSResult {
  audioUrl: string; // Permanent storage URL
  localPath: string; // Temporary local path for FFmpeg
  duration: number; // Estimated duration in seconds
  voice: string;
}

interface GenerateTTSRequest {
  socialPostId: number;
  scenes: VideoScene[];
  tone: string;
  companyName: string;
  runtime: SocialVideoRuntimeContext;
}

export async function generateVideoTTS(
  request: GenerateTTSRequest
): Promise<TTSResult> {
  const { socialPostId, scenes, tone, companyName, runtime } = request;

  console.log(`🎙️ Generating 60-second voiceover with OpenAI TTS`);

  // Combine all scene narrations into one continuous script
  const fullNarration = scenes
    .map(
      (scene) =>
        `${scene.narration}`
    )
    .join(" ... "); // Add brief pauses between scenes

  const voice = TONE_VOICE_MAP[tone] || TONE_VOICE_MAP.default;

  try {
    console.log(`  🎤 Using voice: ${voice} (tone: ${tone})`);

    const mp3 = await callOpenAI(
      (client) => client.audio.speech.create({
        model: "tts-1",
        voice: voice,
        input: fullNarration,
        speed: 1.0,
      }),
      `Video TTS: ${voice} for post ${socialPostId}`
    );

    // Convert response to buffer
    const buffer = Buffer.from(await mp3.arrayBuffer());

    console.log(`  ✅ Audio generated, uploading to storage...`);

    // Upload to Replit Object Storage
    const BUCKET_ID = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || "";
    const timestamp = Date.now();
    const fileName = `video-${socialPostId}-voiceover-${timestamp}.mp3`;
    const objectPath = `public/social-videos/${fileName}`;

    const bucket = objectStorageClient.bucket(BUCKET_ID);
    const file = bucket.file(objectPath);

    await file.save(buffer, {
      contentType: "audio/mpeg",
      metadata: {
        cacheControl: "public, max-age=31536000",
      },
    });

    // Public URL
    const audioUrl = `/api/public-objects/social-videos/${fileName}`;

    // Also save to temporary local file for FFmpeg processing
    const fs = await import("fs/promises");
    const path = await import("path");
    const tempDir = runtime.audioDir;
    await fs.mkdir(tempDir, { recursive: true });
    const localPath = path.join(
      tempDir,
      `${socialPostId}-voiceover-${runtime.attemptId}.mp3`,
    );
    await fs.writeFile(localPath, buffer);

    // Estimate duration (rough calculation: ~150 words per minute, ~5 chars per word)
    const wordCount = fullNarration.split(/\s+/).length;
    const estimatedDuration = Math.ceil((wordCount / 150) * 60);

    console.log(`✅ Voiceover generated (${voice}, ~${estimatedDuration}s)`);

    return {
      audioUrl,
      localPath,
      duration: estimatedDuration,
      voice,
    };
  } catch (error) {
    console.error("❌ Failed to generate TTS:", error);
    throw new Error(`TTS generation failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}
