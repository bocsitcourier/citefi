import { and, eq, inArray, lt } from "drizzle-orm";
import { db } from "@/lib/db";
import { socialPostJobs, socialPostLogs, socialPosts } from "@/shared/schema";
import { getSocialVideoStaleMinutes } from "@/lib/social-video-runtime";

let recoveryInterval: NodeJS.Timeout | null = null;

function getRecoveryIntervalMs(): number {
  const value = Number.parseInt(
    process.env.SOCIAL_VIDEO_RECOVERY_INTERVAL_MS || "300000",
    10,
  );
  return Number.isFinite(value) && value >= 60000 ? value : 300000;
}

export async function startJobRecovery() {
  console.log(
    `🩺 Starting video job recovery loop every ${Math.round(
      getRecoveryIntervalMs() / 1000,
    )}s`,
  );

  await recoverStaleVideoJobs();

  recoveryInterval = setInterval(async () => {
    await recoverStaleVideoJobs();
  }, getRecoveryIntervalMs());
}

export async function stopJobRecovery() {
  if (recoveryInterval) {
    clearInterval(recoveryInterval);
    recoveryInterval = null;
    console.log("🛑 Video job recovery stopped");
  }
}

async function recoverStaleVideoJobs() {
  try {
    const staleCutoff = new Date(
      Date.now() - getSocialVideoStaleMinutes() * 60 * 1000,
    );

    const stalePosts = await db
      .select()
      .from(socialPosts)
      .where(
        and(
          eq(socialPosts.videoStatus, "GENERATING"),
          lt(socialPosts.updatedAt, staleCutoff),
        ),
      );

    for (const post of stalePosts) {
      await db
        .update(socialPosts)
        .set({
          videoStatus: "FAILED",
          videoStage: null,
          errorMessage: `Video generation exceeded ${getSocialVideoStaleMinutes()} minutes and was marked failed for manual retry.`,
          updatedAt: new Date(),
        })
        .where(eq(socialPosts.id, post.id));

      await db
        .update(socialPostJobs)
        .set({
          status: "FAILED",
          completedAt: new Date(),
          errorMessage: `Marked stale by recovery loop after ${getSocialVideoStaleMinutes()} minutes.`,
        })
        .where(
          and(
            eq(socialPostJobs.socialPostId, post.id),
            eq(socialPostJobs.jobType, "VIDEO_GENERATION"),
            inArray(socialPostJobs.status, ["PENDING", "ACTIVE"]),
          ),
        );

      await db.insert(socialPostLogs).values({
        socialPostId: post.id,
        eventType: "FAILED",
        stage: "RECOVERY",
        severity: "warning",
        message: `Marked stale video generation as failed after ${getSocialVideoStaleMinutes()} minutes.`,
        payloadJson: {
          staleMinutes: getSocialVideoStaleMinutes(),
        },
      });

      console.warn(
        `⚠️ Marked stale video generation failed for social post ${post.id}`,
      );
    }
  } catch (error) {
    console.error("❌ Video recovery loop failed:", error);
  }
}
