import { NextRequest, NextResponse } from "next/server";
import { addSocialVideoJob } from "@/lib/queue";
import {
  getSocialVideoStaleMinutes,
  normalizeSocialVideoProvider,
} from "@/lib/social-video-runtime";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      socialPostId,
      platform = "tiktok",
      provider,
    } = body;

    if (!socialPostId) {
      return NextResponse.json(
        { error: "socialPostId is required" },
        { status: 400 }
      );
    }

    // Validate that the social post has a company name
    const { db } = await import("@/lib/db");
    const { socialPostJobs, socialPosts } = await import("@/shared/schema");
    const { and, desc, eq, inArray } = await import("drizzle-orm");
    const videoProvider = normalizeSocialVideoProvider(provider);
    const staleCutoff = new Date(
      Date.now() - getSocialVideoStaleMinutes() * 60 * 1000,
    );
    
    const [post] = await db
      .select()
      .from(socialPosts)
      .where(eq(socialPosts.id, socialPostId))
      .limit(1);

    if (!post) {
      return NextResponse.json(
        { error: "Social post not found" },
        { status: 404 }
      );
    }

    if (!post.companyName) {
      return NextResponse.json(
        { 
          error: "Company name is required for video generation",
          message: "Please edit this post to add your company name before generating a video."
        },
        { status: 400 }
      );
    }

    const [existingLiveJob] = await db
      .select()
      .from(socialPostJobs)
      .where(
        and(
          eq(socialPostJobs.socialPostId, socialPostId),
          eq(socialPostJobs.jobType, "VIDEO_GENERATION"),
          inArray(socialPostJobs.status, ["PENDING", "ACTIVE"]),
        ),
      )
      .orderBy(desc(socialPostJobs.createdAt))
      .limit(1);

    if (
      existingLiveJob &&
      ((existingLiveJob.startedAt && existingLiveJob.startedAt > staleCutoff) ||
        existingLiveJob.createdAt > staleCutoff)
    ) {
      return NextResponse.json({
        success: true,
        alreadyRunning: true,
        jobId: existingLiveJob.jobId,
        socialPostId,
        platform,
        provider: videoProvider,
        message: "Video generation is already in progress for this post.",
        videoStatus: "GENERATING",
        videoStage: post.videoStage || "queued",
        videoProgress: post.videoProgress || 0,
      });
    }

    if (existingLiveJob) {
      await db
        .update(socialPostJobs)
        .set({
          status: "FAILED",
          completedAt: new Date(),
          errorMessage: `Marked stale before requeue after exceeding ${getSocialVideoStaleMinutes()} minutes.`,
        })
        .where(eq(socialPostJobs.id, existingLiveJob.id));
    }

    console.log(`📹 Queueing video generation for Social Post ${socialPostId}`);

    const jobId = await addSocialVideoJob({
      socialPostId,
      platform,
      provider: videoProvider,
    });

    if (!jobId) {
      const [dedupedJob] = await db
        .select()
        .from(socialPostJobs)
        .where(
          and(
            eq(socialPostJobs.socialPostId, socialPostId),
            eq(socialPostJobs.jobType, "VIDEO_GENERATION"),
            inArray(socialPostJobs.status, ["PENDING", "ACTIVE"]),
          ),
        )
        .orderBy(desc(socialPostJobs.createdAt))
        .limit(1);

      if (dedupedJob) {
        return NextResponse.json({
          success: true,
          alreadyRunning: true,
          jobId: dedupedJob.jobId,
          socialPostId,
          platform,
          provider: videoProvider,
          message: "Video generation is already in progress for this post.",
          videoStatus: "GENERATING",
          videoStage: post.videoStage || "queued",
          videoProgress: post.videoProgress || 0,
        });
      }

      console.error(`❌ CRITICAL: pg-boss.send() returned NULL! Job was NOT queued.`);
      await db
        .update(socialPosts)
        .set({
          videoStatus: "FAILED",
          videoProgress: 0,
          videoStage: null,
          errorMessage: "Failed to queue job - pg-boss returned null",
        })
        .where(eq(socialPosts.id, socialPostId));
      
      throw new Error("Failed to queue video generation job - pg-boss returned null. The job queue may not be accepting jobs.");
    }

    await db
      .update(socialPosts)
      .set({
        videoStatus: "GENERATING",
        videoProgress: 0,
        videoStage: "queued",
        errorMessage: null,
        jobId,
        updatedAt: new Date(),
      })
      .where(eq(socialPosts.id, socialPostId));

    await db.insert(socialPostJobs).values({
      socialPostId,
      jobId,
      jobType: "VIDEO_GENERATION",
      status: "PENDING",
      maxAttempts: 1,
    });

    console.log(`✅ Video generation job queued successfully: ${jobId}`);

    return NextResponse.json({
      success: true,
      jobId,
      socialPostId,
      platform,
      provider: videoProvider,
      message:
        videoProvider === "veo"
          ? "Veo generation started. This can take several minutes."
          : "Video generation started. This will take 2-3 minutes.",
      estimatedTime: videoProvider === "veo" ? "5-15 minutes" : "2-3 minutes",
      videoStatus: "GENERATING",
      videoProgress: 0,
      videoStage: "queued",
    });
  } catch (error) {
    console.error("❌ Failed to queue video generation:", error);
    return NextResponse.json(
      {
        error: "Failed to start video generation",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 }
    );
  }
}
