/**
 * METACOGNITIVE CONTENT PIPELINE
 * ═══════════════════════════════
 *
 * This replaces the "stupid" linear pipeline with a THINKING system.
 *
 * For every single article, the flow is:
 *
 *   ┌─────────────────────────────────────────────────────────────────┐
 *   │                     THINK → CHECK → DO                         │
 *   │                                                                 │
 *   │  1. INTENTION     ─► Query memory for gold standard + failures  │
 *   │  2. PREDICTION    ─► Calculate P(failure), choose model tier    │
 *   │  3. SHADOW RUN    ─► AI explains its avoidance plan (50 words)  │
 *   │  4. CONSTRAINT    ─► Inject plan + redlines into prompt         │
 *   │  5. EXECUTION     ─► Generate with constraint-injected prompt   │
 *   │  6. JURY          ─► Separate fast model critiques output       │
 *   │  7. RETRY/ACCEPT  ─► Re-gen with jury feedback or publish       │
 *   │  8. LEARN         ─► Record outcome in memory for next cycle    │
 *   └─────────────────────────────────────────────────────────────────┘
 *
 * The Evolutionary Agent runs every 6 hours to optimize the agents themselves.
 */

import { EventEmitter } from "events";
import { getMemory } from "./metacognition/memory.mjs";
import { shadowRun, buildConstrainedPrompt } from "./metacognition/shadow-run.mjs";
import { juryReview, buildRetryPrompt } from "./metacognition/jury.mjs";
import { startEvolutionLoop } from "./metacognition/evolution.mjs";
import { callAI, MODEL_FAST, MODEL_STANDARD, MODEL_REASONING } from "./ai/router.mjs";

// ─────────────────────────────────────────
// CONCURRENCY LIMITER
// ─────────────────────────────────────────
function createLimiter(concurrency) {
  let active = 0;
  const queue = [];
  return {
    async run(fn) {
      return new Promise((resolve, reject) => {
        const execute = async () => {
          active++;
          try { resolve(await fn()); }
          catch (err) { reject(err); }
          finally {
            active--;
            if (queue.length > 0) queue.shift()();
          }
        };
        active < concurrency ? execute() : queue.push(execute);
      });
    },
    get active() { return active; },
    get pending() { return queue.length; },
  };
}

// ─────────────────────────────────────────
// RATE LIMITER
// ─────────────────────────────────────────
class RateLimiter {
  constructor(maxRequests, windowMs) {
    this.max = maxRequests;
    this.window = windowMs;
    this.tokens = maxRequests;
    this.last = Date.now();
  }
  async acquire() {
    while (true) {
      const now = Date.now();
      this.tokens = Math.min(this.max, this.tokens + ((now - this.last) / this.window) * this.max);
      this.last = now;
      if (this.tokens >= 1) { this.tokens--; return; }
      await new Promise((r) => setTimeout(r, Math.ceil(((1 - this.tokens) / this.max) * this.window)));
    }
  }
}

// ─────────────────────────────────────────
// RETRY WITH BACKOFF
// ─────────────────────────────────────────
async function withRetry(fn, { maxRetries = 3, baseDelay = 1000, label = "" } = {}) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try { return await fn(); }
    catch (err) {
      if (attempt === maxRetries || !(err?.status === 429 || err?.status >= 500 || err?.code === "ECONNRESET")) throw err;
      const delay = baseDelay * 2 ** (attempt - 1) + Math.random() * 500;
      console.warn(`  [Retry] ${label} attempt ${attempt}/${maxRetries}, waiting ${Math.round(delay)}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
}

// ═══════════════════════════════════════════
// THE METACOGNITIVE PIPELINE
// ═══════════════════════════════════════════

export class MetacognitivePipeline extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      articleConcurrency: config.articleConcurrency ?? 10,
      mediaConcurrency: config.mediaConcurrency ?? 3,
      publishConcurrency: config.publishConcurrency ?? 5,
      maxJuryRetries: config.maxJuryRetries ?? 2, // Max re-gens after jury rejection
      juryThreshold: config.juryThreshold ?? 0.7,  // Min score to pass
      contentTypes: config.contentTypes ?? ["image"],
      targetPlatforms: config.targetPlatforms ?? ["wordpress"],
      enableEvolution: config.enableEvolution ?? true,
      evolutionInterval: config.evolutionInterval ?? 6 * 60 * 60 * 1000,
      ...config,
    };
    this.results = [];
    this.errors = [];
    this._evolutionTimer = null;
  }

  // ─────────────────────────────────────────
  // SINGLE ARTICLE: THE FULL THINKING LOOP
  // ─────────────────────────────────────────

  async processArticle(job, index) {
    const memory = await getMemory();
    const startTime = Date.now();
    const result = {
      job, index, stages: {}, publishResults: [],
      metacognition: { shadowPlan: null, juryResults: [], attempts: 0 },
    };

    try {
      // ══════════════════════════════════════
      // STAGE 1–3: THINK (Shadow Run)
      // ══════════════════════════════════════
      this.emit("stage", { index, stage: "shadow-run", status: "start" });

      const shadow = await shadowRun({
        contentType: "article",
        topic: job.topic,
        originalPrompt: job.prompt ?? `Write a comprehensive article about: ${job.topic}`,
        conditions: {
          promptComplexity: job.complexity ?? 50,
          apiLatency: job.estimatedLatency ?? 2000,
        },
      });

      result.metacognition.shadowPlan = shadow.plan;
      result.metacognition.prediction = shadow.prediction;
      result.metacognition.selectedModel = shadow.model;

      this.emit("stage", { index, stage: "shadow-run", status: "done", shadow });

      // If shadow run says "don't bother" — skip to save money
      if (!shadow.shouldProceed) {
        console.log(`  ⏭️ [${index}] Shadow run aborted: too high failure risk (P=${shadow.prediction.probability})`);
        result.status = "skipped";
        result.skipReason = "Shadow run predicted failure";
        memory.recordGeneration({
          contentType: "article",
          topic: job.topic,
          model: shadow.model,
          success: false,
          failureReasons: ["shadow_run_abort"],
          metadata: { prediction: shadow.prediction },
          shadowPlan: shadow.plan,
        });
        this.results.push(result);
        return result;
      }

      // ══════════════════════════════════════
      // STAGE 4: BUILD CONSTRAINT-INJECTED PROMPT
      // ══════════════════════════════════════
      const { prompt: constrainedPrompt, systemPrompt } = buildConstrainedPrompt({
        originalPrompt: job.prompt ?? `Write a comprehensive article about: ${job.topic}`,
        shadowResult: shadow,
        contentType: "article",
      });

      // Also inject the evolved agent prompt from memory
      const evolvedAgentPrompt = memory.getAgentPrompt("article")?.prompt;
      const fullSystemPrompt = [evolvedAgentPrompt, systemPrompt].filter(Boolean).join("\n\n---\n\n");

      // ══════════════════════════════════════
      // STAGE 5–7: DO + CHECK (Generate → Jury → Retry Loop)
      // ══════════════════════════════════════
      let article = null;
      let juryResult = null;
      let currentPrompt = constrainedPrompt;
      let attempts = 0;

      while (attempts < this.config.maxJuryRetries + 1) {
        attempts++;
        result.metacognition.attempts = attempts;

        // ── GENERATE ──
        this.emit("stage", { index, stage: "generate", status: "start", attempt: attempts });

        const genStart = Date.now();
        const generatedText = await withRetry(
          () => callAI({
            model: shadow.model,
            messages: [{ role: "user", content: currentPrompt }],
            system: fullSystemPrompt,
            maxTokens: 4096,
          }),
          { label: `gen:${job.topic}:attempt${attempts}` }
        );
        const genLatency = Date.now() - genStart;

        article = {
          title: job.title ?? extractTitle(generatedText),
          text: generatedText,
          excerpt: generatedText.slice(0, 200),
          tags: job.tags ?? ["ai-generated"],
          metadata: { model: shadow.model, latency: genLatency, attempt: attempts },
        };

        this.emit("stage", { index, stage: "generate", status: "done", attempt: attempts, latency: genLatency });

        // ── JURY REVIEW ──
        this.emit("stage", { index, stage: "jury", status: "start", attempt: attempts });

        juryResult = await juryReview({
          contentType: "article",
          topic: job.topic,
          output: generatedText,
          constraints: shadow.constraints,
          goldStandard: shadow.goldStandard,
        });

        result.metacognition.juryResults.push(juryResult);
        this.emit("stage", { index, stage: "jury", status: "done", attempt: attempts, jury: juryResult });

        console.log(
          `  [${index}] Attempt ${attempts}: Jury score=${juryResult.score} verdict=${juryResult.verdict}`
        );

        // ── PASS / RETRY DECISION ──
        if (juryResult.passed || juryResult.score >= this.config.juryThreshold) {
          break; // Accept the output
        }

        if (attempts < this.config.maxJuryRetries + 1) {
          // Build retry prompt with jury feedback injected
          currentPrompt = buildRetryPrompt({
            originalPrompt: constrainedPrompt,
            juryResult,
            attempt: attempts + 1,
          });
          console.log(`  [${index}] Jury rejected — retrying with feedback...`);
        }
      }

      result.stages.article = article;
      result.stages.juryFinal = juryResult;

      // ══════════════════════════════════════
      // STAGE 8: MEDIA GENERATION (parallel, with image aesthetic corrections)
      // ══════════════════════════════════════
      this.emit("stage", { index, stage: "media", status: "start" });
      const mediaLimiter = createLimiter(this.config.mediaConcurrency);
      const mediaJobs = [];

      if (this.config.contentTypes.includes("image")) {
        mediaJobs.push(
          mediaLimiter.run(async () => {
            // Build image prompt with aesthetic corrections from shadow run
            const corrections = shadow.imageCorrections?.length
              ? `[${shadow.imageCorrections.join(", ")}] ` : "";
            const imagePrompt = `${corrections}${job.imagePrompt ?? article.title}`;

            // YOUR IMAGE API HERE (DALL-E, Stability, Midjourney, etc.)
            return { url: `https://placeholder.com/img/${Date.now()}`, type: "image", prompt: imagePrompt };
          })
        );
      }

      if (this.config.contentTypes.includes("video")) {
        mediaJobs.push(
          mediaLimiter.run(async () => {
            // YOUR VIDEO API HERE (Runway, Pika, etc.)
            return { url: `https://placeholder.com/video/${Date.now()}`, type: "video" };
          })
        );
      }

      if (this.config.contentTypes.includes("podcast")) {
        mediaJobs.push(
          mediaLimiter.run(async () => {
            // Prosody feedback: check if previous podcasts had drop-off issues
            const prosodyTrend = memory.getMetricsTrend("podcast", "completionRate", 10);
            let ttsInstructions = "";
            if (prosodyTrend.avg < 0.6) {
              ttsInstructions = "Increase pitch variance by 20% during introduction. Add 0.5s pauses between sections.";
            }
            // YOUR TTS/PODCAST API HERE (ElevenLabs, Play.ht, etc.)
            return { url: `https://placeholder.com/podcast/${Date.now()}.mp3`, type: "podcast", ttsInstructions };
          })
        );
      }

      const mediaResults = await Promise.allSettled(mediaJobs);
      result.stages.media = mediaResults.map((r) => ({
        status: r.status,
        value: r.status === "fulfilled" ? r.value : null,
        error: r.status === "rejected" ? r.reason?.message : null,
      }));

      const media = {};
      for (const r of mediaResults) {
        if (r.status === "fulfilled" && r.value) media[r.value.type] = r.value;
      }

      this.emit("stage", { index, stage: "media", status: "done" });

      // ══════════════════════════════════════
      // STAGE 9: MULTI-SITE PUBLISHING (parallel)
      // ══════════════════════════════════════
      this.emit("stage", { index, stage: "publish", status: "start" });
      const pubLimiter = createLimiter(this.config.publishConcurrency);
      const targets = job.platforms ?? this.config.targetPlatforms;

      const pubResults = await Promise.allSettled(
        targets.map((platform) =>
          pubLimiter.run(async () => {
            // YOUR PUBLISH API HERE — same as before
            return { platform, id: `${platform}-${Date.now()}`, status: "published" };
          })
        )
      );

      result.publishResults = pubResults.map((r, i) => ({
        platform: targets[i],
        status: r.status,
        value: r.status === "fulfilled" ? r.value : null,
        error: r.status === "rejected" ? r.reason?.message : null,
      }));

      this.emit("stage", { index, stage: "publish", status: "done" });

      // ══════════════════════════════════════
      // STAGE 10: LEARN (record in memory)
      // ══════════════════════════════════════
      const success = juryResult?.passed ?? true;
      memory.recordGeneration({
        contentType: "article",
        topic: job.topic,
        model: shadow.model,
        success,
        failureReasons: juryResult?.violations ?? [],
        metadata: {
          latency: Date.now() - startTime,
          juryScore: juryResult?.score,
          attempts,
          prediction: shadow.prediction,
        },
        shadowPlan: shadow.plan,
        juryVerdict: juryResult?.verdict,
      });

      result.status = "success";
      result.duration = Date.now() - startTime;
    } catch (err) {
      result.status = "failed";
      result.error = err.message;
      result.duration = Date.now() - startTime;
      this.errors.push({ index, error: err });

      // Record failure in memory even on crash
      const memory = await getMemory();
      memory.recordGeneration({
        contentType: "article",
        topic: job.topic,
        model: "unknown",
        success: false,
        failureReasons: [err.message],
        metadata: { latency: result.duration, stage: "crash" },
        shadowPlan: result.metacognition?.shadowPlan,
      });

      this.emit("error", { index, error: err });
    }

    this.results.push(result);
    this.emit("article-done", result);
    return result;
  }

  // ─────────────────────────────────────────
  // RUN ALL ARTICLES
  // ─────────────────────────────────────────

  async run(jobs) {
    const totalStart = Date.now();
    console.log(`\n🧠 Metacognitive Pipeline: ${jobs.length} articles, concurrency=${this.config.articleConcurrency}`);
    console.log(`   Think→Check→Do | Jury retries: ${this.config.maxJuryRetries} | Threshold: ${this.config.juryThreshold}\n`);

    // Start evolution loop in background
    if (this.config.enableEvolution) {
      this._evolutionTimer = startEvolutionLoop(this.config.evolutionInterval);
    }

    const limiter = createLimiter(this.config.articleConcurrency);

    await Promise.allSettled(
      jobs.map((job, index) => limiter.run(() => this.processArticle(job, index)))
    );

    const summary = {
      total: jobs.length,
      succeeded: this.results.filter((r) => r.status === "success").length,
      failed: this.results.filter((r) => r.status === "failed").length,
      skipped: this.results.filter((r) => r.status === "skipped").length,
      totalDuration: Date.now() - totalStart,
      avgJuryScore: average(this.results.flatMap((r) => r.metacognition?.juryResults?.map((j) => j.score) ?? [])),
      avgAttempts: average(this.results.map((r) => r.metacognition?.attempts ?? 1)),
      totalAPICallsSaved: this.results.filter((r) => r.status === "skipped").length, // Shadow run aborts
    };

    console.log(`\n✅ Pipeline complete in ${summary.totalDuration}ms`);
    console.log(`   ${summary.succeeded} succeeded | ${summary.failed} failed | ${summary.skipped} skipped`);
    console.log(`   Avg jury score: ${summary.avgJuryScore?.toFixed(2)} | Avg attempts: ${summary.avgAttempts?.toFixed(1)}`);
    console.log(`   API calls saved by shadow abort: ${summary.totalAPICallsSaved}\n`);

    this.emit("pipeline-done", summary);
    return { results: this.results, errors: this.errors, summary };
  }

  stop() {
    if (this._evolutionTimer) clearInterval(this._evolutionTimer);
  }
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

function extractTitle(text) {
  const firstLine = text.split("\n")[0]?.replace(/^#+\s*/, "").trim();
  return firstLine?.slice(0, 100) ?? "Untitled";
}

function average(arr) {
  return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
}

// ─────────────────────────────────────────
// USAGE
// ─────────────────────────────────────────

async function main() {
  const jobs = Array.from({ length: 50 }, (_, i) => ({
    topic: `Article topic #${i + 1}: AI in healthcare`,
    prompt: `Write a 1000-word article about AI applications in healthcare, focus area #${i + 1}`,
    imagePrompt: `Medical AI illustration for topic ${i + 1}`,
    platforms: ["wordpress", "medium"],
    complexity: 40 + Math.random() * 40, // 40-80
    tags: ["ai", "healthcare", "technology"],
  }));

  const pipeline = new MetacognitivePipeline({
    articleConcurrency: 10,
    mediaConcurrency: 3,
    publishConcurrency: 5,
    maxJuryRetries: 2,
    juryThreshold: 0.7,
    contentTypes: ["image", "podcast"],
    targetPlatforms: ["wordpress", "medium"],
    enableEvolution: true,
    evolutionInterval: 6 * 60 * 60 * 1000, // 6 hours
  });

  // ── PROGRESS ──
  let completed = 0;
  pipeline.on("article-done", (r) => {
    completed++;
    const pct = ((completed / jobs.length) * 100).toFixed(0);
    const juryScore = r.metacognition?.juryResults?.slice(-1)[0]?.score?.toFixed(2) ?? "N/A";
    console.log(
      `[${pct}%] #${r.index + 1}: ${r.status} | ` +
      `Attempts: ${r.metacognition?.attempts} | Jury: ${juryScore} | ${r.duration}ms`
    );
  });

  const { summary } = await pipeline.run(jobs);
  console.log("\n── FINAL REPORT ──");
  console.log(JSON.stringify(summary, null, 2));

  pipeline.stop();
}

main().catch(console.error);
