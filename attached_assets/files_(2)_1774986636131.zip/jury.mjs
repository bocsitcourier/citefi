/**
 * MULTI-AGENT JURY
 * ────────────────
 * Stage IV of the Metacognitive Workflow.
 *
 * After generation, a SEPARATE fast model critiques the output against:
 *   1. The gold standard pattern
 *   2. The shadow run constraints
 *   3. The dynamic redline list
 *
 * If the jury rejects it, we get specific feedback for retry.
 * This is cheaper than re-generating blindly.
 */

import { callAI, MODEL_FAST } from "../ai/router.mjs";
import { getMemory } from "./memory.mjs";

/**
 * @param {Object} params
 * @param {string} params.contentType
 * @param {string} params.topic
 * @param {string} params.output         - the generated content
 * @param {string[]} params.constraints  - from shadow run
 * @param {Object} params.goldStandard   - from memory
 * @returns {{ verdict, score, passed, violations, suggestions, retryPrompt }}
 */
export async function juryReview({
  contentType,
  topic,
  output,
  constraints = [],
  goldStandard = null,
}) {
  const memory = await getMemory();
  const topFailures = memory.getTopFailures(contentType, 5);

  const redlineList = topFailures.map((f) => f.reason);

  // Truncate output for the jury (save tokens)
  const truncatedOutput =
    output.length > 3000 ? output.slice(0, 1500) + "\n...[truncated]...\n" + output.slice(-1500) : output;

  const juryPrompt = `You are a Content Quality Jury. Your job is to CRITIQUE this generated ${contentType} output. Be strict but fair.

## GENERATED OUTPUT
Topic: "${topic}"
Content type: ${contentType}

---
${truncatedOutput}
---

## EVALUATION CRITERIA

### 1. REDLINE LIST (automatic fail if ANY are present)
${redlineList.map((r) => `❌ ${r}`).join("\n") || "No redlines defined yet."}

### 2. CONSTRAINTS (from pre-flight plan — must ALL be satisfied)
${constraints.map((c, i) => `${i + 1}. ${c}`).join("\n") || "No constraints specified."}

### 3. GOLD STANDARD
${goldStandard ? `Structure: ${goldStandard.structure ?? "flexible"}\nTone: ${goldStandard.tone ?? "professional"}\nRequired elements: ${goldStandard.requiredElements?.join(", ") ?? "none specified"}` : "No gold standard defined — evaluate against industry best practices."}

## YOUR VERDICT
Respond ONLY with this JSON:
\`\`\`json
{
  "score": 0.0-1.0,
  "passed": true/false,
  "violations": ["list of specific violations found"],
  "strengths": ["what was done well"],
  "suggestions": ["specific actionable improvements"],
  "verdict": "PASS" | "FAIL" | "CONDITIONAL_PASS",
  "retryGuidance": "If FAIL: specific instructions for the regeneration attempt"
}
\`\`\`

Scoring guide:
- 0.9+ = PASS (excellent, publish immediately)
- 0.7-0.89 = CONDITIONAL_PASS (minor issues, can publish with edits)
- Below 0.7 = FAIL (must regenerate)`;

  try {
    const response = await callAI({
      model: MODEL_FAST, // Jury always uses fast/cheap model
      messages: [{ role: "user", content: juryPrompt }],
      maxTokens: 600,
    });

    const parsed = parseJuryResponse(response);

    // Record the jury's verdict in memory
    memory.recordGeneration({
      contentType,
      topic,
      model: MODEL_FAST,
      success: parsed.passed,
      failureReasons: parsed.violations,
      metadata: {
        juryScore: parsed.score,
        juryVerdict: parsed.verdict,
        stage: "jury",
      },
      juryVerdict: parsed.verdict,
    });

    return parsed;
  } catch (err) {
    console.warn(`[Jury] Review failed: ${err.message}. Auto-passing.`);
    return {
      score: 0.7,
      passed: true,
      violations: [],
      strengths: [],
      suggestions: [],
      verdict: "CONDITIONAL_PASS",
      retryGuidance: "",
      error: err.message,
    };
  }
}

/**
 * RETRY WITH JURY FEEDBACK
 *
 * When the jury rejects content, we don't just retry blindly.
 * We inject the jury's specific feedback into the retry prompt.
 */
export function buildRetryPrompt({ originalPrompt, juryResult, attempt }) {
  return `${originalPrompt}

## ⚠️ RETRY ATTEMPT ${attempt} — PREVIOUS VERSION WAS REJECTED

The quality jury rejected the previous output for these specific reasons:
${juryResult.violations.map((v) => `- ❌ ${v}`).join("\n")}

Specific guidance for this retry:
${juryResult.retryGuidance}

Improvements suggested:
${juryResult.suggestions.map((s) => `- ${s}`).join("\n")}

You MUST address every violation listed above. The jury will review again.`;
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

function parseJuryResponse(text) {
  const jsonMatch = text.match(/```json\s*([\s\S]*?)```/) ?? text.match(/\{[\s\S]*"verdict"[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const raw = jsonMatch[1] ?? jsonMatch[0];
      const parsed = JSON.parse(raw);
      return {
        score: parsed.score ?? 0.5,
        passed: parsed.passed ?? parsed.verdict === "PASS",
        violations: parsed.violations ?? [],
        strengths: parsed.strengths ?? [],
        suggestions: parsed.suggestions ?? [],
        verdict: parsed.verdict ?? "FAIL",
        retryGuidance: parsed.retryGuidance ?? "",
      };
    } catch {
      // Fall through
    }
  }

  // Fallback: assume marginal pass
  return {
    score: 0.7,
    passed: true,
    violations: [],
    strengths: [],
    suggestions: [],
    verdict: "CONDITIONAL_PASS",
    retryGuidance: "",
  };
}
