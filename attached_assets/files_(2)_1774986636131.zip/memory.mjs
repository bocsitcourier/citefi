/**
 * SEMANTIC MEMORY SYSTEM
 * ──────────────────────
 * The "brain" of the pipeline. Stores patterns, failures, gold standards,
 * and provides query interfaces for the Shadow Run and Observer Agent.
 *
 * In production, back this with PostgreSQL + pgvector or Pinecone.
 * This implementation uses an in-memory store with file persistence.
 */

import { readFile, writeFile, mkdir } from "fs/promises";
import { existsSync } from "fs";
import path from "path";

const DATA_DIR = process.env.MEMORY_DIR ?? "./data/memory";

export class SemanticMemory {
  constructor() {
    this.ledger = [];           // aiLearningLedger — all generation records
    this.patterns = new Map();  // learningPatterns — gold standards per content type
    this.prompts = new Map();   // learningAgents — current system prompts per agent
    this.metrics = new Map();   // rolling metrics per content type + platform
  }

  async init() {
    await mkdir(DATA_DIR, { recursive: true });
    await this._load();
    return this;
  }

  // ─────────────────────────────────────────
  // LEDGER: Record every generation outcome
  // ─────────────────────────────────────────

  /**
   * @param {Object} entry
   * @param {string} entry.contentType   - "article" | "image" | "video" | "podcast"
   * @param {string} entry.topic
   * @param {string} entry.model         - model used
   * @param {boolean} entry.success
   * @param {string[]} entry.failureReasons - e.g. ["Too promotional", "Broken HTML"]
   * @param {Object} entry.metadata      - scores, latency, tokens used, etc.
   * @param {string} entry.shadowPlan    - the pre-generation plan
   * @param {string} entry.juryVerdict   - multi-agent validation result
   */
  recordGeneration(entry) {
    const record = {
      id: `gen_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      timestamp: new Date().toISOString(),
      ...entry,
    };
    this.ledger.push(record);
    this._updateMetrics(record);
    this._persistAsync();
    return record;
  }

  // ─────────────────────────────────────────
  // QUERY: What the Shadow Run consults
  // ─────────────────────────────────────────

  /**
   * Get the top N most common failure reasons for a content type.
   * This is the "Dynamic Redline List."
   */
  getTopFailures(contentType, n = 5) {
    const failures = this.ledger
      .filter((r) => r.contentType === contentType && !r.success && r.failureReasons?.length)
      .flatMap((r) => r.failureReasons);

    // Count frequency
    const freq = {};
    for (const reason of failures) {
      freq[reason] = (freq[reason] ?? 0) + 1;
    }

    // Calculate Confidence Score: S = (Successes / TotalGenerations) * log(Frequency)
    const totalGens = this.ledger.filter((r) => r.contentType === contentType).length || 1;
    const successes = this.ledger.filter((r) => r.contentType === contentType && r.success).length;

    return Object.entries(freq)
      .map(([reason, count]) => {
        const S = (successes / totalGens) * Math.log(count + 1);
        return {
          reason,
          frequency: count,
          confidenceScore: parseFloat(S.toFixed(4)),
          isHighRisk: S < 0.5,
        };
      })
      .sort((a, b) => b.frequency - a.frequency)
      .slice(0, n);
  }

  /**
   * Get the last N failed outputs for self-analysis.
   */
  getRecentFailures(contentType, n = 10) {
    return this.ledger
      .filter((r) => r.contentType === contentType && !r.success)
      .slice(-n);
  }

  /**
   * Get the gold standard pattern for a content type.
   */
  getGoldStandard(contentType) {
    return this.patterns.get(contentType) ?? null;
  }

  /**
   * Set/update the gold standard for a content type.
   */
  setGoldStandard(contentType, pattern) {
    this.patterns.set(contentType, {
      ...pattern,
      updatedAt: new Date().toISOString(),
    });
    this._persistAsync();
  }

  /**
   * Get the current system prompt for an agent.
   */
  getAgentPrompt(agentName) {
    return this.prompts.get(agentName) ?? null;
  }

  /**
   * Update an agent's system prompt (used by the Evolutionary Agent).
   */
  setAgentPrompt(agentName, prompt, reason = "") {
    this.prompts.set(agentName, {
      prompt,
      updatedAt: new Date().toISOString(),
      reason,
      version: (this.prompts.get(agentName)?.version ?? 0) + 1,
    });
    this._persistAsync();
  }

  /**
   * Get rolling success rate for a content type.
   */
  getSuccessRate(contentType, windowSize = 50) {
    const recent = this.ledger
      .filter((r) => r.contentType === contentType)
      .slice(-windowSize);
    if (recent.length === 0) return 1.0;
    return recent.filter((r) => r.success).length / recent.length;
  }

  /**
   * Get average metrics (latency, score, etc.) for trending.
   */
  getMetricsTrend(contentType, metric = "latency", windowSize = 20) {
    const recent = this.ledger
      .filter((r) => r.contentType === contentType && r.metadata?.[metric] != null)
      .slice(-windowSize);
    if (recent.length === 0) return { avg: 0, trend: "stable", values: [] };

    const values = recent.map((r) => r.metadata[metric]);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;

    // Simple trend: compare first half vs second half
    const mid = Math.floor(values.length / 2);
    const firstHalf = values.slice(0, mid).reduce((a, b) => a + b, 0) / mid || 0;
    const secondHalf = values.slice(mid).reduce((a, b) => a + b, 0) / (values.length - mid) || 0;
    const trend = secondHalf > firstHalf * 1.1 ? "worsening" : secondHalf < firstHalf * 0.9 ? "improving" : "stable";

    return { avg: parseFloat(avg.toFixed(2)), trend, values };
  }

  /**
   * Get image aesthetic trends (for the "too dark" auto-correction).
   */
  getImageAestheticTrend(n = 10) {
    const recent = this.ledger
      .filter((r) => r.contentType === "image" && r.metadata?.aestheticTags)
      .slice(-n);

    const tagFreq = {};
    for (const r of recent) {
      for (const tag of r.metadata.aestheticTags) {
        tagFreq[tag] = (tagFreq[tag] ?? 0) + 1;
      }
    }

    // If any negative tag appears in >50% of recent images, flag it
    const corrections = [];
    const negativeToPositive = {
      "too dark": "Vibrant lighting, high contrast",
      "too saturated": "Natural color palette, subtle tones",
      "blurry": "Sharp focus, high detail, 4K",
      "cluttered": "Clean composition, minimalist layout",
      "too generic": "Unique perspective, creative angle",
      "low quality": "Professional photography, high resolution",
    };

    for (const [tag, count] of Object.entries(tagFreq)) {
      if (count / recent.length > 0.5 && negativeToPositive[tag]) {
        corrections.push({
          issue: tag,
          frequency: count,
          correction: negativeToPositive[tag],
        });
      }
    }

    return corrections;
  }

  // ─────────────────────────────────────────
  // FAILURE PREDICTION
  // ─────────────────────────────────────────

  /**
   * Calculate P(failure) based on historical data + current conditions.
   *
   * @param {string} contentType
   * @param {Object} conditions - { promptComplexity, apiLatency, modelTier }
   * @returns {{ probability: number, recommendation: string }}
   */
  predictFailure(contentType, conditions = {}) {
    const baseFailRate = 1 - this.getSuccessRate(contentType, 30);

    // Complexity factor: longer/more complex prompts fail more
    const complexityFactor = Math.min((conditions.promptComplexity ?? 50) / 100, 1);

    // Latency factor: high API latency correlates with timeouts
    const latencyTrend = this.getMetricsTrend(contentType, "latency", 10);
    const latencyFactor = latencyTrend.trend === "worsening" ? 0.15 : 0;

    // Time-of-day factor: API reliability varies
    const hour = new Date().getHours();
    const peakHourFactor = (hour >= 14 && hour <= 18) ? 0.05 : 0; // US business hours

    // Combined probability (capped at 0.95)
    const pf = Math.min(
      baseFailRate * (1 + complexityFactor * 0.3) + latencyFactor + peakHourFactor,
      0.95
    );

    let recommendation = "proceed";
    if (pf > 0.5) {
      recommendation = "upgrade_model_and_add_reasoning";
    } else if (pf > 0.3) {
      recommendation = "add_reasoning_step";
    }

    return {
      probability: parseFloat(pf.toFixed(4)),
      recommendation,
      factors: {
        baseFailRate: parseFloat(baseFailRate.toFixed(4)),
        complexityFactor: parseFloat(complexityFactor.toFixed(4)),
        latencyFactor,
        peakHourFactor,
      },
    };
  }

  // ─────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────

  _updateMetrics(record) {
    const key = `${record.contentType}`;
    const current = this.metrics.get(key) ?? { total: 0, successes: 0, failures: 0 };
    current.total++;
    if (record.success) current.successes++;
    else current.failures++;
    current.successRate = parseFloat((current.successes / current.total).toFixed(4));
    current.lastUpdated = record.timestamp;
    this.metrics.set(key, current);
  }

  async _load() {
    try {
      const ledgerPath = path.join(DATA_DIR, "ledger.json");
      if (existsSync(ledgerPath)) {
        this.ledger = JSON.parse(await readFile(ledgerPath, "utf-8"));
      }
      const patternsPath = path.join(DATA_DIR, "patterns.json");
      if (existsSync(patternsPath)) {
        const raw = JSON.parse(await readFile(patternsPath, "utf-8"));
        this.patterns = new Map(Object.entries(raw));
      }
      const promptsPath = path.join(DATA_DIR, "prompts.json");
      if (existsSync(promptsPath)) {
        const raw = JSON.parse(await readFile(promptsPath, "utf-8"));
        this.prompts = new Map(Object.entries(raw));
      }
    } catch {
      // First run — start fresh
    }
  }

  _persistAsync() {
    // Fire-and-forget persistence
    const save = async () => {
      try {
        await writeFile(
          path.join(DATA_DIR, "ledger.json"),
          JSON.stringify(this.ledger.slice(-5000), null, 2) // Keep last 5000
        );
        await writeFile(
          path.join(DATA_DIR, "patterns.json"),
          JSON.stringify(Object.fromEntries(this.patterns), null, 2)
        );
        await writeFile(
          path.join(DATA_DIR, "prompts.json"),
          JSON.stringify(Object.fromEntries(this.prompts), null, 2)
        );
      } catch (err) {
        console.error("[Memory] Persist failed:", err.message);
      }
    };
    save();
  }
}

// Singleton
let _instance;
export async function getMemory() {
  if (!_instance) {
    _instance = await new SemanticMemory().init();
  }
  return _instance;
}
