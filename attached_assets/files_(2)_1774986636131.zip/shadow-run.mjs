/**
 * SHADOW RUN ENGINE
 * ─────────────────
 * Stage II of the Metacognitive Workflow.
 *
 * Before any real generation, the AI writes a 50-word plan explaining
 * HOW it will avoid the last N failures. This plan is then injected
 * into the actual generation prompt as constraints.
 *
 * Think → Check → Do
 */

import { getMemory } from "./memory.mjs";
import { callAI, MODEL_FAST, MODEL_REASONING } from "../ai/router.mjs";

/**
 * Run the Shadow (pre-flight) check for a content generation task.
 *
 * @param {Object} params
 * @param {string} params.contentType  - "article" | "image" | "video" | "podcast"
 * @param {string} params.topic
 * @param {string} params.originalPrompt - the prompt we WOULD send
 * @param {Object} params.conditions     - { promptComplexity, apiLatency }
 * @returns {Object} { plan, constraints, model, shouldProceed, prediction }
 */
export async function shadowRun({ contentType, topic, originalPrompt, conditions = {} }) {
  const memory = await getMemory();

  // ── I. INTENTION: Query Semantic Memory for Gold Standard ──
  const goldStandard = memory.getGoldStandard(contentType);
  const topFailures = memory.getTopFailures(contentType, 5);
  const recentFailures = memory.getRecentFailures(contentType, 5);
  const imageTrends = contentType === "image" ? memory.getImageAestheticTrend(10) : [];

  // ── FAILURE PREDICTION: Should we even attempt this? ──
  const prediction = memory.predictFailure(contentType, conditions);

  // Choose model based on prediction
  let selectedModel = MODEL_FAST;
  if (prediction.recommendation === "add_reasoning_step") {
    selectedModel = MODEL_REASONING;
  } else if (prediction.recommendation === "upgrade_model_and_add_reasoning") {
    selectedModel = MODEL_REASONING;
  }

  // ── II. PRE-FLIGHT: The "Shadow" Run ──
  // The AI must EXPLAIN its plan before generating.
  const highRiskFailures = topFailures.filter((f) => f.isHighRisk);
  const allFailureReasons = topFailures.map((f) => `- ${f.reason} (${f.frequency}x, score: ${f.confidenceScore})`).join("\n");

  const recentFailureDetails = recentFailures
    .slice(-3)
    .map((f) => `- Topic: "${f.topic}" | Reasons: ${f.failureReasons?.join(", ")}`)
    .join("\n");

  const shadowPrompt = `You are a Content Quality Strategist. Before we generate any content, you must create a pre-flight plan.

## CONTEXT
Content type: ${contentType}
Topic: "${topic}"

## GOLD STANDARD (what success looks like)
${goldStandard ? JSON.stringify(goldStandard, null, 2) : "No gold standard defined yet — use industry best practices."}

## TOP FAILURE PATTERNS (from our learning ledger)
${allFailureReasons || "No recorded failures yet — this is a first run."}

## RECENT FAILURES (last 3)
${recentFailureDetails || "None yet."}

${contentType === "image" ? `## IMAGE AESTHETIC CORRECTIONS NEEDED\n${imageTrends.map((c) => `- Issue: "${c.issue}" (${c.frequency}x) → Auto-prepend: "${c.correction}"`).join("\n") || "No corrections needed."}` : ""}

## HIGH-RISK PATTERNS (confidence score < 0.5 — MUST address)
${highRiskFailures.map((f) => `⚠️ "${f.reason}" — MANDATORY avoidance strategy required`).join("\n") || "None flagged."}

## YOUR TASK
Write a concise plan (max 75 words) explaining:
1. How you will avoid EACH high-risk failure pattern
2. What specific techniques you'll use for quality
3. Any constraints you're self-imposing

Then output a JSON block with:
\`\`\`json
{
  "plan": "your 75-word plan",
  "constraints": ["constraint 1", "constraint 2", ...],
  "imageCorrections": ["prepend string 1", ...],
  "confidence": 0.0-1.0,
  "shouldProceed": true/false
}
\`\`\`

If the failure rate is too high and you believe this generation will likely fail, set shouldProceed to false and explain why.`;

  try {
    const response = await callAI({
      model: MODEL_FAST, // Shadow run always uses fast model (cheap)
      messages: [{ role: "user", content: shadowPrompt }],
      maxTokens: 500,
    });

    const parsed = parseShadowResponse(response);

    return {
      plan: parsed.plan,
      constraints: parsed.constraints ?? [],
      imageCorrections: parsed.imageCorrections ?? imageTrends.map((c) => c.correction),
      shouldProceed: parsed.shouldProceed ?? true,
      confidence: parsed.confidence ?? 0.7,
      model: selectedModel,
      prediction,
      goldStandard,
      topFailures,
    };
  } catch (err) {
    // Shadow run failure should NOT block generation
    console.warn(`[ShadowRun] Pre-flight failed: ${err.message}. Proceeding with defaults.`);
    return {
      plan: "Shadow run failed — using default constraints.",
      constraints: highRiskFailures.map((f) => `Avoid: ${f.reason}`),
      imageCorrections: imageTrends.map((c) => c.correction),
      shouldProceed: true,
      confidence: 0.5,
      model: selectedModel,
      prediction,
      goldStandard,
      topFailures,
    };
  }
}

/**
 * BUILD THE CONSTRAINT-INJECTED PROMPT
 *
 * Stage III: Takes the Shadow Run output and wraps the original prompt
 * with self-imposed constraints, failure avoidance strategies, and
 * gold standard references.
 */
export function buildConstrainedPrompt({ originalPrompt, shadowResult, contentType }) {
  const { plan, constraints, imageCorrections, goldStandard } = shadowResult;

  // For images: prepend aesthetic corrections to the prompt
  if (contentType === "image") {
    const corrections = imageCorrections?.length ? `[${imageCorrections.join(", ")}] ` : "";
    return {
      prompt: `${corrections}${originalPrompt}`,
      systemPrompt: null, // Image APIs don't use system prompts
    };
  }

  // For text-based content: inject as system prompt preamble
  const constraintBlock = constraints.length
    ? `\n## MANDATORY CONSTRAINTS (from pre-flight analysis)\n${constraints.map((c, i) => `${i + 1}. ${c}`).join("\n")}`
    : "";

  const goldBlock = goldStandard
    ? `\n## GOLD STANDARD REFERENCE\nStructure: ${goldStandard.structure ?? "N/A"}\nTone: ${goldStandard.tone ?? "N/A"}\nLength: ${goldStandard.wordCount ?? "N/A"} words\nMust include: ${goldStandard.requiredElements?.join(", ") ?? "N/A"}`
    : "";

  const systemPrompt = `You are an expert content creator. Before generating, review your pre-flight plan:

## PRE-FLIGHT PLAN
${plan}
${constraintBlock}
${goldBlock}

CRITICAL: You MUST adhere to every constraint listed above. If you violate any constraint, the output will be rejected and you will need to regenerate.`;

  return {
    prompt: originalPrompt,
    systemPrompt,
  };
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

function parseShadowResponse(text) {
  // Extract JSON from the response
  const jsonMatch = text.match(/```json\s*([\s\S]*?)```/) ?? text.match(/\{[\s\S]*"plan"[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const raw = jsonMatch[1] ?? jsonMatch[0];
      return JSON.parse(raw);
    } catch {
      // Fall through to text parsing
    }
  }

  // Fallback: extract plan from plain text
  return {
    plan: text.slice(0, 300),
    constraints: [],
    confidence: 0.6,
    shouldProceed: true,
  };
}
