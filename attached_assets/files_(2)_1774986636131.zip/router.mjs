/**
 * AI ROUTER
 * ─────────
 * Unified interface for calling different AI models.
 * The metacognition layer uses this to dynamically switch
 * between fast (cheap) and reasoning (expensive) models
 * based on failure prediction.
 *
 * Replace the implementations with your actual API calls.
 */

// ── MODEL TIERS ──
export const MODEL_FAST = "fast";           // Gemini Flash, Claude Haiku, GPT-4o-mini
export const MODEL_STANDARD = "standard";   // Claude Sonnet, GPT-4o
export const MODEL_REASONING = "reasoning"; // Claude Opus/Sonnet with thinking, o1

// Map tiers to actual model IDs (configure per provider)
const MODEL_MAP = {
  anthropic: {
    [MODEL_FAST]: "claude-haiku-4-5-20251001",
    [MODEL_STANDARD]: "claude-sonnet-4-20250514",
    [MODEL_REASONING]: "claude-sonnet-4-20250514", // with extended thinking
  },
  openai: {
    [MODEL_FAST]: "gpt-4o-mini",
    [MODEL_STANDARD]: "gpt-4o",
    [MODEL_REASONING]: "o1",
  },
  google: {
    [MODEL_FAST]: "gemini-2.0-flash",
    [MODEL_STANDARD]: "gemini-2.0-pro",
    [MODEL_REASONING]: "gemini-2.0-pro", // with thinking
  },
};

const DEFAULT_PROVIDER = process.env.AI_PROVIDER ?? "anthropic";

/**
 * Unified AI call interface.
 *
 * @param {Object} params
 * @param {string} params.model      - MODEL_FAST | MODEL_STANDARD | MODEL_REASONING
 * @param {Array}  params.messages   - [{ role, content }]
 * @param {string} params.system     - system prompt
 * @param {number} params.maxTokens
 * @param {string} params.provider   - override provider
 * @returns {string} - the text response
 */
export async function callAI({
  model = MODEL_STANDARD,
  messages,
  system,
  maxTokens = 1024,
  provider = DEFAULT_PROVIDER,
}) {
  const modelId = MODEL_MAP[provider]?.[model] ?? model;
  const startTime = Date.now();

  try {
    let result;

    switch (provider) {
      case "anthropic":
        result = await callAnthropic({ modelId, messages, system, maxTokens });
        break;
      case "openai":
        result = await callOpenAI({ modelId, messages, system, maxTokens });
        break;
      case "google":
        result = await callGoogle({ modelId, messages, system, maxTokens });
        break;
      default:
        throw new Error(`Unknown AI provider: ${provider}`);
    }

    const latency = Date.now() - startTime;
    console.log(`  [AI] ${provider}/${modelId} → ${result.length} chars in ${latency}ms`);
    return result;
  } catch (err) {
    const latency = Date.now() - startTime;
    console.error(`  [AI] ${provider}/${modelId} FAILED in ${latency}ms: ${err.message}`);
    throw err;
  }
}

// ─────────────────────────────────────────
// PROVIDER IMPLEMENTATIONS
// ─────────────────────────────────────────

async function callAnthropic({ modelId, messages, system, maxTokens }) {
  const body = {
    model: modelId,
    max_tokens: maxTokens,
    messages,
  };
  if (system) body.system = system;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const error = new Error(err.error?.message ?? `Anthropic ${res.status}`);
    error.status = res.status;
    throw error;
  }

  const data = await res.json();
  return data.content.map((c) => c.text ?? "").join("\n");
}

async function callOpenAI({ modelId, messages, system, maxTokens }) {
  const msgs = system ? [{ role: "system", content: system }, ...messages] : messages;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: modelId,
      messages: msgs,
      max_tokens: maxTokens,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const error = new Error(err.error?.message ?? `OpenAI ${res.status}`);
    error.status = res.status;
    throw error;
  }

  const data = await res.json();
  return data.choices[0].message.content;
}

async function callGoogle({ modelId, messages, system, maxTokens }) {
  // Gemini API format
  const contents = messages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));

  const body = {
    contents,
    generationConfig: { maxOutputTokens: maxTokens },
  };
  if (system) {
    body.systemInstruction = { parts: [{ text: system }] };
  }

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:generateContent?key=${process.env.GOOGLE_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    const error = new Error(err.error?.message ?? `Google ${res.status}`);
    error.status = res.status;
    throw error;
  }

  const data = await res.json();
  return data.candidates[0].content.parts.map((p) => p.text).join("\n");
}
