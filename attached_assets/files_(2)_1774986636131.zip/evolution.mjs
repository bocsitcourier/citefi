/**
 * EVOLUTIONARY AGENT
 * ──────────────────
 * Runs every 6 hours (or on-demand). This is the "self-aware" part.
 *
 * It does three things:
 *   1. Reviews the learning ledger for recurring failures
 *   2. Rewrites agent system prompts with "Lessons Learned"
 *   3. Triggers self-correction when success rate drops below threshold
 *
 * This is the agent that makes the system IMPROVE ITSELF over time.
 */

import { getMemory } from "./memory.mjs";
import { callAI, MODEL_REASONING } from "../ai/router.mjs";

const SUCCESS_THRESHOLD = 0.8; // Trigger self-correction below this
const CONTENT_TYPES = ["article", "image", "video", "podcast"];

/**
 * Main evolution cycle. Call this from a cron job or scheduler.
 */
export async function runEvolutionCycle() {
  const memory = await getMemory();
  const report = {
    timestamp: new Date().toISOString(),
    actions: [],
    promptUpdates: [],
    selfCorrections: [],
  };

  console.log("\n🧬 [Evolution] Starting optimization cycle...\n");

  for (const contentType of CONTENT_TYPES) {
    const successRate = memory.getSuccessRate(contentType, 50);
    const topFailures = memory.getTopFailures(contentType, 5);
    const recentFailures = memory.getRecentFailures(contentType, 10);

    console.log(`  [${contentType}] Success rate: ${(successRate * 100).toFixed(1)}% | Top failures: ${topFailures.length}`);

    // ── STEP 1: Update agent prompts with lessons learned ──
    if (topFailures.length > 0) {
      const updatedPrompt = await evolveAgentPrompt(memory, contentType, topFailures);
      if (updatedPrompt) {
        report.promptUpdates.push({ contentType, ...updatedPrompt });
      }
    }

    // ── STEP 2: Self-correction if below threshold ──
    if (successRate < SUCCESS_THRESHOLD && recentFailures.length >= 3) {
      console.log(`  ⚠️ [${contentType}] Below ${SUCCESS_THRESHOLD * 100}% — triggering self-correction`);
      const correction = await selfCorrect(memory, contentType, recentFailures);
      if (correction) {
        report.selfCorrections.push({ contentType, ...correction });
      }
    }

    // ── STEP 3: Update gold standards if we have enough successful data ──
    if (successRate > 0.9) {
      await updateGoldStandard(memory, contentType);
      report.actions.push({ contentType, action: "gold_standard_check" });
    }
  }

  console.log(`\n🧬 [Evolution] Cycle complete. ${report.promptUpdates.length} prompts updated, ${report.selfCorrections.length} self-corrections.\n`);
  return report;
}

/**
 * EVOLVE AGENT PROMPT
 *
 * Rewrites the system prompt for a content type's agent,
 * injecting "Lessons Learned" from the failure ledger.
 */
async function evolveAgentPrompt(memory, contentType, topFailures) {
  const currentPrompt = memory.getAgentPrompt(contentType);
  const failureSummary = topFailures
    .map((f) => `- "${f.reason}" (${f.frequency}x, risk: ${f.isHighRisk ? "HIGH" : "normal"})`)
    .join("\n");

  const evolutionPrompt = `You are a Prompt Engineer optimizing an AI content generation agent.

## CURRENT SYSTEM PROMPT
${currentPrompt?.prompt ?? "No custom prompt — using defaults."}

## FAILURE ANALYSIS (from learning ledger)
These are the most common failures for "${contentType}" generation:
${failureSummary}

## YOUR TASK
Rewrite the system prompt to incorporate "Lessons Learned" that specifically address each failure pattern. The new prompt must:

1. Explicitly mention each high-risk failure pattern as a "DO NOT" rule
2. Include positive examples of what SHOULD be done instead
3. Be concise (under 300 words) — agents with bloated prompts perform worse
4. Preserve any existing good instructions from the current prompt

Respond with ONLY the new system prompt text, nothing else. No JSON, no markdown fences.`;

  try {
    const newPrompt = await callAI({
      model: MODEL_REASONING,
      messages: [{ role: "user", content: evolutionPrompt }],
      maxTokens: 800,
    });

    memory.setAgentPrompt(contentType, newPrompt.trim(), `Auto-evolved: addressed ${topFailures.length} failure patterns`);

    console.log(`  ✅ [${contentType}] Agent prompt evolved (v${(currentPrompt?.version ?? 0) + 1})`);
    return {
      previousVersion: currentPrompt?.version ?? 0,
      newVersion: (currentPrompt?.version ?? 0) + 1,
      addressedFailures: topFailures.map((f) => f.reason),
    };
  } catch (err) {
    console.error(`  ❌ [${contentType}] Prompt evolution failed: ${err.message}`);
    return null;
  }
}

/**
 * SELF-CORRECTION
 *
 * When an agent's success rate drops below threshold, the AI
 * analyzes its own failed outputs to find the common denominator.
 */
async function selfCorrect(memory, contentType, recentFailures) {
  const failureDetails = recentFailures
    .map(
      (f, i) =>
        `### Failure ${i + 1}
Topic: "${f.topic}"
Reasons: ${f.failureReasons?.join(", ") ?? "unknown"}
Shadow Plan: ${f.shadowPlan ?? "N/A"}
Jury Verdict: ${f.juryVerdict ?? "N/A"}`
    )
    .join("\n\n");

  const correctionPrompt = `You are a Quality Assurance Analyst performing ROOT CAUSE ANALYSIS on a failing AI content generation agent.

## AGENT TYPE: ${contentType}
## CURRENT SUCCESS RATE: ${(memory.getSuccessRate(contentType, 50) * 100).toFixed(1)}%
## THRESHOLD: ${SUCCESS_THRESHOLD * 100}%

## RECENT FAILURES (analyze these)
${failureDetails}

## YOUR TASK
Perform a structured root cause analysis:

1. **Common Denominator**: What single issue connects the majority of these failures?
2. **Root Cause**: Is the problem in the prompt, the model choice, the input data, or the validation criteria?
3. **Corrective Action**: Provide ONE specific, actionable change that would fix the most failures.
4. **New Constraint**: Write ONE new constraint to add to the shadow run.
5. **New Redline**: Should we add a new item to the redline list? If so, what?

Respond in JSON:
\`\`\`json
{
  "commonDenominator": "...",
  "rootCause": "prompt | model | input | validation",
  "correctiveAction": "...",
  "newConstraint": "...",
  "newRedline": "..." or null,
  "confidenceInFix": 0.0-1.0
}
\`\`\``;

  try {
    const response = await callAI({
      model: MODEL_REASONING,
      messages: [{ role: "user", content: correctionPrompt }],
      maxTokens: 600,
    });

    const parsed = parseJSON(response);

    if (parsed) {
      // Apply the corrective action: update the agent prompt with the new constraint
      const currentPrompt = memory.getAgentPrompt(contentType);
      const appendix = `\n\n## AUTO-CORRECTION (applied ${new Date().toISOString()})\nRoot cause: ${parsed.rootCause}\nNew constraint: ${parsed.newConstraint}\nAction: ${parsed.correctiveAction}`;

      memory.setAgentPrompt(
        contentType,
        (currentPrompt?.prompt ?? "") + appendix,
        `Self-correction: ${parsed.commonDenominator}`
      );

      console.log(`  🔧 [${contentType}] Self-correction applied: "${parsed.commonDenominator}"`);
      return parsed;
    }
  } catch (err) {
    console.error(`  ❌ [${contentType}] Self-correction failed: ${err.message}`);
  }
  return null;
}

/**
 * UPDATE GOLD STANDARD
 *
 * If a content type is performing well (>90%), analyze its
 * recent successes to refine the gold standard pattern.
 */
async function updateGoldStandard(memory, contentType) {
  const recentSuccesses = memory.ledger
    .filter((r) => r.contentType === contentType && r.success)
    .slice(-20);

  if (recentSuccesses.length < 10) return; // Not enough data

  const current = memory.getGoldStandard(contentType);

  // Only update every 50 generations
  const totalGens = memory.ledger.filter((r) => r.contentType === contentType).length;
  if (current && totalGens % 50 !== 0) return;

  const analysisPrompt = `Analyze these ${recentSuccesses.length} successful ${contentType} generations and extract the GOLD STANDARD pattern.

Recent successful topics: ${recentSuccesses.map((r) => r.topic).join(", ")}

What structural, tonal, and formatting patterns do these successes share?

Respond in JSON:
\`\`\`json
{
  "structure": "...",
  "tone": "...",
  "wordCount": "...",
  "requiredElements": ["element1", "element2"],
  "avoidElements": ["avoid1", "avoid2"],
  "qualityMarkers": ["marker1", "marker2"]
}
\`\`\``;

  try {
    const response = await callAI({
      model: MODEL_REASONING,
      messages: [{ role: "user", content: analysisPrompt }],
      maxTokens: 400,
    });

    const parsed = parseJSON(response);
    if (parsed) {
      memory.setGoldStandard(contentType, parsed);
      console.log(`  🏆 [${contentType}] Gold standard updated`);
    }
  } catch {
    // Non-critical
  }
}

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────

function parseJSON(text) {
  const match = text.match(/```json\s*([\s\S]*?)```/) ?? text.match(/\{[\s\S]*\}/);
  if (match) {
    try {
      return JSON.parse(match[1] ?? match[0]);
    } catch {
      return null;
    }
  }
  return null;
}

// ─────────────────────────────────────────
// SCHEDULER (call this from your app)
// ─────────────────────────────────────────

/**
 * Start the evolution loop. Runs every `intervalMs` (default 6 hours).
 */
export function startEvolutionLoop(intervalMs = 6 * 60 * 60 * 1000) {
  console.log(`🧬 [Evolution] Scheduled every ${intervalMs / 3600000}h`);

  // Run once immediately
  runEvolutionCycle().catch((err) => console.error("[Evolution] Cycle error:", err));

  // Then on interval
  return setInterval(() => {
    runEvolutionCycle().catch((err) => console.error("[Evolution] Cycle error:", err));
  }, intervalMs);
}
