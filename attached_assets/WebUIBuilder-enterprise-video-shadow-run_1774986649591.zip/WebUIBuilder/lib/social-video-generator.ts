export type {
  GenerateSocialVideoRequest,
  GenerateSocialVideoResult,
} from "./video-pipeline";

export { processSocialVideoJob as generateSocialVideo } from "./video-pipeline";
