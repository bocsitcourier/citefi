import { GoogleGenAI } from "@google/genai";
import Bottleneck from "bottleneck";
import { createBrandLockPromptSegment } from "./branding";
import type { ArticleShadowRunPlan } from "./article-shadow-run";
import { buildShadowRunPromptPreamble } from "./article-shadow-run";

if (!process.env.GEMINI_API_KEY) {
  throw new Error("GEMINI_API_KEY environment variable is required");
}

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Gemini 2.0 Flash: 10 RPM (requests per minute) limit - ACTUAL quota from Google
// Using Bottleneck for proper time-based rate limiting with retry on 429
const GEMINI_REQUESTS_PER_MINUTE = parseInt(process.env.GEMINI_RATE_LIMIT || "10");

// Dynamic concurrent limit based on rate limit tier
// Tier 1 (2000 RPM) needs higher concurrency than free tier (10 RPM)
const MAX_CONCURRENT_REQUESTS = Math.min(
  parseInt(process.env.ARTICLE_WORKER_CONCURRENCY || "50"),
  Math.max(10, Math.floor(GEMINI_REQUESTS_PER_MINUTE / 20)) // Scale with quota
);

// Bottleneck rate limiter with time-based quota enforcement
const geminiRateLimiter = new Bottleneck({
  reservoir: GEMINI_REQUESTS_PER_MINUTE, // Total requests allowed
  reservoirRefreshAmount: GEMINI_REQUESTS_PER_MINUTE, // Refill amount
  reservoirRefreshInterval: 60 * 1000, // Refill every 60 seconds
  maxConcurrent: MAX_CONCURRENT_REQUESTS, // Scale with API tier
  minTime: Math.floor((60 * 1000) / GEMINI_REQUESTS_PER_MINUTE), // Minimum time between requests
});

// Exponential backoff on 429 errors
geminiRateLimiter.on("failed", async (error, jobInfo) => {
  const isRateLimitError = error?.message?.includes("429") || error?.message?.includes("RESOURCE_EXHAUSTED");
  if (isRateLimitError && jobInfo.retryCount < 3) {
    const delay = Math.min(1000 * Math.pow(2, jobInfo.retryCount) + Math.random() * 1000, 10000);
    console.warn(`⚠️  Gemini rate limit hit, retrying in ${delay}ms (attempt ${jobInfo.retryCount + 1}/3)`);
    return delay;
  }
});

console.log(`🔧 Gemini rate limiter initialized: ${GEMINI_REQUESTS_PER_MINUTE} requests/minute, max ${MAX_CONCURRENT_REQUESTS} concurrent`);

/**
 * US State abbreviation to full name mapping
 */
const US_STATES: Record<string, string> = {
  'al': 'Alabama', 'ak': 'Alaska', 'az': 'Arizona', 'ar': 'Arkansas',
  'ca': 'California', 'co': 'Colorado', 'ct': 'Connecticut', 'de': 'Delaware',
  'fl': 'Florida', 'ga': 'Georgia', 'hi': 'Hawaii', 'id': 'Idaho',
  'il': 'Illinois', 'in': 'Indiana', 'ia': 'Iowa', 'ks': 'Kansas',
  'ky': 'Kentucky', 'la': 'Louisiana', 'me': 'Maine', 'md': 'Maryland',
  'ma': 'Massachusetts', 'mi': 'Michigan', 'mn': 'Minnesota', 'ms': 'Mississippi',
  'mo': 'Missouri', 'mt': 'Montana', 'ne': 'Nebraska', 'nv': 'Nevada',
  'nh': 'New Hampshire', 'nj': 'New Jersey', 'nm': 'New Mexico', 'ny': 'New York',
  'nc': 'North Carolina', 'nd': 'North Dakota', 'oh': 'Ohio', 'ok': 'Oklahoma',
  'or': 'Oregon', 'pa': 'Pennsylvania', 'ri': 'Rhode Island', 'sc': 'South Carolina',
  'sd': 'South Dakota', 'tn': 'Tennessee', 'tx': 'Texas', 'ut': 'Utah',
  'vt': 'Vermont', 'va': 'Virginia', 'wa': 'Washington', 'wv': 'West Virginia',
  'wi': 'Wisconsin', 'wy': 'Wyoming', 'dc': 'District of Columbia'
};

/**
 * Common US city abbreviations to full names
 * Covers top 30 metros to handle 80%+ of real-world use cases
 */
const CITY_ABBREVIATIONS: Record<string, string> = {
  'la': 'los angeles',
  'sf': 'san francisco',
  'sd': 'san diego',
  'nyc': 'new york city',
  'phx': 'phoenix',
  'stl': 'st louis',
  'kc': 'kansas city',
  'dc': 'washington',
  'atl': 'atlanta',
  'chi': 'chicago',
  'hou': 'houston',
  'dal': 'dallas',
  'sa': 'san antonio',
  'philly': 'philadelphia',
  'vegas': 'las vegas',
  'pdx': 'portland',
  'sea': 'seattle',
  'den': 'denver',
  'mia': 'miami',
  'bos': 'boston',
};

/**
 * Normalize state to full name
 * Handles both abbreviations and full names (case-insensitive)
 */
function normalizeState(state: string): string {
  const stateLower = state.toLowerCase().trim();
  
  // Check if it's an abbreviation
  if (US_STATES[stateLower]) {
    return US_STATES[stateLower];
  }
  
  // Check if it's already a full state name
  const stateValues = Object.values(US_STATES).map(s => s.toLowerCase());
  if (stateValues.includes(stateLower)) {
    // Return with proper capitalization
    return Object.values(US_STATES).find(s => s.toLowerCase() === stateLower) || state;
  }
  
  // Not a recognized state, return as-is
  return state;
}

/**
 * Check if a string is a US state (abbreviation or full name)
 */
function isUSState(text: string): boolean {
  const textLower = text.toLowerCase().trim();
  
  // Check abbreviations
  if (US_STATES[textLower]) {
    return true;
  }
  
  // Check full names
  const stateValues = Object.values(US_STATES).map(s => s.toLowerCase());
  return stateValues.includes(textLower);
}

/**
 * Parse multiple cities from a comma-separated string
 * Handles formats like:
 * - "Boston, Massachusetts, Hartford, CT, NY, NY"
 * - "Boston, Hartford, Albany"  
 * - "Seattle, WA"
 * - "Austin, Texas, Miami, FL"
 * 
 * Returns array of normalized city locations with full state names
 */
export function parseMultipleCities(geographicFocus: string): string[] {
  if (!geographicFocus || !geographicFocus.trim()) {
    return [];
  }

  // Split by both comma AND pipe, then clean up each part
  const parts = geographicFocus
    .split(/[,|]/)
    .map(p => p.trim())
    .map(p => p.replace(/\.$/, '')) // Strip trailing periods (e.g., "MA." → "MA")
    .filter(Boolean);
  
  if (parts.length === 0) return [];
  if (parts.length === 1) return [parts[0]];
  if (parts.length === 2) {
    // Single city, state pair - normalize state (after stripping punctuation)
    const [city, state] = parts;
    if (isUSState(state)) {
      return [`${city}, ${normalizeState(state)}`];
    }
    return [geographicFocus.trim()];
  }

  const cities: string[] = [];
  let i = 0;

  while (i < parts.length) {
    const currentPart = parts[i];
    const nextPart = i + 1 < parts.length ? parts[i + 1] : null;

    // Check if next part is a US state (after punctuation has been stripped)
    const isNextPartState = nextPart && isUSState(nextPart);

    if (isNextPartState) {
      // Combine current part with normalized state
      cities.push(`${currentPart}, ${normalizeState(nextPart!)}`);
      i += 2; // Skip both parts
    } else {
      // Standalone city
      cities.push(currentPart);
      i += 1;
    }
  }

  return cities;
}

export async function throttledGeminiRequest<T>(fn: () => Promise<T>): Promise<T> {
  return geminiRateLimiter.schedule(() => fn());
}

export function getGeminiRateLimitConfig() {
  return {
    requestsPerMinute: GEMINI_REQUESTS_PER_MINUTE,
    concurrentLimit: GEMINI_REQUESTS_PER_MINUTE,
    isThrottlingEnabled: true,
  };
}

export interface TitlePoolResult {
  titles: string[];
  primaryKeywords: string[];
  contentStrategy: string;
  coverageMapping: Array<{
    title: string;
    subtopicCategory: 'types' | 'costs' | 'laws' | 'providers' | 'faqs' | 'best_practices' | 'neighborhoods';
    clusterPillar: string;
    eatSignals: Array<'experience' | 'expertise' | 'authoritativeness' | 'trustworthiness'>;
    answerFirstFraming: boolean;
  }>;
}

export interface MultiCityTitlePoolResult {
  cities: {
    location: string;
    titles: string[];
    primaryKeywords: string[];
    contentStrategy: string;
  }[];
  combinedTitles: string[];
  combinedKeywords: string[];
}

export async function generateTitlePool(
  coreTopic: string,
  targetUrl: string,
  numTitles: number = 50,
  tone?: string,
  geographicFocus?: string,
  audience?: string,
  redditQuestions?: Array<{question: string, upvotes: number, subreddit: string}>
): Promise<TitlePoolResult> {
  // Require geographic focus for local SEO
  if (!geographicFocus) {
    throw new Error("Geographic focus is required for location-optimized SEO titles");
  }

  const audienceContext = audience ? `\nTarget Audience: ${audience}` : "";
  const toneContext = tone ? `\nTone: ${tone}` : "";
  
  // ENHANCED v3.0: Reddit research integration for intent-based title generation
  // SAFETY: Include Reddit context only if data is actually available
  const redditContext = redditQuestions && redditQuestions.length > 0 
    ? `\n\n**🔥 REDDIT RESEARCH - REAL USER INTENT (HIGH PRIORITY):**

We've mined ${redditQuestions.length} actual questions from Reddit that real ${geographicFocus} users are asking about ${coreTopic}. These are AUTHENTIC user intents - prioritize them!

**Top Reddit Questions (sorted by upvotes - highest engagement first):**
${redditQuestions.slice(0, 15).map((q, i) => `${i+1}. "${q.question}" (${q.upvotes} upvotes on r/${q.subreddit})`).join('\n')}

**INSTRUCTION:** Use these Reddit questions as the foundation for your titles. Transform them into answer-first, location-optimized titles that directly address these real user needs. These questions reveal actual pain points and information gaps - your titles should promise to answer them comprehensively.

Examples of Reddit-to-Title transformation:
- Reddit: "What's the average cost?" → Title: "How Much Does ${coreTopic} Cost in ${geographicFocus}? 2025 Price Analysis"
- Reddit: "Are there any good providers near me?" → Title: "Best ${coreTopic} Providers in ${geographicFocus}: Expert Ratings & Reviews"
- Reddit: "What are the regulations?" → Title: "What are ${geographicFocus} ${coreTopic} Laws? Complete Regulatory Guide 2025"
` 
    : `\n\n**NOTE:** Reddit research data not available for this batch. Generate titles based on standard SEO best practices and coverage pillars.`;

  const prompt = `You are an expert content strategist implementing Lily Ray's AEO (Answer Engine Optimization) methodology, specializing in E-E-A-T signals and answer-first structure for AI citations. Generate ${numTitles} unique, strategic article titles optimized for both traditional SEO and AI Overviews.

**CORE PARAMETERS:**
Core Topic: ${coreTopic}
Target URL: ${targetUrl}
Geographic Location (REQUIRED): ${geographicFocus}${audienceContext}${toneContext}${redditContext}

**CRITICAL REQUIREMENT:** EVERY SINGLE TITLE MUST INCLUDE LOCATION INFORMATION

**ANSWER-FIRST TITLE FRAMING (Lily Ray Methodology):**

Titles must promise DIRECT, COMPLETE ANSWERS that AI can extract and cite:
- Use question-based formats: "What is...", "How to...", "Why [LOCATION] Needs...", "When to..."
- Promise immediate value: "Complete Guide to...", "Expert Analysis:", "[TOPIC] Explained"
- Front-load the answer hint: "Yes, [TOPIC] is... (Here's What [LOCATION] Residents Should Know)"
- Make titles quotable: Use authoritative language AI models will cite

GOOD EXAMPLES (Answer-First):
✓ "What is [TOPIC] in ${geographicFocus}? Complete 2025 Guide with Local Regulations"
✓ "How ${geographicFocus} [TOPIC] Works: Expert Analysis with Neighborhood Data"
✓ "Why ${geographicFocus} Needs [TOPIC]: Statistics, Laws, and Local Solutions"
✓ "${geographicFocus} [TOPIC] Guide: What You Need to Know (Costs, Regulations, Providers)"

BAD EXAMPLES (Vague, No Answer Promise):
✗ "Everything About [TOPIC]" (no location, no specificity)
✗ "The Ultimate ${geographicFocus} Guide" (no clear answer)
✗ "Learn More About [TOPIC]" (weak promise)

**COVERAGE PILLAR MAPPING (Content Cluster Architecture):**

Distribute titles across these subtopic categories (aim for balanced coverage):

1. **Types/Options** (15-20% of titles):
   - "Types of [TOPIC] Available in ${geographicFocus}: Complete 2025 Comparison"
   - "What [TOPIC] Options Exist in ${geographicFocus}? Expert Breakdown"

2. **Costs/Pricing** (15-20%):
   - "How Much Does [TOPIC] Cost in ${geographicFocus}? 2025 Price Analysis"
   - "${geographicFocus} [TOPIC] Pricing Guide: What to Expect in [Neighborhoods]"

3. **Laws/Regulations** (10-15%):
   - "What are ${geographicFocus} [TOPIC] Laws? Complete Regulatory Guide 2025"
   - "${geographicFocus} [TOPIC] Regulations: What Local Businesses Must Know"

4. **Providers/Services** (15-20%):
   - "Best [TOPIC] Providers in ${geographicFocus}: Expert Ratings & Reviews"
   - "How to Choose [TOPIC] Services in ${geographicFocus}: Local Comparison"

5. **FAQs/Common Questions** (10-15%):
   - "Top 10 ${geographicFocus} [TOPIC] Questions Answered by Local Experts"
   - "What ${geographicFocus} Residents Ask About [TOPIC]: Complete FAQ"

6. **Best Practices/How-To** (15-20%):
   - "How to [ACTION] in ${geographicFocus}: Step-by-Step Expert Guide"
   - "Best Practices for [TOPIC] in ${geographicFocus}: 2025 Expert Recommendations"

7. **Neighborhood/ZIP-Specific** (10-15%):
   - "[Specific Neighborhood] [TOPIC] Guide: What Makes This Area Unique"
   - "[ZIP Code] [TOPIC]: Local Statistics, Regulations, and Options"

**E-E-A-T SIGNAL REQUIREMENTS (Google Quality Guidelines):**

Titles must demonstrate Experience, Expertise, Authoritativeness, Trustworthiness:

**Experience Signals:**
- "Our 15-Year Guide to ${geographicFocus} [TOPIC]"
- "${geographicFocus} [TOPIC]: Insights from 500+ Local Cases"

**Expertise Signals:**
- "Expert Analysis: ${geographicFocus} [TOPIC] Technical Deep-Dive"
- "Professional Guide to ${geographicFocus} [TOPIC]: Industry Insights"

**Authoritativeness Signals:**
- "Comprehensive ${geographicFocus} [TOPIC] Resource: Data-Backed Analysis"
- "Definitive ${geographicFocus} [TOPIC] Guide: Research & Statistics"

**Trustworthiness Signals:**
- "${geographicFocus} [TOPIC] Guide: 2025 Updated with Latest Regulations"
- "${geographicFocus} [TOPIC]: Verified Data from Official Sources"

**LOCAL SEO OPTIMIZATION (MANDATORY):**

Every title MUST include location information:
- City-level: "${geographicFocus} [TOPIC]"
- Neighborhood-level: "[Actual Neighborhood Name] [TOPIC] Guide"
- ZIP-specific: "[ZIP Code] Area [TOPIC]: What Residents Need to Know"
- Proximity: "[TOPIC] Near ${geographicFocus}", "[TOPIC] in the ${geographicFocus} Area"

USE REAL NAMES ONLY - Never use [brackets], [placeholders], or generic terms like [Hospital], [Landmark]

**TECHNICAL SEO REQUIREMENTS:**

1. **Length**: 50-70 characters optimal (can go to 80 for long-tail)
2. **Intent Mix**: Distribute across informational (40%), transactional (30%), navigational (30%)
3. **Keyword Placement**: Target keyword in first 5 words when possible
4. **Freshness**: Include "2025", "Latest", "Updated" for time-sensitive topics
5. **Schema-Ready**: Use formats AI can easily extract (Q&A, How-To, List)

**STRATEGIC DEPTH:**

- Go beyond surface-level topics - show LOCAL thought leadership
- Include frameworks, methodologies specific to ${geographicFocus} market
- Address complex scenarios in the local context
- Create content worthy of local bookmarking and AI citation

**REQUIRED OUTPUT STRUCTURE:**

Return ONLY valid JSON with enhanced coverage mapping:

{
  "titles": ["title1", "title2", ... ${numTitles} titles total],
  "primaryKeywords": ["keyword1", "keyword2", ... 10 keywords],
  "contentStrategy": "brief strategy recommendation",
  "coverageMapping": [
    {
      "title": "exact title from titles array",
      "subtopicCategory": "types | costs | laws | providers | faqs | best_practices | neighborhoods",
      "clusterPillar": "main topic pillar",
      "eatSignals": ["experience", "expertise", "authoritativeness", "trustworthiness"],
      "answerFirstFraming": true | false
    }
  ]
}

**QUALITY CHECKLIST (Self-Audit Before Returning):**
✓ Every title includes ${geographicFocus} or specific neighborhood/ZIP
✓ At least 60% of titles use answer-first question formats
✓ Coverage categories balanced across 7 pillars
✓ Each title has at least 1 E-E-A-T signal
✓ No generic/vague titles - all promise specific value
✓ No [placeholders] or [brackets] - only real names
✓ Titles optimized for AI extraction and citation`;

  console.log(`🤖 Calling Gemini API for ${numTitles} titles...`);
  const result = await throttledGeminiRequest(() => genAI.models.generateContent({
    model: "gemini-2.0-flash",  // Stable production model with 2000 RPM Tier 1 quota
    contents: [
      {
        role: "user",
        parts: [{ text: prompt }],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: "object",
        properties: {
          titles: {
            type: "array",
            items: { type: "string" },
            description: `Array of ${numTitles} unique, answer-first SEO-optimized article titles`
          },
          primaryKeywords: {
            type: "array",
            items: { type: "string" },
            description: "Top 10 primary keywords for SEO strategy"
          },
          contentStrategy: {
            type: "string",
            description: "Brief content strategy recommendation (2-3 sentences)"
          },
          coverageMapping: {
            type: "array",
            items: {
              type: "object",
              properties: {
                title: { type: "string" },
                subtopicCategory: { 
                  type: "string",
                  enum: ["types", "costs", "laws", "providers", "faqs", "best_practices", "neighborhoods"]
                },
                clusterPillar: { type: "string" },
                eatSignals: { 
                  type: "array",
                  items: { 
                    type: "string",
                    enum: ["experience", "expertise", "authoritativeness", "trustworthiness"]
                  }
                },
                answerFirstFraming: { type: "boolean" }
              },
              required: ["title", "subtopicCategory", "clusterPillar", "eatSignals", "answerFirstFraming"]
            },
            description: "Coverage pillar mapping for content cluster architecture"
          }
        },
        required: ["titles", "primaryKeywords", "contentStrategy", "coverageMapping"]
      }
    }
  }));
  console.log(`✅ Gemini API returned response`);

  let responseText = result.text || "";
  if (!responseText) {
    throw new Error("No response text from Gemini");
  }
  
  // Strip markdown code fences if present
  responseText = responseText.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
  
  const parsed = JSON.parse(responseText) as TitlePoolResult;
  
  if (!parsed.titles || parsed.titles.length < numTitles - 5) {
    throw new Error(`Expected ${numTitles} titles, received ${parsed.titles?.length || 0}`);
  }

  // CRITICAL: Validate that titles include geographic location
  // This enforces the mandatory location-based SEO requirement
  // We allow hyper-local variations (neighborhoods, districts) which are superior for local SEO
  
  // Common stop words to filter out (but keep geographic abbreviations)
  const stopWords = new Set(['in', 'of', 'the', 'and', 'or', 'at', 'to', 'for', 'on']);
  
  // Build location tokens from the raw input
  // Strip punctuation (especially trailing periods like "MA.") before tokenizing
  const rawTokens = geographicFocus
    .toLowerCase()
    .replace(/\.$/, '') // Remove trailing periods
    .split(/[\s,|]+/) // Split on spaces, commas, and pipes
    .map(token => token.replace(/\.$/, '')) // Strip periods from individual tokens
    .filter(token => {
      // Keep if not a stop word and has length
      return Boolean(token) && !stopWords.has(token);
    });
  
  // Add normalized state names for any state abbreviations
  const stateTokens: string[] = [];
  for (const token of rawTokens) {
    // Token is already cleaned of punctuation
    if (US_STATES[token]) {
      const fullStateName = US_STATES[token].toLowerCase();
      stateTokens.push(fullStateName); // e.g., "new york"
      // Also add words from multi-word state names
      const stateWords = fullStateName.split(/\s+/).filter(w => w.length > 2);
      stateTokens.push(...stateWords); // e.g., ["new", "york"]
    }
  }
  
  // Add normalized city names for common abbreviations
  const cityTokens: string[] = [];
  for (const token of rawTokens) {
    if (CITY_ABBREVIATIONS[token]) {
      const fullCityName = CITY_ABBREVIATIONS[token];
      cityTokens.push(fullCityName); // e.g., "los angeles"
      // Also add words from multi-word city names
      const cityWords = fullCityName.split(/\s+/).filter(w => w.length > 2);
      cityTokens.push(...cityWords); // e.g., ["los", "angeles"]
    }
  }
  
  // Combine all tokens - includes abbreviations + full names for both cities and states
  const locationTokens = [...new Set([...rawTokens, ...stateTokens, ...cityTokens])].filter(Boolean);
  
  console.log(`🔍 Location validation tokens for "${geographicFocus}": ${locationTokens.join(', ')}`);
  
  const hyperLocalIndicators = [
    'local', 'neighborhood', 'area', 'district', 'downtown', 'near',
    'community', 'region', 'zone', 'metro'
  ];
  
  let titlesWithLocation = 0;
  const titlesWithoutLocation: string[] = [];
  
  for (const title of parsed.titles) {
    const titleLower = title.toLowerCase();
    
    // Check if title contains main location tokens OR hyper-local indicators
    const hasMainLocation = locationTokens.some(token => titleLower.includes(token));
    const hasHyperLocal = hyperLocalIndicators.some(indicator => titleLower.includes(indicator));
    
    // Title is valid if it has main location OR is clearly hyper-local
    if (hasMainLocation || hasHyperLocal) {
      titlesWithLocation++;
    } else {
      titlesWithoutLocation.push(title);
    }
  }
  
  // Require at least 80% of titles to have location/hyper-local context
  // This allows for some variation while ensuring strong local SEO focus
  const locationPercentage = (titlesWithLocation / parsed.titles.length) * 100;
  const REQUIRED_PERCENTAGE = 80;
  
  if (locationPercentage < REQUIRED_PERCENTAGE) {
    const errorDetails = titlesWithoutLocation.slice(0, 3).join('", "');
    throw new Error(
      `Location validation failed: Only ${Math.round(locationPercentage)}% of titles contain location context (minimum: ${REQUIRED_PERCENTAGE}%). ` +
      `${titlesWithoutLocation.length} title(s) lack geographic focus "${geographicFocus}". ` +
      `Examples: "${errorDetails}". Please try again.`
    );
  }
  
  console.log(`✅ Location validation passed: ${titlesWithLocation}/${parsed.titles.length} titles (${Math.round(locationPercentage)}%) include location or hyper-local context`);

  return parsed;
}

/**
 * Generate titles for multiple cities
 * Splits geographic focus into multiple cities and generates separate title pools for each
 */
export async function generateTitlePoolForMultipleCities(
  coreTopic: string,
  targetUrl: string,
  numTitlesPerCity: number = 25,
  tone?: string,
  geographicFocus?: string,
  audience?: string
): Promise<MultiCityTitlePoolResult> {
  if (!geographicFocus) {
    throw new Error("Geographic focus is required for location-optimized SEO titles");
  }

  // Parse multiple cities from the input
  const cities = parseMultipleCities(geographicFocus);
  
  if (cities.length === 0) {
    throw new Error("No valid cities found in geographic focus");
  }

  console.log(`📍 Detected ${cities.length} cities: ${cities.join(' | ')}`);
  console.log(`🚀 Generating ${numTitlesPerCity} titles for EACH city (${cities.length * numTitlesPerCity} total titles)`);

  // Generate titles for each city in parallel
  const cityResults = await Promise.all(
    cities.map(async (city) => {
      console.log(`  🏙️ Generating titles for: ${city}`);
      const result = await generateTitlePool(
        coreTopic,
        targetUrl,
        numTitlesPerCity,
        tone,
        city, // Each city gets its own title pool
        audience
      );
      
      console.log(`  ✅ Generated ${result.titles.length} titles for ${city}`);
      
      return {
        location: city,
        titles: result.titles,
        primaryKeywords: result.primaryKeywords,
        contentStrategy: result.contentStrategy,
      };
    })
  );

  // Combine all titles and keywords
  const combinedTitles = cityResults.flatMap(r => r.titles);
  const allKeywords = cityResults.flatMap(r => r.primaryKeywords);
  const combinedKeywords = [...new Set(allKeywords)]; // Deduplicate keywords

  console.log(`✅ Multi-city title generation complete: ${combinedTitles.length} total titles across ${cities.length} cities`);

  return {
    cities: cityResults,
    combinedTitles,
    combinedKeywords,
  };
}

export interface ArticleGenerationResult {
  articleText: string;
  seoTitle: string;
  metaDescription: string;
  slug: string;
  keywords: string[];
  hashtags: string[];
  faq: Array<{ question: string; answer: string }>;
  imagePrompts: string[];
  wordCount: number;
}

export async function generateArticleContent(
  title: string,
  targetUrl: string,
  wordCountMin: number = 800,
  wordCountMax: number = 2000,
  tone?: string,
  geographicFocus?: string,
  audience?: string,
  businessName?: string,
  customInstructions?: string,
  companyLogoUrl?: string,
  batchId?: number, // NEW: Batch ID for SEO cache lookup
  shadowRunPlan?: ArticleShadowRunPlan,
): Promise<ArticleGenerationResult> {
  // CRITICAL: Require businessName to prevent generic placeholder generation
  if (!businessName || businessName.trim().length === 0) {
    throw new Error(
      "CRITICAL: businessName is REQUIRED for article generation. " +
      "Cannot generate content with generic 'company' placeholders - this defeats brand lock protection. " +
      "All image prompts and content must reference the actual business name to prevent AI hallucination."
    );
  }
  
  // OPTIMIZATION: Fetch batch-level SEO cache if available (30-50% API call reduction)
  let batchSeoContext: string = "";
  if (batchId) {
    try {
      const { getBatchSeoCache } = await import("./batch-seo-cache");
      const seoCache = await getBatchSeoCache(batchId);
      
      if (seoCache) {
        console.log(`✅ [CACHE HIT] Using batch SEO cache for article generation (batch ${batchId})`);
        
        // NULL-SAFE: Provide defaults for array fields to prevent .join() errors
        const landmarks = seoCache.locationAnalysis?.landmarks || [];
        const locationKeywords = seoCache.locationKeywords || [];
        const primaryTopics = seoCache.semanticClusters?.primary || [];
        const secondaryTopics = seoCache.semanticClusters?.secondary || [];
        const relatedTopics = seoCache.semanticClusters?.related || [];
        const expertiseAreas = seoCache.topicalAuthority?.expertiseAreas || [];
        const trustSignals = seoCache.topicalAuthority?.trustSignals || [];
        const commonThemes = seoCache.competitorInsights?.commonThemes || [];
        const contentGaps = seoCache.competitorInsights?.contentGaps || [];
        const uniqueAngles = seoCache.competitorInsights?.uniqueAngles || [];
        const competitorKeywords = seoCache.competitorKeywords || [];
        
        // NULL-SAFE: Extract v2.0 enhanced fields
        const zipCodes = seoCache.locationAnalysis?.zipCodes || [];
        const neighborhoods = seoCache.locationAnalysis?.neighborhoods || [];
        const population = seoCache.locationAnalysis?.population || '';
        const medianIncome = seoCache.locationAnalysis?.medianIncome || '';
        const localRegulations = seoCache.localRegulations || [];
        const authorityEntities = seoCache.authorityEntities || [];
        const keyStatistics = seoCache.keyStatistics || [];
        
        // NULL-SAFE: Extract v3.0 Reddit research (intent-based content gap analysis)
        const redditQuestions = seoCache.redditResearch?.questions || [];
        const redditDiscussions = seoCache.redditResearch?.discussions || [];
        const redditContentGaps = seoCache.redditResearch?.contentGaps || [];
        const redditSubreddits = seoCache.redditResearch?.subreddits || [];
        
        // PHASE 1: Consolidated Intent Outline (structured H2 themes from raw Reddit data)
        const consolidatedOutline = seoCache.redditResearch?.consolidatedOutline;
        
        // Inject cached SEO context into prompt (v3.0 ENHANCED with Reddit)
        batchSeoContext = `\n\n**PRE-GENERATED BATCH SEO CONTEXT v3.0** (MANDATORY: Use this deep local intelligence + Reddit research):

**Location Intelligence** (${geographicFocus}):
- Demographics: ${seoCache.locationAnalysis?.demographics || 'Not provided'}
- Key Landmarks: ${landmarks.length > 0 ? landmarks.join(", ") : 'Not provided'}
- Local Culture: ${seoCache.locationAnalysis?.localCulture || 'Not provided'}
- Economic Context: ${seoCache.locationAnalysis?.economicContext || 'Not provided'}
${zipCodes.length > 0 ? `- **ZIP Codes** (MENTION IN FIRST 3 PARAGRAPHS): ${zipCodes.join(", ")}` : ''}
${neighborhoods.length > 0 ? `- **Neighborhoods** (MENTION IN FIRST 3 PARAGRAPHS): ${neighborhoods.join(", ")}` : ''}
${population ? `- **Population**: ${population}` : ''}
${medianIncome ? `- **Median Income**: ${medianIncome}` : ''}

**Location-Specific Keywords** (naturally weave these into content):
${locationKeywords.length > 0 ? locationKeywords.join(", ") : 'Not provided'}

${localRegulations.length > 0 ? `**Local Regulations** (CITE FOR AUTHORITY):
${localRegulations.map(r => `- ${r.title} (${r.category}): ${r.description}${r.effectiveDate ? ` [Effective: ${r.effectiveDate}]` : ''}${r.sourceUrl ? ` [Source: ${r.sourceUrl}]` : ''}`).join('\n')}` : ''}

${authorityEntities.length > 0 ? `**Authority Entities** (CITE FOR E-E-A-T):
${authorityEntities.map(e => `- ${e.name} (${e.type}, credibility: ${e.credibilityScore}/100): ${e.description}${e.citationUrl ? ` [${e.citationUrl}]` : ''}${e.freshnessYear ? ` [${e.freshnessYear}]` : ''}`).join('\n')}` : ''}

${keyStatistics.length > 0 ? `**Key Statistics** (USE IN FIRST 2-3 PARAGRAPHS):
${keyStatistics.map(s => `- ${s.claim}: ${s.value} (Source: ${s.source}, ${s.year})`).join('\n')}` : ''}

${consolidatedOutline && consolidatedOutline.consolidatedIntents?.length > 0 ? `**🔥 PHASE 1: CONSOLIDATED REDDIT OUTLINE - STRUCTURED USER INTENT** (HIGHEST PRIORITY):

This is a professionally analyzed outline derived from ${redditQuestions.length} Reddit discussions. Each theme below represents a cluster of user questions transformed into AEO-compliant H2 headings with authentic experience proof.

**Target Audience:** ${consolidatedOutline.targetAudience}
**Overall Theme:** ${consolidatedOutline.overallTheme}

**YOUR ARTICLE STRUCTURE (USE THESE H2 HEADINGS):**

${consolidatedOutline.consolidatedIntents.map((intent: any, i: number) => `
${i+1}. **H2:** "${intent.h2Question}"
   - **Core Intent:** ${intent.coreIntent}
   - **Coverage Pillar:** ${intent.coveragePillar}
   - **Experience Proof (E-E-A-T):** ${intent.experienceProof}
   - **Prevalence:** ${intent.prevalence}
   - **Supporting Questions:** ${intent.supportingQuestions.slice(0, 3).join('; ')}
   
   **INSTRUCTION:** Create a comprehensive section answering this H2. Incorporate the experience proof naturally as real-world evidence. Reference it as "Users in ${geographicFocus} report...", "According to local community discussions...", or "Real experiences from ${geographicFocus} residents show..."
`).join('\n')}

**CRITICAL REQUIREMENTS:**
1. Use the H2 questions EXACTLY as written above (they are pre-optimized for AEO)
2. Each H2 section must incorporate its experience proof authentically
3. Structure follows user intent priority (most prevalent themes first)
4. Answer each H2 comprehensively in 2-4 paragraphs (Mike King format)
5. Include relevant supporting questions as H3 subsections where appropriate` : (
// FALLBACK: If Phase 1 consolidation failed, use raw Reddit data
redditQuestions.length > 0 || redditDiscussions.length > 0 ? `**🔥 REDDIT RESEARCH - REAL USER INTENT & E-E-A-T PROOF** (HIGHEST PRIORITY):

${redditQuestions.length > 0 ? `**Reddit Questions Mined** (${redditQuestions.length} total from ${redditSubreddits.join(', ')}):
Use these as H2/H3 headings and answer them directly in the article:
${redditQuestions.slice(0, 10).map((q: any, i: number) => `${i+1}. "${q.question}" (${q.upvotes} upvotes on r/${q.subreddit})`).join('\n')}

**INSTRUCTION:** Structure your H2/H3 headings based on these questions. For example:
- Reddit Q: "What's the average cost?" → H2: "What Does ${title.split(':')[0]} Cost in ${geographicFocus}?"
- Reddit Q: "Are there any regulations?" → H2: "What ${geographicFocus} Regulations Apply to ${title.split(':')[0]}?"` : ''}

${redditDiscussions.length > 0 ? `\n**Reddit Discussions for E-E-A-T Proof** (${redditDiscussions.length} upvoted discussions):
Use these as Experience signals - reference real user experiences:
${redditDiscussions.slice(0, 5).map((d: any, i: number) => `${i+1}. "${d.title}" (${d.upvotes} upvotes on r/${d.subreddit})\n   E-E-A-T Proof: ${d.eatProof}`).join('\n\n')}

**E-E-A-T INTEGRATION:** Reference these discussions as "Reddit users in ${geographicFocus} report...", "Common experiences shared in local forums...", "According to ${geographicFocus} community discussions..."` : ''}

${redditContentGaps.length > 0 ? `\n**Content Gaps to Address** (What Reddit users want but can't find):
${redditContentGaps.map((gap: any) => `- ${gap.gap} (${gap.prevalence} mentions across ${gap.subreddits.join(', ')})`).join('\n')}

**INSTRUCTION:** Make sure your article addresses these specific gaps that competitors are missing.` : ''}
` : ''
)}

${seoCache.competitorInsights && (commonThemes.length > 0 || contentGaps.length > 0) ? `**Competitive Intelligence**:
${commonThemes.length > 0 ? `- Common Themes: ${commonThemes.join(", ")}` : ''}
${contentGaps.length > 0 ? `- Content Gaps to Exploit: ${contentGaps.join(", ")}` : ''}
${uniqueAngles.length > 0 ? `- Unique Differentiation Angles: ${uniqueAngles.join(", ")}` : ''}

${competitorKeywords.length > 0 ? `**Competitor Keywords** (avoid overusing, focus on differentiation):
${competitorKeywords.join(", ")}` : ''}` : ''}

**Semantic Keyword Clusters** (use naturally throughout):
${primaryTopics.length > 0 ? `- Primary Topics: ${primaryTopics.join(", ")}` : ''}
${secondaryTopics.length > 0 ? `- Secondary Concepts: ${secondaryTopics.join(", ")}` : ''}
${relatedTopics.length > 0 ? `- Related Terms: ${relatedTopics.join(", ")}` : ''}

**Topical Authority Markers** (emphasize these):
${expertiseAreas.length > 0 ? `- Expertise Areas: ${expertiseAreas.join(", ")}` : ''}
${trustSignals.length > 0 ? `- Trust Signals: ${trustSignals.join(", ")}` : ''}

**MANDATORY USAGE REQUIREMENTS:**
- MUST mention at least 1 ZIP code or neighborhood in first 3 paragraphs (if provided in batch cache)
- MUST cite at least 2 authority entities for credibility (if provided in batch cache)
- MUST include at least 2 key statistics with sources and years (if provided in batch cache)
- MUST reference at least 1 local regulation (if provided in batch cache)
- If batch cache fields are empty, focus on ${geographicFocus} context using general knowledge
`;
      } else {
        console.log(`⏩ [CACHE MISS] No batch SEO cache found for batch ${batchId} - generating without cache`);
      }
    } catch (error) {
      console.warn(`⚠️ Failed to fetch batch SEO cache for batch ${batchId}:`, error);
      // Continue without cache - non-fatal error
    }
  }
  
  const geographicContext = geographicFocus ? `\nGeographic Focus: ${geographicFocus}` : "";
  const audienceContext = audience ? `\nTarget Audience: ${audience}` : "";
  const toneContext = tone ? `\nTone: ${tone} - Write the entire article in this tone` : "";
  const customContext = customInstructions ? `\n\n**CUSTOM REGENERATION INSTRUCTIONS:**\n${customInstructions}\n\nPlease apply these specific changes while maintaining all other quality standards and requirements below.` : "";
  const brandLockContext = createBrandLockPromptSegment(businessName);
  const shadowRunContext = shadowRunPlan
    ? `\n\n${buildShadowRunPromptPreamble(shadowRunPlan)}`
    : "";

  const prompt = `You are an expert content strategist implementing a composite 3-layer methodology combining Lily Ray's Answer-First structure, Mike King's passage-level optimization, and Kevin Indig's citation optimization for maximum AI visibility and E-E-A-T signals.

Article Title: ${title}
Target URL for Internal Linking: ${targetUrl}
Word Count Range: ${wordCountMin}-${wordCountMax} words${geographicContext}${audienceContext}${toneContext}${customContext}
${brandLockContext}${batchSeoContext}${shadowRunContext}

**CRITICAL CONTENT FOCUS:**
The article MUST be ABOUT THE TOPIC/SUBJECT MATTER, NOT about ${businessName}.
- WRONG: "10 Ways ${businessName} Helps You..." (article ABOUT the company)
- CORRECT: "10 Ways to Build Better Software (tools like ${businessName} can help)" (article ABOUT the topic)
- ${businessName} should only appear as an EXAMPLE or REFERENCE when discussing the topic
- Focus on educating readers about the INDUSTRY/SUBJECT, using ${businessName} to illustrate points

**COMPOSITE 3-LAYER METHODOLOGY (ALL LAYERS MANDATORY):**

═══════════════════════════════════════════════════════════════════
LAYER 1: LILY RAY'S ANSWER-FIRST STRUCTURE (AEO Optimization)
═══════════════════════════════════════════════════════════════════

1. **ANSWER-FIRST OPENING PARAGRAPH (150-200 words) - CRITICAL:**
   
   ⚠️ **EXCEPTION TO 3-5 SENTENCE RULE**: This opening paragraph is exempt from the strict sentence limit and should be 8-12 sentences to reach 150-200 words.
   
   - Provide a COMPLETE, DIRECT answer to the main query in the title
   - Front-load the most important facts and evidence
   - Make this paragraph quotable and citable by AI systems
   - Include target keyword naturally 2-3 times
   - Use clear, authoritative language
   - Think: "If AI only reads this paragraph, does it get the full answer?"
   
   **Formula:** [Direct Answer] + [Key Facts] + [Evidence/Statistics] + [Local Context for ${geographicFocus}] + [Practical Implication]
   
   **Example Structure (8-12 sentences, 150-200 words):**
   "${title} involves [direct answer in 2-3 sentences]. ${geographicFocus} residents/businesses face [specific local challenge]. According to [authority entity with credibility score], [key statistic with source and year]. The primary considerations include [3-4 key factors]. For ${geographicFocus} specifically, [local regulation or neighborhood-specific context]. [Additional supporting evidence]. [Final implication or practical takeaway]."

2. **E-E-A-T SIGNALS THROUGHOUT CONTENT:**
   
   **Experience (First-Hand Evidence):**
   - Include phrases like: "In our [X] years working with ${geographicFocus} clients..."
   - Add case studies: "When we helped [${geographicFocus} neighborhood] residents with..."
   - Show real-world application with local examples
   
   **Expertise (Technical Depth):**
   - Demonstrate deep knowledge with technical details
   - Explain complex concepts clearly for ${geographicFocus} context
   - Use industry-specific terminology with explanations
   - Reference ${geographicFocus}-specific standards or practices
   
   **Authoritativeness (Credible Citations):**
   - MANDATORY: Cite at least 2 authority entities from batch SEO cache
   - Include statistics with sources and years from batch cache
   - Reference local regulations provided in batch context
   - Cite government data, industry reports, local authorities
   
   **Trustworthiness (Accuracy & Transparency):**
   - Be accurate and fact-check all claims against batch SEO cache
   - Be transparent about limitations or uncertainties
   - Provide balanced perspectives
   - Use recent data (2024-2025) and cite years

3. **LOCAL/GEO OPTIMIZATION (MANDATORY IN FIRST 3 PARAGRAPHS):**
   - MUST include ${geographicFocus}-specific data in first 3 paragraphs
   - MUST mention at least 1 ZIP code OR neighborhood (if provided in batch cache above)
   - Reference local demographics, regulations, or trends (use batch cache if available)
   - Cite local authority entities where relevant (if provided in batch cache above)
   - Add ${geographicFocus}-specific examples using available data or general knowledge

4. **FRESHNESS SIGNALS:**
   - Include current year (2025) in opening paragraph
   - Reference latest developments (2024-2025)
   - Use phrases: "As of 2025...", "Latest data shows...", "Recent trends in ${geographicFocus}..."

═══════════════════════════════════════════════════════════════════
LAYER 2: MIKE KING'S PASSAGE-LEVEL OPTIMIZATION (AI Extraction)
═══════════════════════════════════════════════════════════════════

**CRITICAL: STRICT PARAGRAPH LENGTH LIMITS**

⚠️ **IMPORTANT**: Opening paragraph is EXEMPT from this rule (see Layer 1). ALL OTHER paragraphs must follow:

Every paragraph (EXCEPT opening) MUST be:
- **3-5 sentences maximum** (STRICT)
- Self-contained (can stand alone as a complete answer)
- Contains ONE clear idea only
- Includes context (don't assume reader read previous paragraphs)
- Optimized for AI extraction

**PARAGRAPH FORMULA (Use This Pattern):**
"[Topic/Question] is [Definition/Answer]. [Supporting detail 1 with evidence]. [Supporting detail 2 with local context]. [Practical implication]. [Specific relevance to ${geographicFocus}]."

**Example (5 sentences max):**
"${title} requires understanding local regulations in ${geographicFocus}. [Local regulation from batch cache] mandates specific requirements for businesses. According to [authority entity from batch cache], [statistic with source]. This affects [ZIP code area from batch cache] residents differently than other neighborhoods. Compliance ensures [practical benefit]."

**COMPRESSION RULES (Mike King):**
- Remove ALL unnecessary words
- Get to the point IMMEDIATELY
- Front-load key information in EVERY paragraph
- Use active voice exclusively
- Eliminate redundancy completely
- No fluff, no filler, no transitional waffle

**BAD (Too Long, Vague):**
"When it comes to understanding the various aspects of this topic, there are many different factors that one should consider, especially when looking at the local context and all of the various regulations that might apply to different situations..."

**GOOD (Compressed, Specific):**
"${title} in ${geographicFocus} requires three key considerations. First, [local regulation from batch cache] sets mandatory standards. Second, [ZIP code] residents face unique challenges. Third, compliance costs average [statistic from batch cache]."

═══════════════════════════════════════════════════════════════════
LAYER 3: KEVIN INDIG'S CITATION OPTIMIZATION (Schema-Ready)
═══════════════════════════════════════════════════════════════════

1. **SCHEMA-READY STRUCTURE:**
   - Use question-based H2 headings: "What is...", "How does...", "Why...", "When to..."
   - Each H2 section = 2-3 H3 subsections maximum
   - Include numbered lists for step-by-step processes (HowTo schema)
   - Create 5-8 natural Q&As in FAQ section (FAQPage schema)
   - Use semantic HTML structure

2. **🚨 CRITICAL AEO CONSTRAINT: 40-60 WORD DIRECT ANSWERS 🚨**
   
   **MANDATORY FOR EVERY H2 AND H3 HEADING:**
   
   The FIRST paragraph immediately following each H2 or H3 heading MUST be:
   - **Exactly 40-60 words** (count carefully!)
   - A complete, direct, non-promotional answer to the heading question
   - Optimized for AI Overview citation and featured snippets
   - Front-loaded with the most critical information
   - Self-contained (understandable without context)
   
   **Formula for H2/H3 Direct Answers (40-60 words):**
   "[Direct answer in 1-2 sentences]. [Key supporting fact with evidence]. [Local context for ${geographicFocus}]. [Practical implication or next step]."
   
   **Example for H2: "What Are the Requirements for [Topic] in ${geographicFocus}?"**
   "[Topic] in ${geographicFocus} requires three primary elements: [requirement 1], [requirement 2], and [requirement 3]. According to [authority entity], [key statistic]. ${geographicFocus} residents in [ZIP code/neighborhood] must also comply with [local regulation]. This ensures [practical benefit]." (58 words)
   
   **Example for H3: "How Much Does [Topic] Cost?"**
   "[Topic] costs between $[low] and $[high] in ${geographicFocus}, depending on [factor 1] and [factor 2]. [Authority entity] reports that ${geographicFocus} prices average [statistic]. [Neighborhood]-specific pricing varies by [factor]. Budget accordingly for [practical consideration]." (45 words)
   
   ⚠️ **AFTER** the 40-60 word direct answer paragraph, you may continue with additional detail in standard 3-5 sentence paragraphs.

3. **AUTHOR ENTITY INTEGRATION (E-E-A-T Authority Signal):**
   
   **MANDATORY AUTHOR REFERENCES:**
   - In the introduction or first H2 section, reference the primary author/expert
   - Use phrases like: "Based on [X] years of experience with ${geographicFocus} clients..."
   - Include: "Our team of ${geographicFocus}-based experts has worked with..."
   - Add credibility markers: "As certified professionals serving ${geographicFocus}..."
   - Reference specific experience: "Having assisted over [number] ${geographicFocus} residents with..."
   
   **Example Integration:**
   "Our team has assisted over 500 ${geographicFocus} residents navigate [topic] since 2018. This firsthand experience across ${geographicFocus} neighborhoods like [neighborhood 1] and [neighborhood 2] provides deep insight into local challenges and solutions."

4. **FRONT-LOAD EVIDENCE (First 2-3 Paragraphs):**
   - Paragraph 1 (Answer-first): Include primary statistic
   - Paragraph 2: Cite authority entity with credibility note
   - Paragraph 3: Reference local regulation or neighborhood data
   - Use format: "[Claim] + [Evidence with source] + [Implication]"
   
   **Example:**
   "[Statistic claim]: [value]. [Authority entity] (credibility: [score]/100) reports [evidence]. For ${geographicFocus} residents, this means [implication]."

5. **COMPRESS PARAGRAPHS FOR EXTRACTABILITY:**
   - Each paragraph = [Claim] + [Evidence] + [Implication]
   - 3-4 sentences per paragraph (Mike King limit applies here too)
   - Make each paragraph quotable on its own

6. **CONTENT STRUCTURE (Kevin Indig's No-Regret Moves):**
   - Introduction: Answer-first paragraph (150-200 words)
   - 6-8 H2 sections with question-based headings
   - Each H2: 2-3 H3 subsections
   - Include 1 comparison table (format as text list)
   - Include 1 step-by-step numbered process
   - FAQ section: 5-8 natural language questions
   - Conclusion: Key takeaways summary (3-5 sentences)

**SCHEMA MARKUP REQUIREMENTS:**
- FAQPage: Natural Q&As (not keyword-stuffed)
- HowTo: Step-by-step processes with clear actions
- Article: Clear structure, author indicators, dates
- LocalBusiness: For ${geographicFocus}-specific content

═══════════════════════════════════════════════════════════════════
QUALITY CHECKLIST (Self-Audit Before Returning Article)
═══════════════════════════════════════════════════════════════════

**LAYER 1 (Lily Ray - Answer-First):**
✓ Opening paragraph is 150-200 words
✓ Provides complete, direct answer to title question
✓ Front-loads facts and evidence
✓ Includes 2-3 mentions of target keyword naturally
✓ Cites at least 1 statistic with source in opening
✓ Mentions ${geographicFocus} in first paragraph

**LAYER 2 (Mike King - Passage-Level):**
✓ Opening paragraph is 8-12 sentences (150-200 words)
✓ ALL OTHER paragraphs are 3-5 sentences
✓ Each paragraph stands alone (self-contained)
✓ No filler or transitional waffle
✓ Active voice used throughout
✓ Key info front-loaded in every paragraph

**LAYER 3 (Kevin Indig - Citation Optimization):**
✓ Question-based H2 headings used
✓ 🚨 CRITICAL: Every H2/H3 has 40-60 word direct answer as first paragraph
✓ Author entity referenced in introduction or first H2 section
✓ First 2-3 paragraphs include evidence with sources
✓ At least 2 authority entities cited
✓ At least 2 statistics with sources and years
✓ FAQ section has 5-8 natural Q&As
✓ At least 1 numbered step-by-step process

**LOCAL SEO (Mandatory):**
✓ ${geographicFocus} mentioned in first 3 paragraphs
✓ At least 1 ZIP code OR neighborhood mentioned in first 3 paragraphs (use batch cache if available)
✓ At least 1 local regulation cited (ONLY IF provided in batch cache above)
✓ At least 2 local authority entities cited (ONLY IF provided in batch cache above)
✓ If batch cache is empty, use ${geographicFocus} general context and knowledge

**TECHNICAL REQUIREMENTS:**
✓ Word count within ${wordCountMin}-${wordCountMax} range
✓ ${businessName} appears as example/reference only (NOT main subject)
✓ Current year (2025) referenced
✓ All claims supported by evidence

SEO Requirements:
1. Generate an SEO-optimized title tag (50-60 characters)
2. Write a compelling meta description (150-160 characters)
3. Create a URL-friendly slug (lowercase, hyphens, no special characters)
4. Identify exactly 6 article-specific long-phrase keywords (3-6 words each) that:
   - Are unique to THIS specific article title and geographic focus
   - Appear naturally in the article content
   - Target search queries relevant to "${title}"${geographicContext ? ` in ${geographicFocus}` : ''}
   - Will be used for internal linking to ${targetUrl}
5. Generate 10-15 relevant hashtags for social media

FAQ Requirements:
Generate 5-8 frequently asked questions with detailed answers:
1. Questions should be in natural language (how people actually ask)
2. Answers should be 2-4 sentences, comprehensive but concise
3. Cover common buyer concerns, technical questions, and decision criteria
4. Support FAQ schema markup

Image Requirements:
Generate exactly 3 HYPER-REALISTIC, VIBRANT image generation prompts that align PERFECTLY with the article content and company brand.

**CRITICAL IMAGE REQUIREMENTS:**
- Workers MUST be wearing ${businessName}-branded uniforms with logos (${businessName} logo, branded shirts/jackets, professional attire with brand colors)${companyLogoUrl ? `\n- **LOGO REFERENCE**: The ${businessName} logo is available at ${companyLogoUrl}. Study this logo carefully and ensure all generated images feature workers wearing uniforms/apparel with THIS EXACT logo design, colors, and branding elements.` : ''}
- Images MUST be VIBRANT and colorful - matching the tone and energy of the article
- AVOID professional stock photo aesthetics - go for authentic, documentary-style realism
- HYPERREALISTIC location settings - capture the actual environment and geographic location${geographicContext ? ` (${geographicFocus})` : ''}

**EXACT BRAND NAME TEXT REQUIREMENTS:**
- The brand name is EXACTLY: "${businessName}"
- Include the exact text "${businessName}" in the image, do NOT abbreviate or change
- When text appears in images (signs, banners, uniforms, vehicles), it must be EXACTLY: "${businessName}"
- Brand name text must be legible, clear, and spelled EXACTLY as written above
- Use professional sans-serif font, bold and readable for "${businessName}" text
- Text placement: Centered on signs/banners OR visible on uniform patches/logos OR on ${businessName} vehicles
- Do NOT invent, modify, replace, or abbreviate "${businessName}"

**NEGATIVE PROMPTS FOR TEXT ACCURACY:**
- Do NOT abbreviate "${businessName}"
- Do NOT change or modify "${businessName}" in any way
- No fictional names, only the exact text provided: "${businessName}"
- Do NOT use placeholder text or variations of "${businessName}"

Each prompt MUST include ALL of these elements:

1. **Subject & Scene** (WHAT): Real workers in ${businessName}-branded uniforms doing actual work
   - Be extremely specific: ages, expressions, branded clothing (${businessName} logo shirts/jackets), authentic activities
   - **MANDATORY**: All workers must be wearing ${businessName}-branded uniforms with visible logos or brand colors
   - Example: "A 45-year-old technician wearing a branded navy blue ${businessName} uniform with logo patch, installing equipment"
   
2. **Location Context** (WHERE): HYPERREALISTIC setting in the specific geographic location${geographicContext ? ` (${geographicFocus})` : ''}
   - Include EXACT architectural styles, recognizable local landmarks, regional characteristics
   - Capture authentic local environment - weather patterns, vegetation, building materials
   - Example: "On-site at a residential property in ${geographicFocus || 'the local area'}, showing authentic local architecture and landscape"
   
3. **Vibrant Color & Atmosphere** (FEEL): VIBRANT, energetic visuals matching article tone
   - Use saturated, vivid colors - avoid muted or washed-out tones
   - Match the ${businessName} brand energy${toneContext ? ` and ${tone} tone` : ''}
   - Example: "Vibrant and energetic atmosphere, bright brand colors (blues, oranges, greens), lively and engaging"
   
4. **Lighting** (HOW IT LOOKS): Natural, authentic lighting that enhances vibrancy
   - Specify: bright natural daylight, golden hour warmth, well-lit work environments
   - Enhance color saturation and vibrancy through lighting
   - Example: "Bright natural daylight, clear skies, enhanced color saturation, vibrant warm tones"
   
5. **Composition** (FRAMING): Documentary-style authentic framing
   - Avoid posed, stock-photo compositions
   - Capture real work in action, genuine moments
   - Example: "Action shot, workers actively engaged in task, candid documentary style, dynamic angles"
   
6. **Style & Quality** (VISUAL TONE): Authentic, non-stock photography
   - AVOID: Staged stock photos, artificial perfection, generic business imagery
   - AIM FOR: Documentary realism, vibrant photojournalism, authentic work environments
   - Example: "Documentary-style photojournalism, hyperrealistic, vibrant color grading, authentic work scene"
   
7. **Branding Details** (AUTHENTICITY): Visible ${businessName} branding and realistic work context
   - ${businessName} uniforms with logos, branded vehicles/equipment, brand colors prominently displayed
   - Real work tools, equipment, and authentic job site details
   - Example: "${businessName}-branded work truck in background, branded tool bags, workers wearing ${businessName} uniform shirts with visible logo patches, authentic work equipment"

CONSISTENCY REQUIREMENTS:
- All 3 prompts must feature ${businessName}-branded uniforms and authentic work scenes
- VIBRANT color palette throughout - saturated, energetic, eye-catching
- Consistent ${businessName} branding across all images (same logo, uniform colors)
- Hyperrealistic ${geographicFocus || 'local'} location settings in every image
- Progress from wider establishing shots to detailed action close-ups
- Each prompt should illustrate a different aspect of ${businessName}'s work

ABSOLUTELY AVOID: 
- Generic stock photos with models
- Staged, overly-polished scenes
- Workers without ${businessName}-branded uniforms
- Muted, professional corporate aesthetics
- Unrealistic perfection or artificial setups

MANDATE:
- Documentary-style authenticity with real workers in ${businessName}-branded uniforms
- Vibrant, saturated colors matching ${businessName} brand energy
- Hyperrealistic location-specific settings
- Genuine work moments, not posed scenes

**CRITICAL FORMATTING REQUIREMENT:**
Return the article text in MARKDOWN format with proper structure:
- Use ## for H2 headers (main sections)
- Use ### for H3 headers (subsections)
- Use blank lines to separate paragraphs
- Use - or * for bullet lists
- Use 1. 2. 3. for numbered lists
- Use **bold** for emphasis
- Use proper spacing between sections

This markdown structure is ESSENTIAL for proper HTML conversion in the next stage.

Return ONLY valid JSON in this exact format (no markdown, no code blocks):
{
  "articleText": "full article text here...",
  "seoTitle": "SEO title 50-60 chars",
  "metaDescription": "meta description 150-160 chars",
  "slug": "url-friendly-slug",
  "keywords": ["article-specific keyword 1", "article-specific keyword 2", "article-specific keyword 3", "article-specific keyword 4", "article-specific keyword 5", "article-specific keyword 6"],
  "hashtags": ["#tag1", "#tag2", ... 10-15 hashtags],
  "faq": [
    {"question": "Question 1?", "answer": "Detailed answer..."},
    {"question": "Question 2?", "answer": "Detailed answer..."},
    ... 5-8 FAQ items
  ],
  "imagePrompts": ["prompt1", "prompt2", "prompt3"],
  "wordCount": 1500
}`;

  // Use Gemini 2.0 Flash for 4-6× faster generation (adequate for first draft)
  const model = process.env.GEMINI_ARTICLE_MODEL || "gemini-2.0-flash";
  
  const result = await throttledGeminiRequest(() => genAI.models.generateContent({
    model,
    contents: [
      {
        role: "user",
        parts: [{ text: prompt }],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: "object",
        properties: {
          articleText: {
            type: "string",
            description: "Full article content in plain text format"
          },
          seoTitle: {
            type: "string",
            description: "SEO-optimized title tag (50-60 characters)"
          },
          metaDescription: {
            type: "string",
            description: "Compelling meta description (150-160 characters)"
          },
          slug: {
            type: "string",
            description: "URL-friendly slug"
          },
          keywords: {
            type: "array",
            items: { type: "string" },
            description: "6 article-specific long-phrase keywords tailored to this title and geographic focus"
          },
          hashtags: {
            type: "array",
            items: { type: "string" },
            description: "10-15 relevant hashtags"
          },
          faq: {
            type: "array",
            items: {
              type: "object",
              properties: {
                question: { type: "string" },
                answer: { type: "string" }
              },
              required: ["question", "answer"]
            },
            description: "5-8 FAQ items with questions and answers"
          },
          imagePrompts: {
            type: "array",
            items: { type: "string" },
            description: "3 photorealistic image generation prompts"
          },
          wordCount: {
            type: "number",
            description: "Actual word count of the article"
          }
        },
        required: [
          "articleText",
          "seoTitle",
          "metaDescription",
          "slug",
          "keywords",
          "hashtags",
          "faq",
          "imagePrompts",
          "wordCount"
        ]
      }
    }
  }));

  let responseText = result.text || "";
  if (!responseText) {
    throw new Error("No response text from Gemini");
  }
  
  // Strip markdown code fences if present
  responseText = responseText.replace(/^```json\s*/i, '').replace(/```\s*$/i, '').trim();
  
  const parsed = JSON.parse(responseText) as ArticleGenerationResult;
  
  if (!parsed.articleText || parsed.articleText.length < 100) {
    throw new Error("Article text is too short or missing");
  }

  if (parsed.keywords.length !== 6) {
    throw new Error(`Expected 6 article-specific keywords, received ${parsed.keywords.length}`);
  }

  if (parsed.imagePrompts.length !== 3) {
    throw new Error(`Expected 3 image prompts, received ${parsed.imagePrompts.length}`);
  }

  if (parsed.hashtags.length < 10 || parsed.hashtags.length > 15) {
    throw new Error(`Expected 10-15 hashtags, received ${parsed.hashtags.length}`);
  }

  if (!parsed.faq || parsed.faq.length < 5 || parsed.faq.length > 8) {
    throw new Error(`Expected 5-8 FAQ items, received ${parsed.faq?.length || 0}`);
  }

  return parsed;
}

// ============================================================================
// ADVANCED ARTICLE GENERATION WITH GEO-SCORING & SERP TARGETING
// ============================================================================

export interface AdvancedArticleResult {
  rawContent: string;
  seoTitle: string;
  metaDescription: string;
  slug: string;
  keywords: string[];
  hashtags: string[];
  faq: Array<{ question: string; answer: string }>;
  imagePrompts: string[];
  wordCount: number;
  geoAccuracyScore?: number;
  tokensUsed?: number;
}

export async function generateArticleWithGemini(
  title: string,
  targetUrl: string,
  wordCountMin: number = 800,
  wordCountMax: number = 2000,
  tone?: string,
  geographicFocus?: string,
  audience?: string,
  competitorUrls?: string[],
  serpFeatureTarget?: string,
  businessName?: string,
  customInstructions?: string,
  companyLogoUrl?: string,
  batchId?: number, // NEW: Batch ID for SEO cache lookup
  shadowRunPlan?: ArticleShadowRunPlan,
): Promise<AdvancedArticleResult> {
  const result = await generateArticleContent(
    title,
    targetUrl,
    wordCountMin,
    wordCountMax,
    tone,
    geographicFocus,
    audience,
    businessName,
    customInstructions,
    companyLogoUrl,
    batchId, // Pass batchId to enable cache lookup
    shadowRunPlan,
  );

  let geoAccuracyScore: number | undefined;
  if (geographicFocus) {
    const locationMentions = (result.articleText.match(new RegExp(geographicFocus, 'gi')) || []).length;
    geoAccuracyScore = Math.min(100, locationMentions * 10 + 50);
  }

  return {
    rawContent: result.articleText,
    seoTitle: result.seoTitle,
    metaDescription: result.metaDescription,
    slug: result.slug,
    keywords: result.keywords,
    hashtags: result.hashtags,
    faq: result.faq,
    imagePrompts: result.imagePrompts,
    wordCount: result.wordCount,
    geoAccuracyScore,
    tokensUsed: result.wordCount,
  };
}
