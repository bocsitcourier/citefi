import { eq } from "drizzle-orm";
import { statelessDb } from "./db";
import {
  socialPostAssets,
  socialPostLogs,
  socialPosts,
  type SocialPost,
} from "@/shared/schema";
import {
  generateVideoScript,
  type VideoScript,
} from "./gemini-video-script-generator";
import { generateVideoImages } from "./social-video-image-generator";
import { generateVideoTTS } from "./social-video-tts-generator";
import {
  cleanupTempFiles,
  runFFmpegCompositor,
  type VideoCompositorResult,
  SOCIAL_VIDEO_HARD_CAP_SECONDS,
} from "./social-video-compositor";
import {
  createSocialVideoRuntimeContext,
  normalizeSocialVideoProvider,
  type SocialVideoProvider,
  type SocialVideoRuntimeContext,
} from "./social-video-runtime";
import { generateVeoSocialVideo } from "./veo-social-video-generator";
import { enforceVideoScriptLength } from "./utils/video-guards";

const VIDEO_SCRIPT_WORD_CAP = 215;
const VIDEO_SCRIPT_WORDS_PER_SECOND = 3;
const VIDEO_PIPELINE_JITTER_MAX_MS = Number.parseInt(
  process.env.SOCIAL_VIDEO_JITTER_MAX_MS || "8000",
  10,
);

type SocialPostUpdate = Partial<typeof socialPosts.$inferInsert>;

export interface GenerateSocialVideoRequest {
  socialPostId: number;
  platform?: string;
  provider?: string;
  jobId?: string;
}

export interface GenerateSocialVideoResult {
  videoUrl: string;
  duration: number;
  resolution: string;
  fileSize: number;
  scriptSummary: {
    title: string;
    scenes: number;
    hashtags: string[];
  };
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function updateVideoPost(
  socialPostId: number,
  updates: SocialPostUpdate,
): Promise<void> {
  await statelessDb
    .update(socialPosts)
    .set({
      ...updates,
      updatedAt: new Date(),
    })
    .where(eq(socialPosts.id, socialPostId));
}

async function loadSocialPost(socialPostId: number): Promise<SocialPost> {
  const [post] = await statelessDb
    .select()
    .from(socialPosts)
    .where(eq(socialPosts.id, socialPostId))
    .limit(1);

  if (!post) {
    throw new Error(`Social post ${socialPostId} not found`);
  }

  return post;
}

async function loadArticleContent(
  articleId?: number | null,
): Promise<string | undefined> {
  if (!articleId) {
    return undefined;
  }

  const { articles } = await import("@/shared/schema");
  const [article] = await statelessDb
    .select()
    .from(articles)
    .where(eq(articles.id, articleId))
    .limit(1);

  if (!article?.finalHtmlContent) {
    return undefined;
  }

  return article.finalHtmlContent.replace(/<[^>]*>/g, " ").slice(0, 2000);
}

async function downloadCompanyLogo(
  companyLogoUrl: string | null,
  workDir: string,
): Promise<string | undefined> {
  if (!companyLogoUrl || !companyLogoUrl.startsWith("/api/public-objects/")) {
    return undefined;
  }

  try {
    const fs = await import("fs/promises");
    const path = await import("path");
    await fs.mkdir(workDir, { recursive: true });

    const logoFileName = companyLogoUrl.split("/").pop() || "logo";
    const logoPath = path.join(workDir, `logo-${logoFileName}`);
    const { objectStorageClient } = await import("./storage");
    const bucket = objectStorageClient.bucket(
      process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || "",
    );
    const objectPath = companyLogoUrl.replace("/api/public-objects/", "public/");
    const [buffer] = await bucket.file(objectPath).download();

    await fs.writeFile(logoPath, buffer);
    return logoPath;
  } catch (error) {
    console.warn("⚠️ Could not load company logo:", error);
    return undefined;
  }
}

function buildScriptRequest(post: SocialPost, articleContent?: string) {
  return {
    topic: post.topic,
    title: post.title,
    location: post.location,
    tone: post.tone || "Professional",
    mood: post.mood || "Informative",
    industry: post.industry || "Business",
    companyName: post.companyName!,
    articleContent,
    landingPageUrl: post.landingPageUrl || undefined,
  };
}

async function generateSafeVideoScript(input: {
  socialPostId: number;
  post: SocialPost;
  articleContent?: string;
}): Promise<VideoScript> {
  const { socialPostId, post, articleContent } = input;

  console.log(`\n📝 Step 2/5: Generating guarded video script...`);
  const rawScript = await generateVideoScript(
    buildScriptRequest(post, articleContent),
  );
  const safeScript = enforceVideoScriptLength(rawScript, {
    maxWords: VIDEO_SCRIPT_WORD_CAP,
    wordsPerSecond: VIDEO_SCRIPT_WORDS_PER_SECOND,
    maxDuration: SOCIAL_VIDEO_HARD_CAP_SECONDS,
  });

  await updateVideoPost(socialPostId, {
    videoScriptJson: safeScript as any,
    videoProgress: 20,
    videoStage: "script_complete",
  });

  return safeScript;
}

async function persistImageAssets(input: {
  socialPostId: number;
  platform: string;
  script: VideoScript;
  images: Awaited<ReturnType<typeof generateVideoImages>>;
}): Promise<void> {
  const { socialPostId, platform, script, images } = input;

  if (!images.length) {
    return;
  }

  await statelessDb.insert(socialPostAssets).values(
    images.map((image) => {
      const scene = script.scenes.find(
        (item) => item.sceneNumber === image.sceneNumber,
      );

      return {
        socialPostId,
        platform,
        assetType: "image" as const,
        promptUsed: scene?.visualDescription || "Video scene image",
        storageUrl: image.storageUrl,
        altText: `Scene ${image.sceneNumber}: ${scene?.caption || ""}`,
        aspectRatio: image.aspectRatio,
        fileFormat: "jpg",
      };
    }),
  );
}

async function finalizeVideo(
  socialPostId: number,
  platform: string,
  promptSummary: string,
  altText: string,
  video: VideoCompositorResult,
): Promise<void> {
  await updateVideoPost(socialPostId, {
    videoUrl: video.videoUrl,
    videoStatus: "READY",
    videoProgress: 100,
    videoStage: "complete",
    videoDuration: video.duration,
    videoGeneratedAt: new Date(),
    errorMessage: null,
  });

  await statelessDb.insert(socialPostAssets).values({
    socialPostId,
    platform,
    assetType: "video",
    promptUsed: promptSummary,
    storageUrl: video.videoUrl,
    altText,
    aspectRatio: video.resolution,
    fileFormat: "mp4",
    videoDuration: video.duration,
    videoResolution: video.resolution,
  });
}

async function runSlideshowPipeline(input: {
  socialPostId: number;
  platform: string;
  post: SocialPost;
  script: VideoScript;
  runtime: SocialVideoRuntimeContext;
}): Promise<VideoCompositorResult> {
  const { socialPostId, platform, post, script, runtime } = input;

  await updateVideoPost(socialPostId, {
    videoProgress: 25,
    videoStage: "parallel_generation",
  });

  const [images, audio] = await Promise.all([
    generateVideoImages({
      socialPostId,
      scenes: script.scenes,
      industry: post.industry || "Business",
      companyName: post.companyName!,
      platform,
      runtime,
    }),
    generateVideoTTS({
      socialPostId,
      scenes: script.scenes,
      tone: post.tone || "Professional",
      companyName: post.companyName!,
      runtime,
    }),
  ]);

  await updateVideoPost(socialPostId, {
    videoProgress: 65,
    videoStage: "assets_complete",
  });

  await persistImageAssets({
    socialPostId,
    platform,
    script,
    images,
  });

  const companyLogoPath = await downloadCompanyLogo(
    post.companyLogoUrl,
    runtime.workDir,
  );

  const video = await runFFmpegCompositor(
    {
      socialPostId,
      images,
      audio,
      scenes: script.scenes,
      companyLogoPath,
      companyName: post.companyName!,
      platform,
      runtime,
    },
    SOCIAL_VIDEO_HARD_CAP_SECONDS,
  );

  await updateVideoPost(socialPostId, {
    videoProgress: 90,
    videoStage: "composition_complete",
  });

  return video;
}

async function runPreferredVideoPipeline(input: {
  socialPostId: number;
  platform: string;
  provider: SocialVideoProvider;
  post: SocialPost;
  script: VideoScript;
  runtime: SocialVideoRuntimeContext;
}): Promise<{ video: VideoCompositorResult; usedFallback: boolean }> {
  const { socialPostId, platform, provider, post, script, runtime } = input;

  if (provider !== "veo") {
    const video = await runSlideshowPipeline({
      socialPostId,
      platform,
      post,
      script,
      runtime,
    });

    return { video, usedFallback: false };
  }

  try {
    console.log(`🤖 Attempting Veo 2.0 generation for ${socialPostId}...`);

    const video = await generateVeoSocialVideo({
      socialPostId,
      platform,
      companyName: post.companyName!,
      topic: post.topic,
      title: post.title,
      location: post.location,
      tone: post.tone || "Professional",
      mood: post.mood || "Informative",
      industry: post.industry || "Business",
      script,
      runtime,
    });

    await updateVideoPost(socialPostId, {
      videoProgress: 95,
      videoStage: "composition_complete",
    });

    return { video, usedFallback: false };
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : String(error);
    console.warn(
      `⚠️ Veo generation failed for ${socialPostId}. Falling back to slideshow compositor: ${errorMessage}`,
    );

    await updateVideoPost(socialPostId, {
      videoProgress: 25,
      videoStage: "parallel_generation",
    });

    try {
      await statelessDb.insert(socialPostLogs).values({
        socialPostId,
        eventType: "FALLBACK",
        stage: "VEO",
        severity: "warning",
        message: `Veo generation failed. Falling back to slideshow compositor: ${errorMessage}`,
        payloadJson: {
          provider: "veo",
          fallback: "slideshow",
        },
      });
    } catch (logError) {
      console.warn("⚠️ Failed to persist Veo fallback log:", logError);
    }

    const video = await runSlideshowPipeline({
      socialPostId,
      platform,
      post,
      script,
      runtime,
    });

    return { video, usedFallback: true };
  }
}

export async function processSocialVideoJob(
  request: GenerateSocialVideoRequest,
): Promise<GenerateSocialVideoResult> {
  const socialPostId = request.socialPostId;
  const platform = request.platform || "tiktok";
  const provider = normalizeSocialVideoProvider(request.provider);
  const runtime = createSocialVideoRuntimeContext({
    socialPostId,
    jobId: request.jobId,
    provider,
  });

  console.log(
    `\n🎬 Starting enterprise video pipeline for Social Post ${socialPostId} (${provider})`,
  );

  try {
    const post = await loadSocialPost(socialPostId);

    if (!post.companyName) {
      await updateVideoPost(socialPostId, {
        videoStatus: "FAILED",
        videoStage: null,
        errorMessage:
          "Company name is required for video generation. Please edit this post to add your company name.",
      });

      throw new Error(
        "Company name is required for video generation. Please edit this post to add your company name.",
      );
    }

    await updateVideoPost(socialPostId, {
      videoStatus: "GENERATING",
      videoProgress: 0,
      videoStage: "initializing",
      errorMessage: null,
    });

    const jitterWindow = Math.max(0, VIDEO_PIPELINE_JITTER_MAX_MS);
    if (jitterWindow > 0) {
      const jitterMs = Math.floor(Math.random() * jitterWindow);
      if (jitterMs > 0) {
        console.log(`⏳ Applying ${jitterMs}ms video worker jitter`);
        await sleep(jitterMs);
      }
    }

    const articleContent = await loadArticleContent(post.articleId);
    const script = await generateSafeVideoScript({
      socialPostId,
      post,
      articleContent,
    });
    const { video, usedFallback } = await runPreferredVideoPipeline({
      socialPostId,
      platform,
      provider,
      post,
      script,
      runtime,
    });

    await finalizeVideo(
      socialPostId,
      platform,
      usedFallback
        ? `Veo fallback video: ${script.title}`
        : provider === "veo"
          ? `Veo social video: ${script.title}`
          : `Social video: ${script.title}`,
      script.title,
      video,
    );

    await cleanupTempFiles(runtime);

    return {
      videoUrl: video.videoUrl,
      duration: video.duration,
      resolution: video.resolution,
      fileSize: video.fileSize,
      scriptSummary: {
        title: script.title,
        scenes: script.scenes.length,
        hashtags: script.hashtags,
      },
    };
  } catch (error) {
    console.error(
      `\n❌ Video pipeline failed for Social Post ${socialPostId}:`,
      error,
    );

    await updateVideoPost(socialPostId, {
      videoStatus: "FAILED",
      videoStage: null,
      errorMessage: error instanceof Error ? error.message : String(error),
    });

    await cleanupTempFiles(runtime);
    throw error;
  }
}
