import type {
  VideoScene,
  VideoScript,
} from "../gemini-video-script-generator";

export interface EnforceVideoScriptLengthOptions {
  maxWords?: number;
  wordsPerSecond?: number;
  maxDuration?: number;
}

function splitWords(text: string): string[] {
  return text
    .trim()
    .split(/\s+/)
    .filter(Boolean);
}

function trimNarrationToWords(words: string[], allowedWords: number): string {
  if (allowedWords <= 0) {
    return "";
  }

  const trimmed = words.slice(0, allowedWords).join(" ").trim();
  if (!trimmed) {
    return "";
  }

  const sentenceMatch = trimmed.match(/.*[.!?](?=\s|$)/);
  if (sentenceMatch?.[0]) {
    return sentenceMatch[0].trim();
  }

  return /[.!?]$/.test(trimmed) ? trimmed : `${trimmed}...`;
}

function estimateDurationSeconds(
  wordCount: number,
  wordsPerSecond: number,
): number {
  if (wordCount <= 0) {
    return 0;
  }

  return Math.max(1, Math.ceil(wordCount / wordsPerSecond));
}

function buildTimeRange(startSeconds: number, durationSeconds: number): string {
  const endSeconds = startSeconds + durationSeconds;
  return `${startSeconds}-${endSeconds}s`;
}

export function enforceVideoScriptLength(
  script: VideoScript,
  options: EnforceVideoScriptLengthOptions = {},
): VideoScript {
  const maxWords = options.maxWords ?? 215;
  const wordsPerSecond = options.wordsPerSecond ?? 3;
  const maxDuration = options.maxDuration ?? 65;

  let totalWords = 0;
  let totalDuration = 0;
  let sceneStart = 0;

  const scenes: VideoScene[] = script.scenes.map((scene) => {
    const sourceWords = splitWords(scene.narration);
    const remainingWords = Math.max(0, maxWords - totalWords);
    const remainingSeconds = Math.max(0, maxDuration - totalDuration);
    const durationWordBudget = Math.max(
      0,
      Math.floor(remainingSeconds * wordsPerSecond),
    );
    const allowedWords = Math.min(
      sourceWords.length,
      remainingWords,
      durationWordBudget,
    );

    const narration =
      allowedWords >= sourceWords.length
        ? scene.narration.trim()
        : trimNarrationToWords(sourceWords, allowedWords);

    const wordCount = splitWords(narration).length;
    const targetDuration = estimateDurationSeconds(wordCount, wordsPerSecond);
    const boundedDuration = Math.min(
      targetDuration,
      Math.max(0, maxDuration - totalDuration),
    );
    const nextScene: VideoScene = {
      ...scene,
      narration,
      targetDuration: boundedDuration,
      timeRange: buildTimeRange(sceneStart, boundedDuration),
    };

    totalWords += wordCount;
    totalDuration += boundedDuration;
    sceneStart += boundedDuration;

    return nextScene;
  });

  return {
    ...script,
    totalDuration,
    scenes,
  };
}
