"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, FileText, Zap, Shield, LogIn, UserPlus, Brain, Users, Globe, Activity, ArrowRight, Loader2, RefreshCw, Settings } from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { NotificationBell } from "@/components/NotificationBell";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { DailyBriefCard } from "@/components/brief/DailyBriefCard";
import { BriefSkeleton } from "@/components/brief/BriefSkeleton";
import { useToast } from "@/hooks/use-toast";

const ACTIVE_STATUSES = ["SUBMITTING", "QUEUED", "PROCESSING", "RUNNING", "IN_PROGRESS"];

interface RecentBatch {
  id: number;
  coreTopic: string;
  status: string;
  numArticlesRequested: number;
  createdAt: string;
}

export default function Home() {
  const { user, logout } = useAuth();
  const { toast } = useToast();

  const { data: recentBatches, isLoading: batchesLoading } = useQuery<RecentBatch[]>({
    queryKey: ["/api/batches"],
    enabled: !!user,
    refetchInterval: (query) => {
      const list = query.state.data as RecentBatch[] | undefined;
      return list?.some(b => ACTIVE_STATUSES.includes(b.status)) ? 5000 : false;
    },
    refetchIntervalInBackground: false,
  });

  const { data: briefData, isLoading: briefLoading, refetch: refetchBrief } = useQuery<{
    available: boolean; brief?: any; id?: number; localDate?: string;
  }>({
    queryKey: ["/api/briefs/today"],
    enabled: !!user,
    refetchInterval: (query) => {
      // Poll every 8s if brief is absent (could be generating)
      return query.state.data?.available ? false : 8000;
    },
    refetchIntervalInBackground: false,
  });

  const generateBriefMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("/api/briefs/generate-me", { method: "POST" });
    },
    onSuccess: () => {
      toast({
        title: "Brief queued",
        description: "Your brief is being generated — it'll appear here in about 15 seconds.",
      });
      // Start polling immediately
      setTimeout(() => refetchBrief(), 10000);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-8 py-16 space-y-16">
        <div className="text-center space-y-4">
          <div className="flex justify-end gap-2 mb-8">
            {user ? (
              <div className="flex items-center gap-3">
                <NotificationBell />
                <span className="text-sm text-muted-foreground">
                  {user.email}
                </span>
                <Button variant="outline" size="sm" onClick={logout} data-testid="button-logout">
                  Logout
                </Button>
              </div>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline" size="sm" data-testid="button-login-link">
                    <LogIn className="w-4 h-4 mr-2" />
                    Login
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button size="sm" data-testid="button-signup-link">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent" data-testid="text-page-title">
            Citefi
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-page-description">
            Enterprise-grade dual-AI SEO content factory powered by advanced AI
          </p>
        </div>

        {/* Daily Marketing Brief Section */}
        {user && (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              Daily Marketing Brief
            </h2>
            {briefLoading ? (
              <BriefSkeleton />
            ) : briefData?.available ? (
              <DailyBriefCard brief={briefData.brief} id={briefData.id!} />
            ) : (
              <Card className="bg-muted/30 border-dashed">
                <CardContent className="py-10 text-center space-y-4">
                  <div className="flex flex-col items-center gap-2">
                    <Sparkles className="w-8 h-8 text-muted-foreground/50" />
                    <p className="text-muted-foreground font-medium">No brief for today yet</p>
                    <p className="text-sm text-muted-foreground/70 max-w-xs">
                      Briefs auto-generate at your configured time. You can also generate one now.
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-3 flex-wrap">
                    <Button
                      onClick={() => generateBriefMutation.mutate()}
                      disabled={generateBriefMutation.isPending}
                      data-testid="button-generate-brief-now"
                    >
                      {generateBriefMutation.isPending ? (
                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating…</>
                      ) : (
                        <><Zap className="w-4 h-4 mr-2" /> Generate my brief now</>
                      )}
                    </Button>
                    <Link href="/settings/brief">
                      <Button variant="outline" size="sm" data-testid="button-brief-settings">
                        <Settings className="w-3.5 h-3.5 mr-1.5" />
                        Schedule settings
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Recent Jobs strip — only for logged-in users */}
        {user && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Recent Jobs
              </h2>
              <Link href="/content">
                <Button variant="ghost" size="sm" data-testid="button-view-all-batches">
                  View all
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
            {batchesLoading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading recent jobs…
              </div>
            ) : recentBatches && recentBatches.length > 0 ? (
              <div className="grid gap-2">
                {recentBatches.slice(0, 5).map(batch => (
                  <Link key={batch.id} href={`/batches/${batch.id}`}>
                    <div className="flex items-center justify-between p-3 rounded-md bg-card border hover-elevate cursor-pointer" data-testid={`batch-row-${batch.id}`}>
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-sm font-medium truncate">{batch.coreTopic}</span>
                        <span className="text-xs text-muted-foreground shrink-0">
                          {batch.numArticlesRequested} articles
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 ml-3">
                        <Badge
                          variant={
                            batch.status === "COMPLETE" ? "default"
                            : ["FAILED", "CANCELLED"].includes(batch.status) ? "destructive"
                            : "secondary"
                          }
                          className={ACTIVE_STATUSES.includes(batch.status) ? "animate-pulse" : ""}
                        >
                          {batch.status}
                        </Badge>
                        <ArrowRight className="w-4 h-4 text-muted-foreground" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground p-4 rounded-md border text-center">
                No jobs yet.{" "}
                <Link href="/dashboard" className="text-primary underline underline-offset-2">
                  Start your first batch
                </Link>
              </div>
            )}
          </div>
        )}

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card className="hover-elevate border-primary/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Dashboard
              </CardTitle>
              <CardDescription>
                Generate 1 or multiple articles with full SEO optimization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard">
                <Button className="w-full" data-testid="button-dashboard">
                  Start Creating
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Content Library
              </CardTitle>
              <CardDescription>
                Browse and export your generated articles
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/content">
                <Button className="w-full" variant="outline" data-testid="button-content">
                  View Content
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate border-purple-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-600" />
                Social Media AI
              </CardTitle>
              <CardDescription>
                Generate & schedule posts for X, Facebook, Instagram, Pinterest, LinkedIn
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/social">
                <Button className="w-full" data-testid="button-social">
                  Social Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-primary" />
                SEO Tools
              </CardTitle>
              <CardDescription>
                AI-powered local research, competitor analysis, and content optimization
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/seo-tools">
                <Button className="w-full" variant="outline" data-testid="button-seo-tools">
                  SEO Intelligence
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Media Library
              </CardTitle>
              <CardDescription>
                Upload and manage images, audio, and video files
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/media">
                <Button className="w-full" variant="outline" data-testid="button-media">
                  Media Manager
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate border-green-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-green-600" />
                AI Learning Center
              </CardTitle>
              <CardDescription>
                View what your AI has learned and optimize agents for better content
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/learning">
                <Button className="w-full" variant="outline" data-testid="button-learning">
                  AI Learning
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate border-orange-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-orange-600" />
                Audience Personas
              </CardTitle>
              <CardDescription>
                Create OCEAN-based personality profiles for psychographic content targeting
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/personas">
                <Button className="w-full" variant="outline" data-testid="button-personas">
                  Manage Personas
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate border-cyan-500/30">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-cyan-600" />
                Site Map
              </CardTitle>
              <CardDescription>
                Crawl your website to enable intelligent multi-page hyperlinking in articles
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/site-map">
                <Button className="w-full" variant="outline" data-testid="button-site-map">
                  Manage Site Map
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover-elevate border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Admin
              </CardTitle>
              <CardDescription>
                User management, system monitoring, SEO reports, cost tracking
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {user && user.role === "admin" && (
                <Link href="/admin/users">
                  <Button className="w-full" variant="default" data-testid="button-admin-users">
                    User Management
                  </Button>
                </Link>
              )}
              <Link href="/admin">
                <Button className="w-full" variant={user && user.role === "admin" ? "outline" : "default"} data-testid="button-admin">
                  Admin Dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              3-Stage Content Pipeline
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-semibold">Stage 1: Title Pool Generation</h3>
              <p className="text-sm text-muted-foreground">
                AI generates 50 SEO-optimized article titles with keywords and content strategy
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold">Stage 2: Content & Image Generation</h3>
              <p className="text-sm text-muted-foreground">
                AI creates 800-2000 word articles with structured metadata and generates 5 images per article
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-semibold">Stage 3: QA & Finalization</h3>
              <p className="text-sm text-muted-foreground">
                AI inserts hyperlinks, places images strategically, and formats publication-ready HTML
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
