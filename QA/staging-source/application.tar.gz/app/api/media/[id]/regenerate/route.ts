import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { articleAssets, articles, jobBatches } from "@/shared/schema";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { generateSingleImage } from "@/lib/gemini-image-generator";
import { uploadMedia } from "@/lib/storage";
import { createImageBrandLockPromptSegment } from "@/lib/branding";
import { withAuthenticatedTeamContext } from "@/lib/api/auth";
import { runDirectImageOperation } from "@/lib/direct-image-operation";

const regenerateSchema = z.object({
  prompt: z.string().min(10, "Prompt must be at least 10 characters"),
});

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    return await withAuthenticatedTeamContext(request, async ({ teamId, userId }) => {
    const { id } = await params;
    const assetId = parseInt(id);

    if (isNaN(assetId)) {
      return NextResponse.json(
        { error: "Invalid asset ID" },
        { status: 400 }
      );
    }

    const body = await request.json();
    const { prompt } = regenerateSchema.parse(body);

    // Get the asset details — enforce team ownership
    const [asset] = await db
      .select()
      .from(articleAssets)
      .where(and(
        eq(articleAssets.id, assetId),
        eq(articleAssets.teamId, teamId),
      ));

    if (!asset) {
      return NextResponse.json(
        { error: "Asset not found" },
        { status: 404 }
      );
    }
    const assetTeamId = asset.teamId;
    if (assetTeamId == null || !Number.isInteger(assetTeamId) || assetTeamId <= 0) {
      throw new Error(`Media asset ${assetId} is missing a validated teamId`);
    }

    if (asset.assetType !== 'image') {
      return NextResponse.json(
        { error: "Can only regenerate images" },
        { status: 400 }
      );
    }

    // Get article to retrieve batch and businessName for brand lock — enforce team ownership
    let businessName: string | undefined;
    if (asset.articleId) {
      const [article] = await db
        .select()
        .from(articles)
        .where(and(eq(articles.id, asset.articleId), eq(articles.teamId, assetTeamId)));
      
      if (article?.batchId) {
        const [batch] = await db
          .select()
          .from(jobBatches)
          .where(and(eq(jobBatches.id, article.batchId), eq(jobBatches.teamId, teamId)));
        
        // CRITICAL: Validate businessName before image regeneration
        if (!batch?.businessName || batch.businessName.trim().length === 0) {
          return NextResponse.json(
            {
              error: "Business name required",
              message: "This batch was created without a business name. Image regeneration requires a valid business name to prevent AI hallucination of company names in images. Please update the batch business name first."
            },
            { status: 400 }
          );
        }
        
        businessName = batch.businessName;
      }
    }

    // Apply IMAGE-SPECIFIC brand lock to user's custom prompt
    const enhancedPrompt = businessName 
      ? `${prompt}\n\n${createImageBrandLockPromptSegment(businessName)}`
      : prompt;

    console.log(`🔄 Regenerating image ${assetId}${businessName ? ` with image brand lock: "${businessName}"` : ''}`);

    // Generate new image with Gemini 2.5 Flash Image with image-specific brand lock
    const result = await runDirectImageOperation({
      teamId: assetTeamId,
      userId,
      resourceType: "media_asset",
      resourceId: assetId,
      resourceVersion: asset.storageUrl,
      requestKey: request.headers.get("x-idempotency-key"),
      generate: async () => {
        const dataUrl = await generateSingleImage(enhancedPrompt, {
          teamId: assetTeamId,
          articleId: asset.articleId ?? undefined,
          resourceType: "media_asset",
          resourceId: assetId,
        });
        if (!dataUrl) throw new Error("Gemini rejected image generation before returning a paid result");
        return dataUrl;
      },
      persist: async (dataUrl) => {

    console.log(`✅ Gemini image generated, extracting data...`);

    // Extract base64 data from data URL
    const base64Data = dataUrl.replace(/^data:image\/\w+;base64,/, "");
    const imageBuffer = Buffer.from(base64Data, "base64");
    
    // Generate new filename
    const timestamp = Date.now();
    const filename = `regenerated-${timestamp}.png`;
    
    // Determine storage path based on article ID
    let storagePath: string;
    if (asset.articleId) {
      storagePath = `public/article-${asset.articleId}/images/${filename}`;
    } else {
      storagePath = `public/media/${filename}`;
    }

    // Upload to permanent storage
    console.log(`📤 Uploading to storage: ${storagePath}`);
    const permanentUrl = await uploadMedia({
      fileData: Buffer.from(imageBuffer),
      fileName: filename,
      contentType: "image/png",
      assetType: 'image',
    });

    console.log(`✅ Uploaded to permanent storage: ${permanentUrl}`);

    // Store the old URL for replacement in article HTML
    const oldUrl = asset.storageUrl;

    const updatedAsset = await db.transaction(async (tx) => {
      const [updated] = await tx
        .update(articleAssets)
        .set({
          storageUrl: permanentUrl,
          imagePromptUsed: prompt,
          metadataJson: {
            ...(asset.metadataJson as Record<string, unknown> | null ?? {}),
            regeneratedAt: new Date().toISOString(),
            originalPrompt: asset.imagePromptUsed,
          }
        })
        .where(and(eq(articleAssets.id, assetId), eq(articleAssets.teamId, assetTeamId)))
        .returning();
      if (!updated) throw new Error("Generated image could not be linked to its media asset");

      if (asset.articleId) {
        const [article] = await tx
          .select()
          .from(articles)
          .where(and(eq(articles.id, asset.articleId), eq(articles.teamId, assetTeamId)));
        if (article) {
          const updatedFields: Record<string, string> = {};
          if (article.heroImageUrl === oldUrl) updatedFields.heroImageUrl = permanentUrl;
          if (article.finalHtmlContent?.includes(oldUrl)) {
            updatedFields.finalHtmlContent = article.finalHtmlContent.replace(
              new RegExp(oldUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), "g"),
              permanentUrl,
            );
          }
          if (Object.keys(updatedFields).length > 0) {
            await tx.update(articles)
              .set(updatedFields)
              .where(and(eq(articles.id, asset.articleId), eq(articles.teamId, assetTeamId)));
          }
        }
      }
      return updated;
    });

    console.log(`✅ Image ${assetId} regenerated successfully`);

        return updatedAsset;
      },
    });

    return NextResponse.json({
      success: true,
      asset: result,
      message: "Image regenerated successfully",
    });
    });
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { 
          error: "Invalid request data",
          details: error.errors
        },
        { status: 400 }
      );
    }

    console.error("❌ Image regeneration error:", error);
    return NextResponse.json(
      { 
        error: "Failed to regenerate image",
        message: error instanceof Error ? error.message : "Unknown error",
        code: error?.code,
        ...(error?.details ?? {}),
      },
      { status: error?.statusCode || 500 }
    );
  }
}
