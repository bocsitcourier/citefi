import { NextResponse } from "next/server";
import { systemDb as db } from "@/lib/db";
import {
  users,
  emailVerificationCodes,
  passwordResets,
  activityLogs,
} from "@/shared/schema";
import { generateEmailCode } from "@/lib/auth";
import { rateLimitDb, getClientIp } from "@/lib/db-rate-limit";
import { eq, and, sql } from "drizzle-orm";
import { sendEmailVerificationCode } from "@/lib/email";

export async function POST(req: Request) {
  try {
    const ip = getClientIp(req);
    const rl = await rateLimitDb(`email-code:${ip}`, 5, 15 * 60 * 1000);
    if (!rl.allowed) {
      return NextResponse.json(
        { error: "Too many code requests. Please try again later." },
        { status: 429, headers: { "Retry-After": String(rl.retryAfter) } }
      );
    }

    const body = await req.json();
    const { userId, purpose } = body;

    if (!userId || !purpose) {
      return NextResponse.json(
        { error: "userId and purpose are required" },
        { status: 400 }
      );
    }

    const userRl = await rateLimitDb(`email-code:user:${userId}`, 5, 15 * 60 * 1000);
    if (!userRl.allowed) {
      return NextResponse.json(
        { error: "Too many code requests for this account. Please try again later." },
        { status: 429, headers: { "Retry-After": String(userRl.retryAfter) } }
      );
    }

    // Login codes are issued only after password verification by /auth/login.
    if (purpose === "login_2fa") {
      return NextResponse.json({ error: "Login verification codes require a password-verified challenge" }, { status: 401 });
    }
    const validPurposes = ["email_verification", "password_reset"];
    if (!validPurposes.includes(purpose)) {
      return NextResponse.json(
        { error: "Invalid purpose" },
        { status: 400 }
      );
    }

    // Fetch user — return same response whether or not the user exists to prevent
    // user-existence enumeration. Rate limiting above is the primary abuse control.
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user) {
      // Don't reveal that the userId is invalid — silently succeed
      return NextResponse.json({
        message: "Verification code sent successfully",
        expiresIn: 600,
      });
    }

    // Generate 6-digit code
    const code = generateEmailCode();

    const issued = await db.transaction(async (tx) => {
      const [lockedUser] = await tx
        .update(users)
        .set({ passwordHash: sql`${users.passwordHash}` })
        .where(eq(users.id, userId))
        .returning({ id: users.id });
      if (!lockedUser) return false;

      await tx
        .update(emailVerificationCodes)
        .set({ isUsed: 1 })
        .where(
          and(
            eq(emailVerificationCodes.userId, userId),
            eq(emailVerificationCodes.purpose, purpose)
          )
        );

      if (purpose === "password_reset") {
        await tx
          .update(passwordResets)
          .set({ status: "cancelled" })
          .where(
            and(
              eq(passwordResets.userId, userId),
              eq(passwordResets.status, "pending"),
            )
          );
      }

      await tx
        .insert(emailVerificationCodes)
        .values({
          userId,
          code,
          purpose,
          attempts: 0,
          isUsed: 0,
          expiresAt: new Date(Date.now() + 10 * 60 * 1000),
        });

      await tx.insert(activityLogs).values({
        userId,
        action: "email_code_sent",
        resource: "users",
        resourceId: userId,
        ipAddress: req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || null,
        userAgent: req.headers.get("user-agent") || null,
        details: { purpose },
        severity: "info",
      });
      return true;
    });
    if (!issued) {
      return NextResponse.json({
        message: "Verification code sent successfully",
        expiresIn: 600,
      });
    }

    // Send the code via email. Errors are caught so a transient delivery failure
    // doesn't block the user — they can re-request a new code.
    try {
      await sendEmailVerificationCode({
        to: user.email,
        code,
        purpose: purpose as "login_2fa" | "email_verification" | "password_reset",
        fullName: user.fullName,
      });
    } catch (emailErr) {
      console.error("Verification email delivery failed", {
        purpose,
        error: emailErr instanceof Error ? emailErr.message : "Unknown delivery error",
      });
      // In development fall through — the code is still in the DB so the caller
      // can use the returned code field to test without a real SMTP server.
      if (process.env.NODE_ENV !== "development") {
        return NextResponse.json(
          { error: "Failed to send verification email. Please try again." },
          { status: 503 }
        );
      }
    }

    return NextResponse.json({
      message: "Verification code sent successfully",
      expiresIn: 600, // 10 minutes in seconds
    });

  } catch (error) {
    console.error("Send email code error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
