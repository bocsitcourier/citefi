import { NextRequest, NextResponse } from "next/server";
import { learningService } from "@/lib/learning-service";
import { withAuthenticatedTeamContext } from "@/lib/api/auth";

export async function POST(request: NextRequest) {
  try {
    return await withAuthenticatedTeamContext(request, async ({ teamId }) => {

    const body = await request.json();
    const { metricId, views, clicks, shares, likes, comments, timeOnPage, bounceRate } = body;

    if (typeof metricId !== "number") {
      return NextResponse.json({ success: false, error: "metricId is required" }, { status: 400 });
    }

    await learningService.recordEngagement(teamId, metricId, {
      views,
      clicks,
      shares,
      likes,
      comments,
      timeOnPage,
      bounceRate,
    });

    return NextResponse.json({
      success: true,
      message: "Engagement recorded",
    });
    });
  } catch (error: any) {
    console.error("Failed to record engagement:", error);
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "Failed to record engagement" },
      { status: error?.statusCode || 500 }
    );
  }
}
