import { NextRequest, NextResponse } from "next/server";
import { withAuthenticatedTeamAdminContext } from "@/lib/api/auth";
import { db } from "@/lib/db";
import { teams, clientBrandProfiles } from "@/shared/schema";
import { eq, and, isNull, inArray } from "drizzle-orm";

/**
 * GET /api/intelligence/agency
 * Returns brand-intelligence statuses + top competitive gap preview
 * for all client teams under the current agency.
 * The caller must be an admin of the parent agency team.
 */
export async function GET(req: NextRequest) {
  try {
    return await withAuthenticatedTeamAdminContext(req, async ({ teamId }) => {

    // Fetch all client teams under this agency
    const clientTeams = await db
      .select({ id: teams.id })
      .from(teams)
      .where(and(eq(teams.parentTeamId, teamId), isNull(teams.deletedAt)));

    if (clientTeams.length === 0) {
      return NextResponse.json({ statuses: {} });
    }

    const clientIds = clientTeams.map((t) => t.id);

    const profiles = await db
      .select({
        teamId: clientBrandProfiles.teamId,
        status: clientBrandProfiles.status,
        companyName: clientBrandProfiles.companyName,
        lastRunAt: clientBrandProfiles.lastRunAt,
        profileJson: clientBrandProfiles.profileJson,
      })
      .from(clientBrandProfiles)
      .where(inArray(clientBrandProfiles.teamId, clientIds));

    const statuses: Record<number, {
      status: string;
      companyName: string;
      lastRunAt: string | null;
      topGaps: string[];
    }> = {};

    for (const p of profiles) {
      // Extract top 3 competitive opportunity topics from the completed profile
      let topGaps: string[] = [];
      if (p.status === "complete" && p.profileJson) {
        const json = p.profileJson as any;
        const opportunityTopics: string[] = json?.competitiveGaps?.opportunityTopics ?? [];
        topGaps = opportunityTopics.slice(0, 3);
      }

      statuses[p.teamId] = {
        status: p.status,
        companyName: p.companyName,
        lastRunAt: p.lastRunAt ? p.lastRunAt.toISOString() : null,
        topGaps,
      };
    }

      return NextResponse.json({ statuses });
    });
  } catch (err: any) {
    if (err.statusCode) return NextResponse.json({ error: err.message }, { status: err.statusCode });
    console.error("GET /api/intelligence/agency error:", err);
    return NextResponse.json({ error: "Failed to load intelligence statuses" }, { status: 500 });
  }
}
