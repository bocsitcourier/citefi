import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { articles, articleAssets, jobBatches, errorLogs } from "@/shared/schema";
import { and, eq, asc, desc, isNull, sql } from "drizzle-orm";
import { z } from "zod";
import { withAuthenticatedTeamContext, requireTeamResource } from "@/lib/api/auth";
import { assertValidArticleOutput } from "@/lib/article-output-safety";

// Helper: Convert any absolute image URL to a relative /api/public-objects/ path.
// This makes URLs immune to Replit dev domain changes and works on any deployment.
function normalizeImageUrl(url: string | null): string | null {
  if (!url) return null;

  // Already relative — ideal format
  if (url.startsWith('/api/public-objects/')) {
    return url;
  }

  // Any absolute URL that routes through /api/public-objects/ (riker.replit.dev, etc.)
  // e.g. https://xxx.riker.replit.dev/api/public-objects/article-784/image/xxx.png
  const publicObjectsMatch = url.match(/\/api\/public-objects\/(.+)$/);
  if (publicObjectsMatch) {
    return `/api/public-objects/${publicObjectsMatch[1]}`;
  }

  // Google Cloud Storage direct URL: https://storage.googleapis.com/{bucket}/public/{path}
  const bucketId = process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID;
  if (bucketId && url.includes('storage.googleapis.com') && url.includes(bucketId)) {
    const match = url.match(/\/public\/(.+)$/);
    if (match) {
      return `/api/public-objects/${match[1]}`;
    }
  }

  // Old GCS format: https://{bucket}.id.repl.co/public/{path}
  if (bucketId && url.includes(`${bucketId}.id.repl.co/public/`)) {
    const path = url.split('/public/')[1];
    return `/api/public-objects/${path}`;
  }

  // Legacy temporary DALL-E URLs (oaidalleapiprodscus.blob.core.windows.net) — expired
  if (url.includes('oaidalleapiprodscus.blob.core.windows.net')) {
    return null;
  }

  return url;
}

export async function GET(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    return await withAuthenticatedTeamContext(request, async (auth) => {
      const { userId, teamId } = auth;
    const { id } = await context.params;
    const articleId = parseInt(id);

    if (isNaN(articleId)) {
      return NextResponse.json(
        { error: "Invalid article ID" },
        { status: 400 }
      );
    }

    const [article] = await db
      .select()
      .from(articles)
      .where(and(eq(articles.id, articleId), eq(articles.teamId, teamId)));

    if (!article) {
      return NextResponse.json(
        { error: "Article not found" },
        { status: 404 }
      );
    }
    if (article.teamId === null) {
      return NextResponse.json({ error: "Article not found" }, { status: 404 });
    }
    requireTeamResource(article.teamId, teamId);

    // Run remaining queries in parallel — they're all independent once we have the article
    const [batchResult, assets, errors] = await Promise.all([
      db.select().from(jobBatches).where(eq(jobBatches.id, article.batchId)),
      db.select().from(articleAssets).where(eq(articleAssets.articleId, articleId)).orderBy(asc(articleAssets.id)),
      db.select().from(errorLogs).where(eq(errorLogs.articleId, articleId)).orderBy(desc(errorLogs.createdAt)).limit(10),
    ]);
    const batch = batchResult[0];

    return NextResponse.json({
      article: {
        id: article.id,
        batchId: article.batchId,
        targetUrl: batch?.targetUrl || null,
        status: article.articleStatus,
        title: article.chosenTitle,
        heroImageUrl: normalizeImageUrl(article.heroImageUrl),
        seoTitle: article.seoTitle,
        metaDescription: article.metaDescription,
        slug: article.slug,
        keywords: article.keywordsJson,
        hashtags: article.hashtagsJson,
        faq: article.faqJson,
        wordCount: article.wordCount,
        htmlContent: article.finalHtmlContent,
        seoScore: article.seoScore,
        hyperlinkedKeywords: article.hyperlinkedKeywordsJson,
        metaEnrichment: article.metaEnrichment,
        podcastUrl: normalizeImageUrl(article.podcastUrl),
        podcastDuration: article.podcastDuration,
        podcastStatus: article.podcastStatus,
        podcastGeneratedAt: article.podcastGeneratedAt,
        podcastScriptJson: article.podcastScriptJson,
        businessName: batch?.businessName || null,
        createdAt: article.createdAt,
        updatedAt: article.updatedAt,
      },
      errors: errors.map(err => ({
        id: err.id,
        errorType: err.errorType,
        errorMessage: err.errorMessage,
        severity: err.severity,
        createdAt: err.createdAt,
      })),
      assets: assets.map(asset => ({
        id: asset.id,
        url: normalizeImageUrl(asset.storageUrl) || asset.storageUrl,
        altText: asset.altText,
        prompt: asset.imagePromptUsed,
        format: asset.fileFormat,
      })),
    });
      });
  } catch (error: any) {
    console.error("Error fetching article:", error);
    return NextResponse.json(
      { error: "Failed to fetch article" },
      { status: error?.statusCode || 500 }
    );
  }
}

const updateArticleSchema = z.object({
  expectedUpdatedAt: z.string().datetime(),
  finalHtmlContent: z.string().optional(),
  seoTitle: z.string().max(60).optional(),
  metaDescription: z.string().max(160).optional(),
  slug: z.string().max(255).optional(),
  keywordsJson: z.array(z.string()).optional(),
  hashtagsJson: z.array(z.string()).optional(),
});

export async function PUT(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    return await withAuthenticatedTeamContext(request, async (auth) => {
      const { teamId } = auth;
    const { id } = await context.params;
    const articleId = parseInt(id);

    if (isNaN(articleId)) {
      return NextResponse.json(
        { error: "Invalid article ID" },
        { status: 400 }
      );
    }

    const body = await request.json();
    const validation = updateArticleSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: "Invalid request", details: validation.error.errors },
        { status: 400 }
      );
    }

    const updateData = validation.data;
    if (updateData.finalHtmlContent !== undefined) {
      try {
        assertValidArticleOutput(updateData.finalHtmlContent, { format: "html" });
      } catch {
        return NextResponse.json(
          { error: "Invalid article output: HTML article content is required" },
          { status: 400 },
        );
      }
    }

    const [article] = await db
      .select()
      .from(articles)
      .where(and(eq(articles.id, articleId), eq(articles.teamId, teamId)));

    if (!article) {
      return NextResponse.json(
        { error: "Article not found" },
        { status: 404 }
      );
    }
    if (article.teamId === null) {
      return NextResponse.json({ error: "Article not found" }, { status: 404 });
    }
    requireTeamResource(article.teamId, teamId);

    const updatePayload: any = {};
    if (updateData.finalHtmlContent !== undefined) updatePayload.finalHtmlContent = updateData.finalHtmlContent;
    if (updateData.seoTitle !== undefined) updatePayload.seoTitle = updateData.seoTitle;
    if (updateData.metaDescription !== undefined) updatePayload.metaDescription = updateData.metaDescription;
    if (updateData.slug !== undefined) updatePayload.slug = updateData.slug;
    if (updateData.keywordsJson !== undefined) updatePayload.keywordsJson = updateData.keywordsJson;
    if (updateData.hashtagsJson !== undefined) updatePayload.hashtagsJson = updateData.hashtagsJson;
    updatePayload.updatedAt = new Date(Math.max(Date.now(), Date.parse(updateData.expectedUpdatedAt) + 1));
    updatePayload.approvalStatus = "draft";
    updatePayload.approvalReviewedAt = null;
    updatePayload.approvalReviewedBy = null;

    if (Object.keys(updatePayload).length > 1) {
      const [updated] = await db
        .update(articles)
        .set(updatePayload)
        .where(and(eq(articles.id, articleId), eq(articles.teamId, teamId), isNull(articles.deletedAt),
          sql`date_trunc('milliseconds', ${articles.updatedAt}) = ${new Date(updateData.expectedUpdatedAt)}`))
        .returning();
      if (!updated) return NextResponse.json({ error: "Article changed; reload before saving" }, { status: 409 });

      return NextResponse.json({
        success: true,
        message: "Article updated successfully",
        article: updated,
      });
    }

    return NextResponse.json({
      success: true,
      message: "No changes to save",
    });
      });
  } catch (error: any) {
    console.error("Error updating article:", error);
    return NextResponse.json(
      { error: "Failed to update article", message: error instanceof Error ? error.message : "Unknown error" },
      { status: error?.statusCode || 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    return await withAuthenticatedTeamContext(request, async (auth) => {
      const { teamId } = auth;
    const { id } = await context.params;
    const articleId = parseInt(id);

    if (isNaN(articleId)) {
      return NextResponse.json(
        { error: "Invalid article ID" },
        { status: 400 }
      );
    }

    const [article] = await db
      .select()
      .from(articles)
      .where(and(eq(articles.id, articleId), eq(articles.teamId, teamId)));

    if (!article) {
      return NextResponse.json(
        { error: "Article not found" },
        { status: 404 }
      );
    }
    if (article.teamId === null) {
      return NextResponse.json({ error: "Article not found" }, { status: 404 });
    }
    requireTeamResource(article.teamId, teamId);

    const assets = await db
      .select()
      .from(articleAssets)
      .where(eq(articleAssets.articleId, articleId))
      .orderBy(asc(articleAssets.id));

    await db.delete(articleAssets).where(eq(articleAssets.articleId, articleId));

    if (assets.length > 0) {
      const { deleteFromStorage } = await import("@/lib/storage");
      for (const asset of assets) {
        try {
          await deleteFromStorage(asset.storageUrl);
        } catch (err: any) {
          console.warn(`Failed to delete asset from storage: ${asset.storageUrl}`, err);
        }
      }
    }

    await db.delete(articles).where(and(eq(articles.id, articleId), eq(articles.teamId, teamId)));

    // MVP: Skip audit log for now
    // TODO: Add audit logging when admin features are implemented

    return NextResponse.json({
      success: true,
      message: "Article and all related data deleted successfully",
      deletedAssets: assets.length,
    });
      });
  } catch (error: any) {
    console.error("Error deleting article:", error);
    return NextResponse.json(
      { error: "Failed to delete article", message: error instanceof Error ? error.message : "Unknown error" },
      { status: error?.statusCode || 500 }
    );
  }
}
