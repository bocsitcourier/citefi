import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { articles } from "@/shared/schema";
import { eq, and, isNull, sql } from "drizzle-orm";
import { withAuthenticatedTeamContext } from "@/lib/api/auth";
import { assertValidArticleOutput } from "@/lib/article-output-safety";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // CRITICAL: Verify authentication and get team context
    return await withAuthenticatedTeamContext(request, async (auth) => {
      const { teamId } = auth;

    const resolvedParams = await params;
    const articleId = parseInt(resolvedParams.id);
    const body = await request.json();

    const { htmlContent, title, seoTitle, metaDescription, slug, hyperlinkedKeywords, hashtags, expectedUpdatedAt } = body;
    if (typeof expectedUpdatedAt !== "string" || !Number.isFinite(Date.parse(expectedUpdatedAt))) {
      return NextResponse.json({ error: "Reload the article before saving; a version is required" }, { status: 409 });
    }

    if (!articleId || isNaN(articleId)) {
      return NextResponse.json(
        { error: "Invalid article ID" },
        { status: 400 }
      );
    }
    if (htmlContent !== undefined) {
      try {
        assertValidArticleOutput(htmlContent, { format: "html" });
      } catch {
        return NextResponse.json(
          { error: "Invalid article output: HTML article content is required" },
          { status: 400 },
        );
      }
    }

    const updateData: any = {
      updatedAt: new Date(Math.max(Date.now(), Date.parse(expectedUpdatedAt) + 1)),
      approvalStatus: "draft",
      approvalReviewedAt: null, approvalReviewedBy: null,
    };

    if (htmlContent !== undefined) updateData.finalHtmlContent = htmlContent;
    if (title !== undefined) updateData.chosenTitle = title;
    if (seoTitle !== undefined) updateData.seoTitle = seoTitle;
    if (metaDescription !== undefined) updateData.metaDescription = metaDescription;
    if (slug !== undefined) updateData.slug = slug;
    if (hyperlinkedKeywords !== undefined) updateData.hyperlinkedKeywordsJson = hyperlinkedKeywords;
    if (hashtags !== undefined) updateData.hashtagsJson = hashtags;

    if (htmlContent) {
      const text = htmlContent.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
      const words = text.split(/\s+/).filter((w: string) => w.length > 0);
      updateData.wordCount = words.length;
    }

    // CRITICAL: Update only if article belongs to user's team
    const [updated] = await db
      .update(articles)
      .set(updateData)
      .where(
        and(
          eq(articles.id, articleId),
          eq(articles.teamId, teamId), // TEAM ISOLATION
          isNull(articles.deletedAt),
          sql`date_trunc('milliseconds', ${articles.updatedAt}) = ${new Date(expectedUpdatedAt)}`
        )
      )
      .returning();

    if (!updated) {
      return NextResponse.json(
        { error: "Article changed or is unavailable; reload before saving" },
        { status: 409 }
      );
    }

    return NextResponse.json({ 
      success: true, 
      article: updated 
    });
      });
  } catch (error: any) {
    console.error("Error updating article:", error);
    return NextResponse.json(
      { error: "Failed to update article" },
      { status: error?.statusCode || 500 }
    );
  }
}
