import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { socialPosts, socialPostLogs } from "@/shared/schema";
import { eq, and } from "drizzle-orm";
import { withAuthenticatedTeamContext } from "@/lib/api/auth";
import { scheduleSocialPost } from "@/lib/social-scheduling";

const scheduleSchema = z.object({
  socialPostId: z.number(),
  scheduleAt: z.string().datetime(),
});

export async function POST(request: NextRequest) {
  try {
    // CRITICAL: Verify authentication and get team context
    return await withAuthenticatedTeamContext(request, async ({ teamId }) => {

    const body = await request.json();
    const { socialPostId, scheduleAt } = scheduleSchema.parse(body);

    // Validate scheduleAt is in the future
    const scheduleDate = new Date(scheduleAt);
    if (scheduleDate <= new Date()) {
      return NextResponse.json(
        { error: "scheduleAt must be a future date/time" },
        { status: 400 }
      );
    }

    // CRITICAL: Verify post exists AND belongs to user's team
    const [existingPost] = await db
      .select()
      .from(socialPosts)
      .where(
        and(
          eq(socialPosts.id, socialPostId),
          eq(socialPosts.teamId, teamId) // TEAM ISOLATION
        )
      );

    if (!existingPost) {
      return NextResponse.json(
        { error: "Social post not found or access denied" },
        { status: 404 }
      );
    }

    // Guard: terminal/already-delivered posts cannot be rescheduled
    const NON_SCHEDULABLE = ["POSTED", "DELETED"];
    if (NON_SCHEDULABLE.includes(existingPost.status)) {
      return NextResponse.json(
        { error: `Cannot schedule a post with status '${existingPost.status}'` },
        { status: 409 }
      );
    }

    const updatedPost = await scheduleSocialPost(socialPostId, teamId, scheduleAt, existingPost.status);

    await db.insert(socialPostLogs).values({
      socialPostId,
      eventType: "SCHEDULED",
      stage: "API",
      message: `Post scheduled for ${scheduleAt}`,
      severity: "info",
      payloadJson: { scheduleAt },
    });

    return NextResponse.json({ 
      success: true, 
      post: updatedPost,
      message: `Post scheduled for ${scheduleAt}`
    });
    });
  } catch (error: any) {
    console.error("Error scheduling social post:", error);

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", details: error.errors },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: "Failed to schedule social post" },
      { status: error?.statusCode || 500 }
    );
  }
}
