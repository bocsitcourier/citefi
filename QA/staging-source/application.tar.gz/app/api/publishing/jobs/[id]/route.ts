import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { publishingJobs, articles } from '@/shared/schema';
import { eq, and, isNull, inArray } from 'drizzle-orm';
import { withAuthenticatedTeamContext } from '@/lib/api/auth';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    return await withAuthenticatedTeamContext(request, async (auth) => {
      const { teamId } = auth;
    const { id } = await params;
    const jobId = parseInt(id);

    if (isNaN(jobId)) {
      return NextResponse.json({ error: 'Invalid job ID' }, { status: 400 });
    }

    const [job] = await db
      .select()
      .from(publishingJobs)
      .where(and(eq(publishingJobs.id, jobId), eq(publishingJobs.teamId, teamId)));

    if (!job) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: job });
      });
  } catch (error: any) {
    console.error('Error fetching publishing job:', error);
    return NextResponse.json({ error: 'Failed to fetch job' }, { status: error?.statusCode || 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    return await withAuthenticatedTeamContext(request, async (auth) => {
      const { teamId } = auth;
    const { id } = await params;
    const jobId = parseInt(id);

    if (isNaN(jobId)) {
      return NextResponse.json({ error: 'Invalid job ID' }, { status: 400 });
    }

    const [job] = await db
      .select()
      .from(publishingJobs)
      .where(and(eq(publishingJobs.id, jobId), eq(publishingJobs.teamId, teamId)));

    if (!job) {
      return NextResponse.json({ error: 'Job not found' }, { status: 404 });
    }

    if (!['pending', 'failed'].includes(job.status) || job.lastAttemptAt) {
      return NextResponse.json(
        { error: 'Dispatched jobs must be retained for delivery reconciliation and audit' },
        { status: 409 }
      );
    }

    const removed = await db
      .delete(publishingJobs)
      .where(and(
        eq(publishingJobs.id, jobId), eq(publishingJobs.teamId, teamId),
        inArray(publishingJobs.status, ['pending', 'failed']),
        isNull(publishingJobs.lastAttemptAt),
      )).returning({ id: publishingJobs.id });
    if (!removed.length) return NextResponse.json({ error: 'Job was dispatched concurrently and cannot be deleted' }, { status: 409 });

    return NextResponse.json({ success: true, message: 'Job deleted' });
      });
  } catch (error: any) {
    console.error('Error deleting publishing job:', error);
    return NextResponse.json({ error: 'Failed to delete job' }, { status: error?.statusCode || 500 });
  }
}
