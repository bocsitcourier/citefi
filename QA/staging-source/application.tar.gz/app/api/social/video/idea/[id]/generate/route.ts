import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { videoIdeas } from "@/shared/schema";
import { eq, and, isNull } from "drizzle-orm";
import { withAuthenticatedTeamContext } from "@/lib/api/auth";
import { addVideoIdeaJob } from "@/lib/queue";
import { checkTeamPaywall, paywallErrorBody } from "@/lib/billing/paywall";
import { reserveCredits, releaseReservation } from "@/lib/billing";
import { checkUsageCap, cancelCapReservation } from "@/lib/usage-caps";
import { isMediaEnabled, isStorageConfigured } from "@/lib/storage";
import { randomUUID } from "crypto";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isMediaEnabled) {
    return NextResponse.json(
      { error: "Media generation disabled", code: "FEATURE_DISABLED" },
      { status: 503 },
    );
  }
  // ── Storage preflight ──────────────────────────────────────────────────────
  if (!isStorageConfigured) {
    return NextResponse.json(
      {
        error: "Video storage not configured",
        message:
          "DigitalOcean Spaces is not set up. Add DO_SPACES_KEY, DO_SPACES_SECRET, " +
          "DO_SPACES_ENDPOINT, and DO_SPACES_BUCKET to your environment variables.",
        code: "STORAGE_NOT_CONFIGURED",
      },
      { status: 503 }
    );
  }

  let teamId: number | undefined;
  let ideaIdForCleanup: number | undefined;
  let creditRunId: string | undefined;
  let capReservationId: number | null = null;
  let queueAccepted = false;

  try {
    return await withAuthenticatedTeamContext(request, async (auth) => {
    try {
    teamId = auth.teamId;
    const userId = auth.userId;

    const { id } = await params;
    const ideaId = parseInt(id, 10);
    ideaIdForCleanup = ideaId;
    if (isNaN(ideaId)) {
      return NextResponse.json({ error: "Invalid idea ID" }, { status: 400 });
    }

    const [idea] = await db.select()
      .from(videoIdeas)
      .where(and(
        eq(videoIdeas.id, ideaId),
        eq(videoIdeas.teamId, teamId),
        isNull(videoIdeas.deletedAt)
      ))
      .limit(1);

    if (!idea) {
      return NextResponse.json({ error: "Video idea not found" }, { status: 404 });
    }

    if (!idea.companyName) {
      return NextResponse.json(
        { error: "Company name is required for video generation" },
        { status: 400 }
      );
    }

    const activeStatuses = ["EXPANDING", "SCRIPTING", "GENERATING", "STITCHING"];
    if (activeStatuses.includes(idea.status)) {
      return NextResponse.json({
        success: true,
        message: "Video generation already in progress",
        alreadyQueued: true,
        ideaId: idea.id,
        currentStage: idea.currentStage,
        currentProgress: idea.progress,
      });
    }

    const paywallResult = await checkTeamPaywall(teamId);
    if (!paywallResult.allowed) {
      return NextResponse.json(paywallErrorBody(paywallResult), { status: 402 });
    }

    try {
      capReservationId = await checkUsageCap(teamId, 15); // video idea ≈ 15 credits / 15¢
    } catch (capErr: any) {
      if (capErr.code !== "SPENDING_CAP_EXCEEDED") throw capErr;
      return NextResponse.json(
        { error: capErr.message, code: "SPENDING_CAP_EXCEEDED", spendingCapGate: true },
        { status: 402 }
      );
    }

    creditRunId = randomUUID();
    const reservation = await reserveCredits({
      teamId,
      userId,
      operationType: "video",
      runId: creditRunId,
    });

    if (!reservation.ok) {
      if (capReservationId !== null) cancelCapReservation(capReservationId).catch(() => {});
      creditRunId = undefined;
      return NextResponse.json(
        {
          error: "CREDITS_EXHAUSTED",
          creditBalance: reservation.totalRemaining,
          allowanceRemaining: reservation.allowanceRemaining,
          purchasedRemaining: reservation.purchasedRemaining,
          totalRemaining: reservation.totalRemaining,
          sufficient: false,
          requiredCredits: reservation.requiredCredits,
          upgradeUrl: "/settings/billing",
          message: `Video generation requires ${reservation.requiredCredits} credits. You have ${reservation.totalRemaining} remaining.`,
        },
        { status: 402 }
      );
    }

    console.log(`🎬 Queueing video idea generation for ID ${ideaId}: "${idea.ideaTitle}" (creditRunId: ${creditRunId})`);

    await db.update(videoIdeas)
      .set({
        status: "EXPANDING",
        progress: 0,
        currentStage: "queued",
        errorMessage: null,
        videoCreditRunId: creditRunId,
        videoCapReservationId: capReservationId,
        videoBillingSettledAt: null,
        updatedAt: new Date(),
      })
      .where(eq(videoIdeas.id, ideaId));

    const jobId = await addVideoIdeaJob({
      videoIdeaId: ideaId,
      teamId,
      userId,
      creditRunId,
      capReservationId,
    });
    queueAccepted = Boolean(jobId);

    if (!jobId) {
      console.error(`❌ Failed to queue video idea generation job`);
      if (capReservationId !== null) cancelCapReservation(capReservationId).catch(() => {});
      await releaseReservation({ teamId, runId: creditRunId, reason: "Queue send failed" })
        .catch((e) => console.warn("[billing] releaseReservation on queue failure:", e));
      creditRunId = undefined;

      await db.update(videoIdeas)
        .set({
          status: "FAILED",
          progress: 0,
          errorMessage: "Failed to queue job - please try again",
          videoCreditRunId: null,
          videoCapReservationId: null,
          videoBillingSettledAt: null,
        })
        .where(eq(videoIdeas.id, ideaId));

      return NextResponse.json(
        { error: "Failed to queue video generation job" },
        { status: 500 }
      );
    }

    await db.update(videoIdeas)
      .set({ jobId })
      .where(eq(videoIdeas.id, ideaId));

    creditRunId = undefined;
    console.log(`✅ Video idea generation job queued: ${jobId}`);

    return NextResponse.json({
      success: true,
      jobId,
      ideaId: idea.id,
      message: "Video generation started. This will take 60-80 minutes for premium AI video.",
      estimatedTime: "60-80 minutes",
    });
    } catch (error) {
      // Once BullMQ accepted the job, preserve its durable billing identities
      // for the worker/recovery path; never refund a possibly-running job here.
      if (!queueAccepted && capReservationId !== null) {
        cancelCapReservation(capReservationId).catch(() => {});
      }
      if (!queueAccepted && creditRunId && teamId) {
        await releaseReservation({ teamId, runId: creditRunId, reason: "Unexpected error in idea-to-video route" })
          .catch((e) => console.warn("[billing] emergency releaseReservation:", e));
      }
      if (!queueAccepted && ideaIdForCleanup !== undefined) {
        await db.update(videoIdeas)
          .set({
            videoCreditRunId: null,
            videoCapReservationId: null,
            videoBillingSettledAt: null,
          })
          .where(eq(videoIdeas.id, ideaIdForCleanup))
          .catch(() => {});
      }
      throw error;
    }
    });
  } catch (error: any) {
    console.error("Error starting video idea generation:", error);
    return NextResponse.json(
      { error: "Failed to start video generation" },
      { status: error?.statusCode || 500 }
    );
  }
}
