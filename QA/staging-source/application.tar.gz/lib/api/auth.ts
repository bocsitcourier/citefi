import { NextRequest } from "next/server";
import { systemDb as db } from "@/lib/db";
import { users, sessions, teamMembers, teams } from "@/shared/schema";
import { verifyToken as verifyJWT, hashToken } from "@/lib/auth";
import { eq, and, isNull, gt, ne } from "drizzle-orm";
import {
  runWithTenantContext,
  runWithSystemContext,
} from "@/lib/tenant-context";
import { requireCookieCsrf } from "@/lib/csrf";
import { runWithProviderHttpInvocation } from "@/lib/provider-http-invocation";

/** Five-minute throttle for lastActivityAt writes — one DB write per session per 5 min. */
const ACTIVITY_THROTTLE_MS = 5 * 60 * 1000;

/**
 * In-memory set of session IDs whose lastActivityAt write recently failed.
 * Suppresses repeated log noise: only one error is emitted per session per throttle window.
 */
const recentActivityFailures = new Set<number>();

export interface AuthenticatedUser {
  id: number;
  email: string;
  role: "admin" | "team_member";
  accountStatus: string;
  teamId: number | null; // Multi-tenant team context
}

export interface VerifiedSession {
  userId: number;
  email: string;
  role: string;
  sessionId: number;
  teamContextId: number | null;
  authAssurance: string;
  mfaVerifiedAt: Date | null;
}

export const AUTH_COOKIE_NAME = "auth_token";

type TeamAuthResult = { userId: number; teamId: number; role: string };

export function runWithAuthenticatedTeamContext<T>(
  auth: TeamAuthResult,
  fn: () => T,
): T {
  return runWithTenantContext({
    actorType: "web",
    userId: auth.userId,
    teamId: auth.teamId,
    role: auth.role,
  }, fn);
}

/** Call only with the user ID returned by requireAdmin. */
export function runWithAuthenticatedAdminContext<T>(
  adminUserId: number,
  fn: () => T,
): T {
  if (!Number.isInteger(adminUserId) || adminUserId <= 0) {
    throw new Error("Admin database context requires a positive userId");
  }
  return runWithSystemContext(
    `platform admin request by user ${adminUserId}`,
    fn,
  );
}

export async function withAuthenticatedTeamContext<T>(
  req: NextRequest,
  fn: (auth: TeamAuthResult) => T,
): Promise<Awaited<T>> {
  const auth = await requireTeamMember(req);
  return await runWithProviderHttpInvocation(req, auth, () =>
    runWithAuthenticatedTeamContext(auth, () => fn(auth)));
}

export async function withAuthenticatedTeamAdminContext<T>(
  req: NextRequest,
  fn: (auth: TeamAuthResult) => T,
): Promise<Awaited<T>> {
  const auth = await requireTeamAdmin(req);
  return await runWithProviderHttpInvocation(req, auth, () =>
    runWithAuthenticatedTeamContext(auth, () => fn(auth)));
}

export async function withAuthenticatedClientReviewerContext<T>(
  req: NextRequest,
  fn: (auth: TeamAuthResult) => T,
): Promise<Awaited<T>> {
  const auth = await requireClientReviewer(req);
  return await runWithProviderHttpInvocation(req, auth, () =>
    runWithAuthenticatedTeamContext(auth, () => fn(auth)));
}

function activateTenantContext(result: TeamAuthResult): TeamAuthResult {
  // Authorization guards return claims only. Database authority is established
  // by the bounded withAuthenticated* callbacks above, never as an ambient
  // side effect of an awaited guard.
  return result;
}

async function resolveDirectTeamMembership(
  userId: number,
  defaultTeamId: number | null,
  allowedRoles?: readonly string[]
): Promise<{ teamId: number; role: string } | null> {
  const query = db
    .select({ teamId: teamMembers.teamId, role: teamMembers.role })
    .from(teamMembers)
    .innerJoin(
      teams,
      and(
        eq(teams.id, teamMembers.teamId),
        isNull(teams.deletedAt),
        eq(teams.clientStatus, "active")
      )
    )
    .where(
      defaultTeamId
        ? and(eq(teamMembers.userId, userId), eq(teamMembers.teamId, defaultTeamId))
        : eq(teamMembers.userId, userId)
    )
    .limit(defaultTeamId ? 1 : 2);

  const memberships = await query;
  const filtered = allowedRoles
    ? memberships.filter((membership) => allowedRoles.includes(membership.role))
    : memberships;

  if (defaultTeamId && filtered.length === 0) {
    const error: any = new Error("Access denied: default team context is no longer authorized");
    error.statusCode = 403;
    throw error;
  }
  if (!defaultTeamId && filtered.length > 1) {
    const error: any = new Error("Multiple teams are available; select an active team before continuing");
    error.statusCode = 409;
    throw error;
  }
  return filtered[0] ?? null;
}

/**
 * Extract the auth token from a request, preferring a valid Authorization
 * Bearer header but falling back to the HttpOnly `auth_token` cookie.
 * Bogus header values ("null"/"undefined"/empty) are ignored so legacy
 * client code that sends `Bearer null` still authenticates via the cookie.
 * Works for both NextRequest and the standard Request (reads the cookie header).
 */
export function getTokenFromRequest(req: Request): string | null {
  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    const t = authHeader.slice(7).trim();
    if (t && t !== "null" && t !== "undefined") return t;
  }

  const cookieHeader = req.headers.get("cookie");
  if (cookieHeader) {
    for (const part of cookieHeader.split(";")) {
      const idx = part.indexOf("=");
      if (idx === -1) continue;
      const key = part.slice(0, idx).trim();
      if (key === AUTH_COOKIE_NAME) {
        return decodeURIComponent(part.slice(idx + 1).trim());
      }
    }
  }

  return null;
}

/**
 * Verify JWT token and return authenticated user
 * Throws error if token is invalid or user not found
 */
export async function getAuthenticatedUser(req: NextRequest): Promise<AuthenticatedUser> {
  // Get token from Authorization header or HttpOnly cookie
  const token = getTokenFromRequest(req);

  if (!token) {
    throw new Error("No authentication token provided");
  }
  const bearer = req.headers.get("authorization")?.slice(7).trim();
  if (!bearer || bearer !== token) requireCookieCsrf(req);

  // Verify JWT
  const payload = verifyJWT(token);
  if (!payload) {
    throw new Error("Invalid or expired token");
  }

  // Load user from database
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.id, payload.userId))
    .limit(1);

  if (!user) {
    throw new Error("User not found");
  }

  // Check if account is active
  if (user.accountStatus !== "active") {
    throw new Error("Account is not active");
  }

  const teamMembership = await resolveDirectTeamMembership(
    user.id,
    user.defaultTeamId
  );
  if (teamMembership) {
    activateTenantContext({
      userId: user.id,
      teamId: teamMembership.teamId,
      role: teamMembership.role,
    });
  }

  return {
    id: user.id,
    email: user.email,
    role: user.role as "admin" | "team_member",
    accountStatus: user.accountStatus,
    teamId: teamMembership?.teamId ?? null,
  };
}

/**
 * Verify that a user ID has admin privileges
 * Throws error if user not found or not an admin
 */
export async function requireAdminById(userId: number): Promise<void> {
  const [user] = await db
    .select({ role: users.role, accountStatus: users.accountStatus })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (!user) {
    const error: any = new Error("User not found");
    error.statusCode = 404;
    throw error;
  }

  if (user.accountStatus !== "active") {
    const error: any = new Error("Account is not active");
    error.statusCode = 401;
    throw error;
  }

  if (user.role !== "admin") {
    const error: any = new Error("Admin access required");
    error.statusCode = 403;
    throw error;
  }
}

/**
 * Verify that the request is from an authenticated admin user
 * Returns the admin user's ID
 * Throws error with appropriate HTTP status if authentication fails
 */
export async function requireAdmin(req: NextRequest): Promise<number> {
  const authResult = await verifyTokenFromRequestImpl(req);

  if (!authResult) {
    const error: any = new Error("Authentication required");
    error.statusCode = 401;
    throw error;
  }

  // Re-fetch role and accountStatus from DB — JWT role may be stale if the user
  // was demoted or suspended after their last login.
  const [user] = await db
    .select({
      role: users.role,
      accountStatus: users.accountStatus,
      twoFactorEnabled: users.twoFactorEnabled,
      twoFactorMethod: users.twoFactorMethod,
      mfaEnrollmentDeadline: users.mfaEnrollmentDeadline,
    })
    .from(users)
    .where(eq(users.id, authResult.userId))
    .limit(1);

  if (!user || user.accountStatus !== "active") {
    const error: any = new Error("Account is not active");
    error.statusCode = 401;
    throw error;
  }

  if (user.role !== "admin") {
    const error: any = new Error("Admin access required");
    error.statusCode = 403;
    throw error;
  }
  if (
    user.twoFactorEnabled === 1 &&
    (user.twoFactorMethod !== "totp" || authResult.authAssurance !== "mfa")
  ) {
    const error: any = new Error("Administrator MFA verification required");
    error.statusCode = 403;
    error.code = "ADMIN_MFA_REQUIRED";
    throw error;
  }
  if (
    user.twoFactorEnabled !== 1 &&
    (
      !user.mfaEnrollmentDeadline ||
      user.mfaEnrollmentDeadline.getTime() <= Date.now()
    )
  ) {
    const error: any = new Error("Administrator MFA enrollment required");
    error.statusCode = 403;
    error.code = "ADMIN_MFA_ENROLLMENT_REQUIRED";
    throw error;
  }

  return authResult.userId;
}

export async function requireRecentAdminMfa(
  req: NextRequest,
  maxAgeMs: number = 15 * 60 * 1000,
): Promise<number> {
  const userId = await requireAdmin(req);
  const authResult = await verifyTokenFromRequestImpl(req);
  if (
    !authResult ||
    authResult.userId !== userId ||
    authResult.authAssurance !== "mfa" ||
    !authResult.mfaVerifiedAt ||
    Date.now() - authResult.mfaVerifiedAt.getTime() > maxAgeMs
  ) {
    const error: any = new Error("Recent administrator MFA verification required");
    error.statusCode = 403;
    error.code = "RECENT_ADMIN_MFA_REQUIRED";
    throw error;
  }
  return userId;
}

/**
 * Verify JWT token from request and check session validity
 * Returns null if token is invalid or session is terminated
 * Exported as both verifyTokenFromRequest and as an alias verifyToken for backwards compatibility
 */
async function verifyTokenFromRequestImpl(req: NextRequest): Promise<VerifiedSession | null> {
  return runWithSystemContext(
    "authenticated session bootstrap",
    () => verifyTokenInSystemScope(req),
  );
}

async function verifyTokenInSystemScope(req: NextRequest): Promise<VerifiedSession | null> {
  // Session and identity lookup is a deliberate pre-tenant bootstrap phase.
  // Callback scoping prevents rejected authentication attempts from leaving
  // ambient system authority in the caller's async continuation.

  // Build ordered candidate list: Bearer header first, then HttpOnly cookie.
  // If Bearer holds a stale/revoked token (e.g. localStorage legacy token), we
  // transparently fall through to the cookie so users aren't force-logged-out.
  const candidates: string[] = [];

  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    const t = authHeader.slice(7).trim();
    if (t && t !== "null" && t !== "undefined") candidates.push(t);
  }

  const cookieHeader = req.headers.get("cookie");
  if (cookieHeader) {
    for (const part of cookieHeader.split(";")) {
      const idx = part.indexOf("=");
      if (idx === -1) continue;
      if (part.slice(0, idx).trim() === AUTH_COOKIE_NAME) {
        const val = decodeURIComponent(part.slice(idx + 1).trim());
        if (val && !candidates.includes(val)) candidates.push(val);
        break;
      }
    }
  }

  for (const token of candidates) {
    const payload = verifyJWT(token);
    if (!payload) continue; // Invalid/expired JWT — try next candidate

    const tokenHash = hashToken(token);

    const [session] = await db
      .select()
      .from(sessions)
      .where(
        and(
          eq(sessions.tokenHash, tokenHash),
          eq(sessions.userId, payload.userId),
          eq(sessions.isActive, 1),
          isNull(sessions.forceLogoutAt),
          gt(sessions.expiresAt, new Date())
        )
      )
      .limit(1);

    if (!session) continue; // No active session row — try next candidate (cookie fallback)

    // Only browser-cookie credentials need CSRF. A valid bearer credential is
    // not ambient browser authority and remains compatible with API clients.
    const bearer = req.headers.get("authorization")?.slice(7).trim();
    if (!bearer || bearer !== token) requireCookieCsrf(req);

    // Throttled lastActivityAt refresh — one write per session per 5 min.
    const now = new Date();
    const lastActivity = session.lastActivityAt ? new Date(session.lastActivityAt) : null;
    if (!lastActivity || now.getTime() - lastActivity.getTime() > ACTIVITY_THROTTLE_MS) {
      const sid = session.id;
      db.update(sessions)
        .set({ lastActivityAt: now })
        .where(eq(sessions.id, sid))
        .catch((e) => {
          // Log once per session per throttle window to avoid flooding logs during DB degradation.
          if (!recentActivityFailures.has(sid)) {
            recentActivityFailures.add(sid);
            console.error("[auth] lastActivityAt update failed:", e);
            setTimeout(() => recentActivityFailures.delete(sid), ACTIVITY_THROTTLE_MS);
          }
        });
    }

    return {
      userId: payload.userId,
      email: payload.email,
      role: payload.role,
      sessionId: session.id,
      teamContextId: session.teamContextId ?? null,
      authAssurance: session.authAssurance,
      mfaVerifiedAt: session.mfaVerifiedAt,
    };
  }

  return null;
}

export { verifyTokenFromRequestImpl as verifyToken, verifyTokenFromRequestImpl as verifyTokenFromRequest };

/**
 * Verify authentication and return user with team context
 * Returns userId and teamId for multi-tenant content filtering
 * CRITICAL: Throws error if not authenticated or not in a team
 * This prevents NULL teamId from bypassing team isolation
 * Uses session-aware token verification to prevent false token expiry errors
 */
export async function requireTeamMember(req: NextRequest): Promise<{ userId: number; teamId: number; role: string }> {
  const authResult = await verifyTokenFromRequestImpl(req);
  
  if (!authResult) {
    const error: any = new Error("Authentication required");
    error.statusCode = 401;
    throw error;
  }

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.id, authResult.userId))
    .limit(1);

  if (!user) {
    const error: any = new Error("User not found");
    error.statusCode = 404;
    throw error;
  }

  if (user.accountStatus !== "active") {
    const error: any = new Error("Account is not active");
    error.statusCode = 401;
    throw error;
  }

  // If the session has an active team context, validate it strictly —
  // NEVER fall through to a different team if the context is unauthorized.
  if (authResult.teamContextId) {
    // Check 1: direct membership
    const [directMembership] = await db
      .select({ role: teamMembers.role })
      .from(teamMembers)
      .innerJoin(
        teams,
        and(
          eq(teams.id, teamMembers.teamId),
          isNull(teams.deletedAt),
          eq(teams.clientStatus, "active")
        )
      )
      .where(and(eq(teamMembers.userId, user.id), eq(teamMembers.teamId, authResult.teamContextId)))
      .limit(1);

    if (directMembership && ["owner", "admin", "member"].includes(directMembership.role)) {
      return activateTenantContext({
        userId: user.id,
        teamId: authResult.teamContextId,
        role: directMembership.role,
      });
    }

    // Check 2: agency-admin inheritance — user is admin of the client team's parent agency.
    // The inner join on teams ensures the parent agency team is not soft-deleted.
    const [targetTeam] = await db
      .select({ parentTeamId: teams.parentTeamId })
      .from(teams)
      .where(and(
        eq(teams.id, authResult.teamContextId),
        isNull(teams.deletedAt),
        eq(teams.clientStatus, "active")
      ))
      .limit(1);

    if (targetTeam?.parentTeamId) {
      const [agencyMembership] = await db
        .select({ role: teamMembers.role })
        .from(teamMembers)
        .innerJoin(teams, and(eq(teams.id, teamMembers.teamId), isNull(teams.deletedAt)))
        .where(and(eq(teamMembers.userId, user.id), eq(teamMembers.teamId, targetTeam.parentTeamId)))
        .limit(1);

      if (agencyMembership && ["owner", "admin"].includes(agencyMembership.role)) {
        return activateTenantContext({
          userId: user.id,
          teamId: authResult.teamContextId,
          role: "admin",
        });
      }
    }

    // teamContextId is set but the user no longer has access — hard-fail with 403.
    // Do NOT fall through to a different team; the caller explicitly targeted this context.
    const error: any = new Error("Access denied: team context is no longer authorized");
    error.statusCode = 403;
    throw error;
  }

  const teamMembership = await resolveDirectTeamMembership(
    user.id,
    user.defaultTeamId,
    ["owner", "admin", "member"]
  );
  
  if (!teamMembership?.teamId) {
    const error: any = new Error("Access denied: User must be assigned to a team");
    error.statusCode = 403;
    throw error;
  }
  
  return activateTenantContext({
    userId: user.id,
    teamId: teamMembership.teamId,
    role: teamMembership.role,
  });
}

/**
 * Require the authenticated user to be a team admin (role = 'admin' in team_members).
 * Used for high-privilege billing actions: checkout, portal, subscription management.
 */
export async function requireTeamAdmin(req: NextRequest): Promise<TeamAuthResult> {
  const authResult = await verifyTokenFromRequestImpl(req);

  if (!authResult) {
    const error: any = new Error("Authentication required");
    error.statusCode = 401;
    throw error;
  }

  const [user] = await db.select().from(users).where(eq(users.id, authResult.userId)).limit(1);
  if (!user) {
    const error: any = new Error("User not found");
    error.statusCode = 404;
    throw error;
  }

  if (user.accountStatus !== "active") {
    const error: any = new Error("Account is not active");
    error.statusCode = 401;
    throw error;
  }

  // If the session has an active team context, validate strictly — hard-fail if unauthorized.
  if (authResult.teamContextId) {
    // Global admins bypass team-role check for any context
    if (user.role === "admin") {
      return activateTenantContext({
        userId: user.id,
        teamId: authResult.teamContextId,
        role: "platform_admin",
      });
    }

    // Direct membership with admin role
    const [directMembership] = await db
      .select({ role: teamMembers.role })
      .from(teamMembers)
      .innerJoin(
        teams,
        and(
          eq(teams.id, teamMembers.teamId),
          isNull(teams.deletedAt),
          eq(teams.clientStatus, "active")
        )
      )
      .where(and(eq(teamMembers.userId, user.id), eq(teamMembers.teamId, authResult.teamContextId)))
      .limit(1);

    if (directMembership && ["owner", "admin"].includes(directMembership.role)) {
      return activateTenantContext({
        userId: user.id,
        teamId: authResult.teamContextId,
        role: directMembership.role,
      });
    }

    // Agency-admin inheritance: user is admin of the parent agency team.
    // The inner join on teams ensures the parent agency team is not soft-deleted.
    const [targetTeam] = await db
      .select({ parentTeamId: teams.parentTeamId })
      .from(teams)
      .where(and(
        eq(teams.id, authResult.teamContextId),
        isNull(teams.deletedAt),
        eq(teams.clientStatus, "active")
      ))
      .limit(1);

    if (targetTeam?.parentTeamId) {
      const [agencyMembership] = await db
        .select({ role: teamMembers.role })
        .from(teamMembers)
        .innerJoin(teams, and(eq(teams.id, teamMembers.teamId), isNull(teams.deletedAt)))
        .where(and(eq(teamMembers.userId, user.id), eq(teamMembers.teamId, targetTeam.parentTeamId)))
        .limit(1);

      if (agencyMembership && ["owner", "admin"].includes(agencyMembership.role)) {
        return activateTenantContext({
          userId: user.id,
          teamId: authResult.teamContextId,
          role: "admin",
        });
      }
    }

    // teamContextId set but not admin — hard-fail, do not fall through
    const ctxError: any = new Error("Access denied: insufficient privileges for requested team context");
    ctxError.statusCode = 403;
    throw ctxError;
  }

  // Global admins bypass team-role check
  if (user.role === "admin") {
    const teamMembership = await resolveDirectTeamMembership(
      user.id,
      user.defaultTeamId
    );
    if (!teamMembership?.teamId) {
      const error: any = new Error("Access denied: No team membership");
      error.statusCode = 403;
      throw error;
    }
    return activateTenantContext({
      userId: user.id,
      teamId: teamMembership.teamId,
      role: "platform_admin",
    });
  }

  // For regular team members, require role='admin' in team_members
  const teamMembership = await resolveDirectTeamMembership(
    user.id,
    user.defaultTeamId,
    ["owner", "admin"]
  );

  if (!teamMembership?.teamId) {
    const error: any = new Error("Access denied: No team membership");
    error.statusCode = 403;
    throw error;
  }

  if (teamMembership.role !== "admin") {
    const error: any = new Error("Access denied: Only team admins can manage this resource");
    error.statusCode = 403;
    throw error;
  }

  return activateTenantContext({
    userId: user.id,
    teamId: teamMembership.teamId,
    role: teamMembership.role,
  });
}

/**
 * Verify authentication and return user with optional team context
 * Returns userId and teamId (null if user has no team)
 * Useful for routes that should work for users even if not in a team
 * Uses session-aware token verification to prevent false token expiry errors
 */
export async function requireAuth(req: NextRequest): Promise<{
  userId: number;
  sessionId: number;
  teamId: number | null;
  role: string;
  authAssurance: string;
  mfaVerifiedAt: Date | null;
}> {
  // Use session-aware verification instead of direct JWT validation
  const authResult = await verifyTokenFromRequestImpl(req);
  
  if (!authResult) {
    const error: any = new Error("Authentication required");
    error.statusCode = 401;
    throw error;
  }

  // Load user to get team context
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.id, authResult.userId))
    .limit(1);

  if (!user) {
    const error: any = new Error("User not found");
    error.statusCode = 404;
    throw error;
  }

  if (user.accountStatus !== "active") {
    const error: any = new Error("Account is not active");
    error.statusCode = 401;
    throw error;
  }

  const teamMembership = await resolveDirectTeamMembership(
    user.id,
    authResult.teamContextId ?? user.defaultTeamId
  );
  return {
    userId: user.id,
    sessionId: authResult.sessionId,
    teamId: teamMembership?.teamId ?? null,
    role: teamMembership?.role ?? authResult.role,
    authAssurance: authResult.authAssurance,
    mfaVerifiedAt: authResult.mfaVerifiedAt,
  };
}

/**
 * Guard: verifies a content resource belongs to the authenticated team.
 *
 * Throws 404 (not 403) so that IDOR attempts cannot probe resource existence.
 * Use on every content read/write route after `requireTeamMember()`.
 *
 * @example
 *   const { teamId } = await requireTeamMember(req);
 *   requireTeamResource(article.teamId, teamId);
 */
export function requireTeamResource(resourceTeamId: number, authTeamId: number): void {
  if (resourceTeamId !== authTeamId) {
    const error: any = new Error("Resource not found");
    error.statusCode = 404;
    throw error;
  }
}

/**
 * requireClientReviewer — allows admin | member | client_viewer roles.
 * Use on read-only review routes that client viewers should access.
 * Returns userId, teamId, and the member's role.
 *
 * Mirrors requireTeamMember's teamContextId logic so multi-team users
 * always resolve to the session's active team rather than a random row.
 */
export async function requireClientReviewer(req: NextRequest): Promise<{ userId: number; teamId: number; role: string }> {
  const authResult = await verifyTokenFromRequestImpl(req);
  if (!authResult) {
    const error: any = new Error("Authentication required");
    error.statusCode = 401;
    throw error;
  }

  const [user] = await db.select().from(users).where(eq(users.id, authResult.userId)).limit(1);
  if (!user) { const e: any = new Error("User not found"); e.statusCode = 404; throw e; }
  if (user.accountStatus !== "active") { const e: any = new Error("Account is not active"); e.statusCode = 401; throw e; }

  const ALLOWED = ["owner", "admin", "member", "client_viewer"];

  if (authResult.teamContextId) {
    // Validate membership against the session's explicit team context
    const [directMembership] = await db
      .select({ role: teamMembers.role })
      .from(teamMembers)
      .innerJoin(
        teams,
        and(
          eq(teams.id, teamMembers.teamId),
          isNull(teams.deletedAt),
          eq(teams.clientStatus, "active")
        )
      )
      .where(and(eq(teamMembers.userId, user.id), eq(teamMembers.teamId, authResult.teamContextId)))
      .limit(1);

    if (directMembership && ALLOWED.includes(directMembership.role)) {
      return activateTenantContext({
        userId: user.id,
        teamId: authResult.teamContextId,
        role: directMembership.role,
      });
    }

    // Agency-admin inheritance: user is admin of the client team's parent
    const [targetTeam] = await db
      .select({ parentTeamId: teams.parentTeamId })
      .from(teams)
      .where(and(eq(teams.id, authResult.teamContextId), isNull(teams.deletedAt)))
      .limit(1);

    if (targetTeam?.parentTeamId) {
      const [agencyMembership] = await db
        .select({ role: teamMembers.role })
        .from(teamMembers)
        .innerJoin(
          teams,
          and(
            eq(teams.id, teamMembers.teamId),
            isNull(teams.deletedAt),
            eq(teams.clientStatus, "active")
          )
        )
        .where(and(eq(teamMembers.userId, user.id), eq(teamMembers.teamId, targetTeam.parentTeamId)))
        .limit(1);

      if (agencyMembership && ["owner", "admin"].includes(agencyMembership.role)) {
        return activateTenantContext({
          userId: user.id,
          teamId: authResult.teamContextId,
          role: "admin",
        });
      }
    }

    // teamContextId set but no valid membership — hard-fail, never fall through
    const e: any = new Error("Access denied: team context is no longer authorized");
    e.statusCode = 403;
    throw e;
  }

  const membership = await resolveDirectTeamMembership(
    user.id,
    user.defaultTeamId,
    ALLOWED
  );
  if (!membership) { const e: any = new Error("Not a team member"); e.statusCode = 403; throw e; }

  if (!ALLOWED.includes(membership.role)) {
    const e: any = new Error("Access denied");
    e.statusCode = 403;
    throw e;
  }

  return activateTenantContext({
    userId: user.id,
    teamId: membership.teamId,
    role: membership.role,
  });
}

/**
 * requireContentEditor — allows admin | member roles only.
 * Blocks client_viewer. Use on write routes (create, update, delete content).
 */
export async function requireContentEditor(req: NextRequest): Promise<{ userId: number; teamId: number; role: string }> {
  const { userId, teamId, role } = await requireClientReviewer(req);
  if (role === "client_viewer") {
    const e: any = new Error("Client reviewers have read-only access");
    e.statusCode = 403;
    throw e;
  }
  return { userId, teamId, role };
}
