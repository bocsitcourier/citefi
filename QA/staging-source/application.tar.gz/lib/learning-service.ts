import { db } from "./db";
import { eq, and, desc, gte, sql, asc, inArray } from "drizzle-orm";
import {
  learningAgents,
  learningPatterns,
  patternDimensionStats,
  contentPerformanceMetrics,
  agentOptimizationLogs,
  aiLearningLedger,
  variantArms,
  ContentType,
  articles,
  socialPosts,
  videoIdeas,
} from "../shared/schema";
import {
  GEMINI_ARTICLE_MODEL,
  GEMINI_FLASH_MODEL,
  GPT_ENHANCEMENT_MODEL,
  TTS_MODEL,
  VEO_VIDEO_MODEL,
} from "./ai-config";
import { factStore } from "./fact-store";
import { contentReviewService, type Dimension } from "./content-review-service";
import { PATTERN_DIMENSION } from "./pattern-dimension-map";
import { getFactCoverageReport } from "./fact-validated-generators";
import { 
  humanizeContent, 
  analyzeContentQuality, 
  HumanizationConfig,
  HumanizationResult 
} from "./deterministic-humanizer";
import { getClientBrandContext } from "./client-brand-profile-service";

const EMA_ALPHA = 0.1;
const MIN_CONFIDENCE_SAMPLES = 5;

// Wilson lower-bound (95% CI) — same formula as content-review-service
function wilsonLowerBound(successes: number, trials: number, z = 1.96): number {
  if (trials === 0) return 0;
  const p = successes / trials;
  const denom = 1 + (z * z) / trials;
  const center = p + (z * z) / (2 * trials);
  const margin = z * Math.sqrt((p * (1 - p) + (z * z) / (4 * trials)) / trials);
  return Math.max(0, Math.round(((center - margin) / denom) * 100));
}

// ============================================================================
// Thompson Sampling utilities — Task #16 Bayesian Decisioning Engine
// ============================================================================

/** Standard normal sample via Box-Muller. */
function _randn(): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

/** Marsaglia-Tsang Gamma(α, 1) sample. Works for α ≥ 1; recurses for α < 1. */
function _gammaSample(alpha: number): number {
  if (alpha < 1) return _gammaSample(1 + alpha) * Math.random() ** (1 / alpha);
  const d = alpha - 1 / 3;
  const c = 1 / Math.sqrt(9 * d);
  for (;;) {
    let x: number, v: number;
    do { x = _randn(); v = 1 + c * x; } while (v <= 0);
    v = v * v * v;
    const u = Math.random();
    if (u < 1 - 0.0331 * (x * x) * (x * x)) return d * v;
    if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v;
  }
}

/**
 * Thompson sample from Beta(α, β).
 * α = successes + 1, β = (trials − successes) + 1.
 * Returns a probability in [0, 1].
 */
export function thompsonSample(alpha: number, beta: number): number {
  const x = _gammaSample(Math.max(alpha, 1e-9));
  const y = _gammaSample(Math.max(beta, 1e-9));
  if (x + y === 0) return 0.5;
  return x / (x + y);
}

/**
 * djb2 hash — maps any string to a stable 32-bit unsigned integer.
 * Used for deterministic arm assignment: the same stableId always maps to
 * the same arm, preventing contamination across re-runs of the same job.
 */
function djb2(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) {
    h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
  }
  return h;
}

/**
 * Multi-metric weights per content type.
 * Keys: quality, engagement, conversion.
 * Used to multiply the Thompson score by the metric that governs the pattern's dimension.
 */
export const METRIC_WEIGHTS: Record<string, Record<string, number>> = {
  article:     { quality: 0.40, engagement: 0.35, conversion: 0.25 },
  social:      { engagement: 0.50, conversion: 0.35, quality: 0.15 },
  social_post: { engagement: 0.50, conversion: 0.35, quality: 0.15 },
  podcast:     { engagement: 0.55, quality: 0.30, conversion: 0.15 },
  video:       { engagement: 0.60, quality: 0.25, conversion: 0.15 },
  image:       { quality: 0.50, engagement: 0.40, conversion: 0.10 },
};

/** Maps each patternDimensionStats dimension to its metric bucket. */
const DIM_TO_METRIC: Record<string, string> = {
  completeness: "quality",
  factuality:   "quality",
  structure:    "quality",
  humanness:    "engagement",
  engagement:   "engagement",
  eeat_signal:  "quality",
  conversion:   "conversion",
};

export interface LearnedPattern {
  id: number;
  patternType: string;
  patternName: string;
  patternValue: string;
  successRate: number;
  confidence: number;
}

export interface OptimizationContext {
  agentId: number;
  contentType: string;
  patterns: LearnedPattern[];
  promptEnhancements: string[];
  negativeConstraints?: string[];
  humanizationGuidelines?: string[];
  modelConfig: {
    model: string;
    temperature: number;
  };
  /** variantArms.id of the arm selected for this generation (if an experiment is active). */
  selectedArmId?: number;
  /** true when this generation was routed to the holdout arm (baseline patterns served). */
  isHoldout?: boolean;
}

export class LearningService {
  private static instance: LearningService;

  static getInstance(): LearningService {
    if (!LearningService.instance) {
      LearningService.instance = new LearningService();
    }
    return LearningService.instance;
  }

  async initializeDefaultAgents(teamId: number): Promise<void> {
    const agentConfigs = [
      {
        contentType: ContentType.ARTICLE,
        name: "Article Optimization Agent",
        description: "Learns optimal title styles, opening hooks, E-E-A-T signals, and content structures that drive engagement",
        primaryModel: GEMINI_ARTICLE_MODEL,
        fallbackModel: GPT_ENHANCEMENT_MODEL,
      },
      {
        contentType: ContentType.VIDEO,
        name: "Video Script Agent",
        description: "Learns hooks, pacing, visual styles, and CTAs that maximize video engagement",
        primaryModel: GEMINI_FLASH_MODEL,
        fallbackModel: GPT_ENHANCEMENT_MODEL,
      },
      {
        contentType: ContentType.SOCIAL,
        name: "Social Media Agent",
        description: "Learns tone, hashtag strategies, and post structures that drive shares and engagement",
        primaryModel: GEMINI_FLASH_MODEL,
        fallbackModel: GPT_ENHANCEMENT_MODEL,
      },
      {
        contentType: ContentType.PODCAST,
        name: "Podcast Script Agent",
        description: "Learns conversational patterns, pacing, and hooks for engaging audio content",
        primaryModel: GEMINI_FLASH_MODEL,
        fallbackModel: GPT_ENHANCEMENT_MODEL,
      },
      {
        contentType: ContentType.IMAGE,
        name: "Image Generation Agent",
        description: "Learns visual styles, compositions, and prompts that create compelling images",
        primaryModel: GEMINI_FLASH_MODEL,
        fallbackModel: GEMINI_FLASH_MODEL,
      },
    ];

    for (const config of agentConfigs) {
      const existing = await db
        .select()
        .from(learningAgents)
        .where(
          and(
            eq(learningAgents.teamId, teamId),
            eq(learningAgents.contentType, config.contentType)
          )
        )
        .limit(1);

      if (existing.length === 0) {
        await db.insert(learningAgents).values({
          teamId,
          ...config,
        });
        console.log(`✅ Initialized ${config.name} for team ${teamId}`);
      }
    }
  }

  async getAgentForContentType(
    teamId: number,
    contentType: string
  ): Promise<typeof learningAgents.$inferSelect | null> {
    const agents = await db
      .select()
      .from(learningAgents)
      .where(
        and(
          eq(learningAgents.teamId, teamId),
          eq(learningAgents.contentType, contentType),
          eq(learningAgents.isActive, 1)
        )
      )
      .limit(1);

    return agents[0] || null;
  }

  async getOptimizationContext(
    teamId: number,
    contentType: string,
    options?: {
      industry?: string;
      audience?: string;
      patternTypes?: string[];
      priorityDimension?: Dimension;
      terminalKpi?: string;  // 'conversion' | 'engagement' | 'awareness' — overrides metric weights
      stableId?: string;     // stable seed for deterministic holdout/treatment assignment
      campaignId?: number | null;
    }
  ): Promise<OptimizationContext | null> {
    const agent = await this.getAgentForContentType(teamId, contentType);
    if (!agent) {
      console.log(`⚠️ No learning agent found for ${contentType}, initializing...`);
      await this.initializeDefaultAgents(teamId);
      const newAgent = await this.getAgentForContentType(teamId, contentType);
      if (!newAgent) return null;
      return this.buildOptimizationContext(newAgent, options);
    }

    return this.buildOptimizationContext(agent, options);
  }

  private async buildOptimizationContext(
    agent: typeof learningAgents.$inferSelect,
    options?: {
      industry?: string;
      audience?: string;
      patternTypes?: string[];
      priorityDimension?: Dimension;
      terminalKpi?: string;
      stableId?: string;
      campaignId?: number | null;
    }
  ): Promise<OptimizationContext> {
    if (!agent.teamId) {
      throw new Error(`Learning agent ${agent.id} has no owning team`);
    }
    const agentTeamId = agent.teamId;
    // Fetch ALL non-archived patterns for this agent.
    // Archived patterns were underperformers flagged by the weekly archiving job.
    // Defense-in-depth: scope by both agentId AND teamId so a spoofed agentId
    // cannot leak patterns across team boundaries.
    const allPatterns = await db
      .select()
      .from(learningPatterns)
      .where(
        and(
          eq(learningPatterns.agentId, agent.id),
          eq(learningPatterns.teamId, agentTeamId),
          eq(learningPatterns.isArchived, false)
        )
      )
      .limit(100);

    if (allPatterns.length === 0) {
      return {
        agentId: agent.id,
        contentType: agent.contentType,
        patterns: [],
        promptEnhancements: [],
        negativeConstraints: [],
        modelConfig: { model: agent.primaryModel, temperature: agent.temperature / 100 },
      };
    }

    // Fetch per-dimension Wilson scores for all patterns in a single query.
    // Previously only "engagement" was fetched — now each pattern is judged
    // in the dimension it actually governs (eeat_signal → factuality, etc.).
    const patternIds = allPatterns.map(p => p.id);
    const dimStats = patternIds.length > 0
      ? await db.select().from(patternDimensionStats).where(inArray(patternDimensionStats.patternId, patternIds))
      : [];

    const statKey = (pid: number, dim: string) => `${pid}:${dim}`;
    const statMap = new Map<string, typeof patternDimensionStats.$inferSelect>();
    for (const s of dimStats) statMap.set(statKey(s.patternId, s.dimension), s);

    // Data-maturity check → determines prior strength for Thompson Sampling.
    const maturity = await this.teamDataMaturity(agentTeamId, agent.contentType);

    // Pre-fetch active arms BEFORE computing metric weights so terminalKpi can be resolved
    // from the arm's own stored config. This makes KPI-aware weighting universal across ALL
    // content types (article, social, podcast, video) without requiring each generation
    // worker to explicitly thread terminalKpi through to getPromptEnhancement.
    const activeArms = await db
      .select()
      .from(variantArms)
      .where(and(
        eq(variantArms.teamId, agentTeamId),
        eq(variantArms.contentType, agent.contentType),
        eq(variantArms.isActive, true)
      ));
    const treatmentArmConfig = activeArms.find(a => a.armName === "treatment");
    // Resolve terminalKpi with explicit precedence:
    //   1. Caller-provided (per-batch/per-journey override) — highest priority
    //   2. Arm's persisted config (experiment-level default for this content type)
    //   3. undefined → falls back to content-type default weights
    // This ensures a batch with terminalKpi='conversion' always wins over the arm's
    // default, allowing the same content type to use different weights across journeys.
    const resolvedTerminalKpi: string | undefined =
      options?.terminalKpi ?? treatmentArmConfig?.terminalKpi ?? undefined;

    console.log(
      `[DECISIONING_MATURITY] type=${agent.contentType} maturity=${maturity} patterns=${allPatterns.length} terminalKpi=${resolvedTerminalKpi ?? 'default'}`
    );

    // Effective metric weights — content-type defaults, overridden by resolvedTerminalKpi.
    // Resolved from arm config first for consistent KPI weighting across all generation paths.
    const weights = this.effectiveWeights(agent.contentType, resolvedTerminalKpi);

    // Thompson Sampling — replaces epsilon-greedy.
    //   α = successes + 1,  β = (trials − successes) + 1
    // Sparse maturity → Beta(1,1) equal priors for all patterns (pure exploration).
    // Thompson naturally balances explore/exploit — no explicit epsilon needed.
    const scored = allPatterns.map(p => {
      const dim = options?.priorityDimension ?? PATTERN_DIMENSION[p.patternType] ?? "engagement";
      const stat = statMap.get(statKey(p.id, dim));
      const rawSuccesses = maturity === "sparse" ? 0 : (stat?.successes ?? 0);
      const rawTrials    = maturity === "sparse" ? 0 : (stat?.trials    ?? 0);
      const alpha = rawSuccesses + 1;
      const beta  = Math.max(1, rawTrials - rawSuccesses + 1);
      const metricKey = DIM_TO_METRIC[dim] ?? "engagement";
      const dimWeight = (weights[metricKey] ?? weights["engagement"] ?? 0.35);
      // Sparse mode: omit content-type metric weighting — truly neutral equal-weight priors.
      // Multiplying Beta(1,1) Thompson draws by dimWeight introduces systematic content-type
      // bias before sufficient data exists, violating the sparse-mode design contract.
      const thompsonScore = maturity === "sparse"
        ? thompsonSample(alpha, beta)
        : thompsonSample(alpha, beta) * dimWeight;
      return {
        pattern: p,
        dim,
        wilson: stat?.wilsonScore ?? 0,
        trials: rawTrials,
        thompsonScore,
      };
    });

    // Sort by weighted Thompson score desc.
    const sortedScored = scored.sort((a, b) => b.thompsonScore - a.thompsonScore);

    // Gate external unvalidated patterns to at most 1 exploration slot.
    // External patterns seeded via competitive intelligence have
    // validatedByOwnAudience=false and source='external'.  They must not fill
    // the full exploitation pool before the team has observed their own
    // performance — cap them to 1 slot in the top 8.
    const EXTERNAL_EXPLORATION_CAP = 1;
    let externalSlotsUsed = 0;
    const selected = sortedScored.filter((s) => {
      const isUnvalidatedExternal =
        (s.pattern as any).source === "external" &&
        (s.pattern as any).validatedByOwnAudience === false;
      if (isUnvalidatedExternal) {
        if (externalSlotsUsed >= EXTERNAL_EXPLORATION_CAP) return false;
        externalSlotsUsed++;
      }
      return true;
    }).slice(0, 8);

    let learnedPatterns: LearnedPattern[] = selected.map(s => ({
      id: s.pattern.id,
      patternType: s.pattern.patternType,
      patternName: s.pattern.patternName,
      patternValue: s.pattern.patternValue,
      successRate: s.wilson,
      confidence: Math.min(100, Math.round((s.trials / MIN_CONFIDENCE_SAMPLES) * 100)),
    }));

    // ── Variant Arm Assignment (Task #16 holdout/treatment routing) ─────────────
    // If an active experiment exists for this team × contentType, route each
    // generation to treatment (Thompson-sampled patterns, computed above) or
    // holdout (committed baseline patterns). Callers tag
    // contentPerformanceMetrics.variantId = `va-${selectedArmId}` to enable
    // treatment-vs-holdout lift analysis at declare-winner gate time.
    let selectedArmId: number | undefined;
    let isHoldout = false;
    try {
      // activeArms already fetched above for KPI resolution — reuse to avoid duplicate query.
      const treatmentArm = activeArms.find(a => a.armName === "treatment");
      const holdoutArm   = activeArms.find(a => a.armName === "holdout");

      if (treatmentArm || holdoutArm) {
        const holdoutPct = holdoutArm?.allocationPct ?? 10;
        // Deterministic: same stableId → same arm every run, preventing
        // contamination when the same job is retried or re-evaluated.
        // Falls back to random only when no stableId is available (e.g. tests).
        const roll = options?.stableId
          ? djb2(options.stableId) % 100
          : Math.floor(Math.random() * 100);
        if (holdoutArm && roll < holdoutPct) {
          // Holdout arm: serve committed baseline patterns only
          isHoldout = true;
          selectedArmId = holdoutArm.id;
          const bids: number[] = holdoutArm.baselinePatternIds ?? [];
          if (bids.length > 0) {
            const holdoutSubset = allPatterns
              .filter(p => bids.includes(p.id))
              .slice(0, 8);
            learnedPatterns = holdoutSubset.map(p => ({
              id: p.id,
              patternType: p.patternType,
              patternName: p.patternName,
              patternValue: p.patternValue,
              successRate: 0,
              confidence: 0,
            }));
          } else {
            // No committed baseline — derive deterministically from top Wilson-scored patterns.
            // Pure Wilson ranking: zero Thompson randomness, zero exploration in holdout arm,
            // preventing any treatment signal from contaminating the holdout control group.
            const topWilson = scored
              .slice()
              .sort((a, b) => b.wilson - a.wilson)
              .slice(0, 8);
            learnedPatterns = topWilson.map(s => ({
              id: s.pattern.id,
              patternType: s.pattern.patternType,
              patternName: s.pattern.patternName,
              patternValue: s.pattern.patternValue,
              successRate: s.wilson,
              confidence: 0,
            }));
          }
        } else if (treatmentArm) {
          // Treatment arm: Thompson-sampled patterns already computed above
          selectedArmId = treatmentArm.id;
        }
      }
    } catch {
      // Arm assignment is best-effort; fall back to Thompson selection silently
    }

    // Collect negative constraints + brand intelligence context in parallel
    const [negativeConstraints, brandContext] = await Promise.all([
      this.collectNegativeConstraints(agent.teamId!, agent.contentType),
      getClientBrandContext(agent.teamId!, options?.campaignId ?? null),
    ]);

    const promptEnhancements = this.buildPromptEnhancements(learnedPatterns);
    // Prepend brand intelligence as the first enhancement so it takes
    // precedence over pattern-based enhancements in the prompt.
    const allEnhancements = brandContext
      ? [brandContext, ...promptEnhancements]
      : promptEnhancements;

    return {
      agentId: agent.id,
      contentType: agent.contentType,
      patterns: learnedPatterns,
      promptEnhancements: allEnhancements,
      negativeConstraints,
      modelConfig: {
        model: agent.primaryModel,
        temperature: agent.temperature / 100,
      },
      selectedArmId,
      isHoldout,
    };
  }

  // ============================================================================
  // Task #16: Thompson Sampling support methods
  // ============================================================================

  /**
   * Determine data maturity for a team × content-type combination.
   * Drives Thompson prior strength: sparse → Beta(1,1), learning/mature → real counts.
   */
  async teamDataMaturity(
    teamId: number,
    contentType: string
  ): Promise<"sparse" | "learning" | "mature"> {
    try {
      const [result] = await db
        .select({ total: sql<number>`coalesce(sum(${patternDimensionStats.trials}), 0)` })
        .from(patternDimensionStats)
        .innerJoin(learningPatterns, eq(learningPatterns.id, patternDimensionStats.patternId))
        .where(
          and(
            eq(learningPatterns.teamId, teamId),
            eq(learningPatterns.contentType, contentType),
            eq(learningPatterns.isArchived, false)
          )
        );
      const total = Number(result?.total ?? 0);
      if (total < 20) return "sparse";
      if (total < 100) return "learning";
      return "mature";
    } catch {
      return "sparse";
    }
  }

  /**
   * Compute effective metric weights for a given content type.
   * If terminalKpi is provided, the corresponding metric is boosted to 0.7
   * and the remaining weight is distributed proportionally.
   */
  private effectiveWeights(
    contentType: string,
    terminalKpi?: string
  ): Record<string, number> {
    const base = METRIC_WEIGHTS[contentType] ?? METRIC_WEIGHTS["article"]!;
    if (!terminalKpi) return base;

    const kpiMetric =
      terminalKpi === "conversion" ? "conversion"
      : terminalKpi === "engagement" ? "engagement"
      : terminalKpi === "awareness"  ? "quality"   // awareness is a brand KPI → quality
      : "quality";

    // awareness → boost quality to 0.6 (brand/E-E-A-T KPI)
    // conversion/engagement → boost to 0.7 (performance KPI)
    const boostedWeight = terminalKpi === "awareness" ? 0.6 : 0.7;
    const remainder = 1 - boostedWeight;
    const otherKeys = Object.keys(base).filter(k => k !== kpiMetric);
    const otherTotal = otherKeys.reduce((s, k) => s + (base[k] ?? 0), 0);
    const result: Record<string, number> = { ...base, [kpiMetric]: boostedWeight };
    for (const k of otherKeys) {
      result[k] = otherTotal > 0
        ? ((base[k] ?? 0) / otherTotal) * remainder
        : remainder / otherKeys.length;
    }
    return result;
  }

  private async collectNegativeConstraints(teamId: number, contentType: string): Promise<string[]> {
    try {
      // Mine top recurring defects from the content review ledger, not the error ledger.
      // This gives richer, dimension-aware negative constraints based on actual AI judge output.
      const negatives = await contentReviewService.getNegativeConstraints(teamId, contentType, 5);
      return negatives.map(n => `[AVOID] ${n}`);
    } catch {
      return [];
    }
  }

  private buildPromptEnhancements(patterns: LearnedPattern[]): string[] {
    const enhancements: string[] = [];
    const patternsByType = patterns.reduce((acc, p) => {
      if (!acc[p.patternType]) acc[p.patternType] = [];
      acc[p.patternType]!.push(p);
      return acc;
    }, {} as Record<string, LearnedPattern[]>);

    for (const [type, typePatterns] of Object.entries(patternsByType)) {
      if (typePatterns.length > 0) {
        const topPattern = typePatterns[0]!;
        const isProven = topPattern.confidence >= 50;
        enhancements.push(
          isProven
            ? `[LEARNED - ${type.toUpperCase()}] ${topPattern.patternValue} (${topPattern.successRate}% success)`
            : `[EXPLORING - ${type.toUpperCase()}] Try: ${topPattern.patternValue}`
        );
      }
    }
    return enhancements;
  }

  async recordContentGeneration(
    teamId: number,
    agentId: number,
    contentType: string,
    contentId: number,
    patternsUsed: number[],
    qualityScore: number,
    opts?: { variantId?: string; armId?: number; variantArmId?: number }
  ): Promise<number> {
    // Task #151 — carry the canonical owning campaign onto the performance metric
    // when the content root has one. Derived from the team-scoped root row only
    // (never guessed); null for legacy / standalone content.
    let resolvedCampaignId: number | null = null;
    if (contentType === ContentType.ARTICLE || contentType === ContentType.PODCAST) {
      const [row] = await db
        .select({ campaignId: articles.campaignId })
        .from(articles)
        .where(and(eq(articles.id, contentId), eq(articles.teamId, teamId)))
        .limit(1);
      resolvedCampaignId = row?.campaignId ?? null;
    } else if (contentType === ContentType.SOCIAL) {
      const [row] = await db
        .select({ campaignId: socialPosts.campaignId })
        .from(socialPosts)
        .where(and(eq(socialPosts.id, contentId), eq(socialPosts.teamId, teamId)))
        .limit(1);
      resolvedCampaignId = row?.campaignId ?? null;
    } else if (contentType === ContentType.VIDEO) {
      const [row] = await db
        .select({ campaignId: videoIdeas.campaignId })
        .from(videoIdeas)
        .where(and(eq(videoIdeas.id, contentId), eq(videoIdeas.teamId, teamId)))
        .limit(1);
      resolvedCampaignId = row?.campaignId ?? null;
    }

    const [metricRow] = await db
      .insert(contentPerformanceMetrics)
      .values({
        teamId,
        campaignId: resolvedCampaignId,
        contentType,
        articleId: (contentType === ContentType.ARTICLE || contentType === ContentType.PODCAST) ? contentId : null,
        socialPostId: contentType === ContentType.SOCIAL ? contentId : null,
        videoIdeaId: contentType === ContentType.VIDEO ? contentId : null,
        patternsUsedJson: patternsUsed,
        qualityScore,
        ...(opts?.variantId    !== undefined ? { variantId:    opts.variantId    } : {}),
        ...(opts?.armId        !== undefined ? { armId:        opts.armId        } : {}),
        ...(opts?.variantArmId !== undefined ? { variantArmId: opts.variantArmId } : {}),
      })
      .returning({ id: contentPerformanceMetrics.id });
    const metric = metricRow!;

    await db
      .update(learningAgents)
      .set({
        totalGenerations: sql`${learningAgents.totalGenerations} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(learningAgents.id, agentId));

    return metric.id;
  }

  async recordEngagement(
    teamId: number,
    metricId: number,
    engagement: {
      views?: number;
      clicks?: number;
      shares?: number;
      likes?: number;
      comments?: number;
      timeOnPage?: number;
      bounceRate?: number;
    }
  ): Promise<void> {
    await db
      .update(contentPerformanceMetrics)
      .set({
        ...engagement,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(contentPerformanceMetrics.id, metricId),
          eq(contentPerformanceMetrics.teamId, teamId)
        )
      );
  }

  async markContentSuccess(
    teamId: number,
    metricId: number,
    isSuccess: boolean,
    reason?: string
  ): Promise<void> {
    const updated = await db
      .update(contentPerformanceMetrics)
      .set({
        isSuccess: isSuccess ? 1 : 0,
        successReason: reason,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(contentPerformanceMetrics.id, metricId),
          eq(contentPerformanceMetrics.teamId, teamId)
        )
      )
      .returning({ id: contentPerformanceMetrics.id });

    if (updated.length > 0) {
      await this.processLearningFeedback(metricId);
    }
  }

  async processLearningFeedback(metricId: number): Promise<void> {
    const [metric] = await db
      .select()
      .from(contentPerformanceMetrics)
      .where(eq(contentPerformanceMetrics.id, metricId))
      .limit(1);

    if (!metric || metric.feedbackProcessed === 1) return;
    if (metric.isSuccess === null) return;

    const patternsUsed = (metric.patternsUsedJson as number[]) || [];
    const isSuccess = metric.isSuccess === 1;

    const metricTeamId = metric.teamId;
    if (!metricTeamId) return; // Cannot safely scope EMA update without a team boundary

    for (const patternId of patternsUsed) {
      await this.updatePatternWithEMA(patternId, isSuccess, metric.qualityScore, metricTeamId);
    }

    await db
      .update(contentPerformanceMetrics)
      .set({
        feedbackProcessed: 1,
        processedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(contentPerformanceMetrics.id, metricId));

    console.log(`📊 Processed learning feedback for metric ${metricId}, patterns: ${patternsUsed.length}`);
  }

  private async updatePatternWithEMA(
    patternId: number,
    isSuccess: boolean,
    qualityScore: number,
    teamId: number
  ): Promise<void> {
    // SECURITY: scope by BOTH id AND teamId so a poisoned/cross-tenant patternId
    // in patternsUsedJson cannot mutate another team's learning patterns.
    const [pattern] = await db
      .select()
      .from(learningPatterns)
      .where(
        and(
          eq(learningPatterns.id, patternId),
          eq(learningPatterns.teamId, teamId)
        )
      )
      .limit(1);

    if (!pattern) return;

    const newSuccessRate = Math.round(
      pattern.successRate * (1 - EMA_ALPHA) + (isSuccess ? 100 : 0) * EMA_ALPHA
    );
    const newQualityScore = Math.round(
      pattern.qualityScore * (1 - EMA_ALPHA) + qualityScore * EMA_ALPHA
    );

    const newTimesUsed = pattern.timesUsed + 1;
    const newTimesSuccessful = pattern.timesSuccessful + (isSuccess ? 1 : 0);

    const newConfidence = Math.min(
      100,
      Math.round((newTimesUsed / MIN_CONFIDENCE_SAMPLES) * 100)
    );

    await db
      .update(learningPatterns)
      .set({
        successRate: newSuccessRate,
        qualityScore: newQualityScore,
        timesUsed: newTimesUsed,
        timesSuccessful: newTimesSuccessful,
        confidence: newConfidence,
        lastUsedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(learningPatterns.id, patternId),
          eq(learningPatterns.teamId, teamId)
        )
      );

    console.log(
      `📈 Updated pattern ${patternId}: success=${newSuccessRate}%, quality=${newQualityScore}, confidence=${newConfidence}%`
    );
  }

  async addPattern(
    agentId: number,
    teamId: number,
    pattern: {
      patternType: string;
      patternName: string;
      patternValue: string;
      industry?: string;
      audience?: string;
    }
  ): Promise<number> {
    const [agent] = await db
      .select()
      .from(learningAgents)
      .where(eq(learningAgents.id, agentId))
      .limit(1);

    if (!agent) throw new Error(`Agent ${agentId} not found`);
    if (agent.teamId !== teamId) throw new Error(`Agent ${agentId} does not belong to team ${teamId}`);

    const [newPatternRow] = await db
      .insert(learningPatterns)
      .values({
        agentId,
        teamId,
        contentType: agent.contentType,
        ...pattern,
        successRate: 50,
        engagementScore: 50,
        qualityScore: 50,
        confidence: 0,
      })
      .returning({ id: learningPatterns.id });
    const newPattern = newPatternRow!;

    console.log(`✅ Added new pattern: ${pattern.patternName} (${pattern.patternType})`);

    return newPattern.id;
  }

  async getTopPatterns(
    teamId: number,
    contentType: string,
    limit: number = 10
  ): Promise<LearnedPattern[]> {
    const patterns = await db
      .select()
      .from(learningPatterns)
      .where(
        and(
          eq(learningPatterns.teamId, teamId),
          eq(learningPatterns.contentType, contentType)
        )
      )
      .orderBy(desc(learningPatterns.successRate))
      .limit(limit);

    return patterns.map((p) => ({
      id: p.id,
      patternType: p.patternType,
      patternName: p.patternName,
      patternValue: p.patternValue,
      successRate: p.successRate,
      confidence: p.confidence,
    }));
  }

  async getAgentStats(teamId: number): Promise<{
    agents: Array<{
      id: number;
      name: string;
      contentType: string;
      totalGenerations: number;
      successfulGenerations: number;
      averageQualityScore: number;
      patternCount: number;
      topPatterns: LearnedPattern[];
    }>;
  }> {
    const agents = await db
      .select()
      .from(learningAgents)
      .where(eq(learningAgents.teamId, teamId));

    const stats = await Promise.all(
      agents.map(async (agent) => {
        const patterns = await this.getTopPatterns(teamId, agent.contentType, 5);
        const patternCount = await db
          .select({ count: sql<number>`count(*)` })
          .from(learningPatterns)
          .where(eq(learningPatterns.agentId, agent.id));

        return {
          id: agent.id,
          name: agent.name,
          contentType: agent.contentType,
          totalGenerations: agent.totalGenerations,
          successfulGenerations: agent.successfulGenerations,
          averageQualityScore: agent.averageQualityScore,
          patternCount: Number(patternCount[0]?.count || 0),
          topPatterns: patterns,
        };
      })
    );

    return { agents: stats };
  }

  async optimizeAgent(teamId: number, agentId: number): Promise<void> {
    const [agent] = await db
      .select()
      .from(learningAgents)
      .where(
        and(
          eq(learningAgents.id, agentId),
          eq(learningAgents.teamId, teamId)
        )
      )
      .limit(1);

    if (!agent) return;

    const beforeMetrics = {
      averageQualityScore: agent.averageQualityScore,
      totalGenerations: agent.totalGenerations,
      successfulGenerations: agent.successfulGenerations,
    };

    const unprocessedMetrics = await db
      .select()
      .from(contentPerformanceMetrics)
      .where(
        and(
          eq(contentPerformanceMetrics.teamId, teamId),
          eq(contentPerformanceMetrics.contentType, agent.contentType),
          eq(contentPerformanceMetrics.feedbackProcessed, 0)
        )
      );

    let patternsUpdated = 0;
    for (const metric of unprocessedMetrics) {
      if (metric.isSuccess !== null) {
        await this.processLearningFeedback(metric.id);
        patternsUpdated++;
      }
    }

    const successfulGenerations = await db
      .select({ count: sql<number>`count(*)` })
      .from(contentPerformanceMetrics)
      .where(
        and(
          eq(contentPerformanceMetrics.teamId, teamId),
          eq(contentPerformanceMetrics.contentType, agent.contentType),
          eq(contentPerformanceMetrics.isSuccess, 1)
        )
      );

    const avgQuality = await db
      .select({ avg: sql<number>`avg(quality_score)` })
      .from(contentPerformanceMetrics)
      .where(
        and(
          eq(contentPerformanceMetrics.teamId, teamId),
          eq(contentPerformanceMetrics.contentType, agent.contentType)
        )
      );

    await db
      .update(learningAgents)
      .set({
        successfulGenerations: Number(successfulGenerations[0]?.count || 0),
        averageQualityScore: Math.round(avgQuality[0]?.avg || 0),
        lastOptimizedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(learningAgents.id, agentId));

    const afterMetrics = {
      averageQualityScore: Math.round(avgQuality[0]?.avg || 0),
      totalGenerations: agent.totalGenerations,
      successfulGenerations: Number(successfulGenerations[0]?.count || 0),
    };

    await db.insert(agentOptimizationLogs).values({
      agentId,
      optimizationType: "pattern_update",
      description: `Processed ${unprocessedMetrics.length} metrics, updated ${patternsUpdated} patterns`,
      beforeMetricsJson: beforeMetrics,
      afterMetricsJson: afterMetrics,
      changesAppliedJson: { metricsProcessed: unprocessedMetrics.length },
      patternsUpdated,
    });

    console.log(`🔄 Optimized agent ${agent.name}: ${patternsUpdated} patterns updated`);
  }

  async seedDefaultPatterns(agentId: number, teamId: number, contentType: string): Promise<void> {
    const defaultPatterns: Record<string, Array<{ type: string; name: string; value: string }>> = {
      article: [
        { type: "opening_style", name: "Direct Answer First", value: "Start with a clear, direct answer to the main question in the first paragraph. Provide the key insight immediately." },
        { type: "opening_style", name: "Problem-Solution Hook", value: "Open with a relatable problem statement, then preview the solution. Create immediate relevance." },
        { type: "tone", name: "Expert Educational", value: "Write in an authoritative but approachable tone. Use 'you' language. Avoid jargon without explanation." },
        { type: "structure", name: "Scannable Format", value: "Use H2 headings every 200-300 words. Include bullet points for key takeaways. Add a summary box." },
        { type: "cta", name: "Soft Value CTA", value: "End with a helpful next step, not a hard sell. Offer additional value before mentioning services." },
        { type: "eeat_signal", name: "Local Expertise", value: "Reference specific local entities, regulations, or case studies. Show first-hand experience." },
      ],
      video: [
        { type: "hook", name: "Pattern Interrupt", value: "Start with an unexpected statement or visual that breaks viewer expectations in the first 2 seconds." },
        { type: "hook", name: "Question Hook", value: "Open with a compelling question that addresses the viewer's pain point directly." },
        { type: "pacing", name: "Fast-Slow-Fast", value: "Quick cuts for energy, slow for key points, quick for transitions. Match audio pacing." },
        { type: "visual_style", name: "Cinematic B-Roll", value: "Use professional b-roll with shallow depth of field. Color grade for warmth and trust." },
        { type: "cta", name: "Value Before Ask", value: "Deliver full value before any CTA. Make the CTA feel like a natural next step, not an interruption." },
      ],
      social: [
        { type: "hook", name: "Curiosity Gap", value: "Create information asymmetry - hint at valuable insight without revealing everything upfront." },
        { type: "format", name: "List with Twist", value: "Use numbered lists but include one unexpected or contrarian point to stand out." },
        { type: "hashtag", name: "Niche + Broad Mix", value: "Use 2-3 niche hashtags (high relevance) + 1-2 broad hashtags (discovery potential)." },
        { type: "tone", name: "Conversational Authority", value: "Sound like a knowledgeable friend, not a corporate brand. Use contractions and direct address." },
        { type: "cta", name: "Engagement Prompt", value: "End with a question or poll to drive comments. Boost algorithm visibility through engagement." },
      ],
      podcast: [
        { type: "opening", name: "Story Cold Open", value: "Start mid-story or with a compelling quote. Skip intros - hook listeners immediately." },
        { type: "pacing", name: "Energy Variation", value: "Vary energy levels throughout. Low for reflection, high for key insights. Avoid monotone." },
        { type: "structure", name: "Conversational Chapters", value: "Organize around 3-4 main topics. Signal transitions naturally through conversation." },
        { type: "engagement", name: "Direct Address", value: "Speak to the listener as 'you'. Include them in the conversation. Anticipate their questions." },
      ],
      image: [
        { type: "composition", name: "Rule of Thirds with Focus", value: "Place subject at intersection points. Use depth of field to direct attention." },
        { type: "color", name: "Brand-Consistent Palette", value: "Use 2-3 core colors consistently. Warm tones for trust, cool for professionalism." },
        { type: "style", name: "Authentic Over Stock", value: "Prefer realistic, authentic imagery over polished stock photos. Real > perfect." },
        { type: "text", name: "Minimal Readable Text", value: "If adding text, use high contrast and minimal words. Text should be readable at all sizes." },
      ],
    };

    const patterns = defaultPatterns[contentType] || [];

    for (const pattern of patterns) {
      await this.addPattern(agentId, teamId, {
        patternType: pattern.type,
        patternName: pattern.name,
        patternValue: pattern.value,
      });
    }

    console.log(`🌱 Seeded ${patterns.length} default patterns for ${contentType} agent`);
  }

  async getFactAwareOptimizationContext(
    teamId: number,
    contentType: string,
    options: { topic?: string; entityTypes?: string[] } = {}
  ): Promise<OptimizationContext & { factCoverage: { totalFacts: number; recommendations: string[] } }> {
    const baseContext = await this.getOptimizationContext(teamId, contentType);
    if (!baseContext) throw new Error(`No optimization context for team ${teamId}, type ${contentType}`);
    
    const factCoverage = await getFactCoverageReport(teamId, options.topic, options.entityTypes);
    
    const factAwareEnhancements = [...baseContext.promptEnhancements];
    
    if (factCoverage.totalFacts > 0) {
      factAwareEnhancements.push(
        `FACT VALIDATION ACTIVE: ${factCoverage.totalFacts} verified facts available (avg confidence: ${factCoverage.averageConfidence}%)`
      );
      
      if (factCoverage.expiringFacts > 0) {
        factAwareEnhancements.push(
          `⚠️ ${factCoverage.expiringFacts} facts expiring soon - verify before using`
        );
      }
    } else {
      factAwareEnhancements.push(
        `⚠️ NO VERIFIED FACTS AVAILABLE - Content generation may include unverified claims`
      );
    }
    
    console.log(`🧠 [Learning+Facts] Context for ${contentType}: ${baseContext.patterns.length} patterns, ${factCoverage.totalFacts} facts`);
    
    return {
      ...baseContext,
      promptEnhancements: factAwareEnhancements,
      factCoverage: {
        totalFacts: factCoverage.totalFacts,
        recommendations: factCoverage.recommendations,
      },
    } as OptimizationContext & { factCoverage: { totalFacts: number; recommendations: string[] } };
  }

  async validatePatternAgainstFacts(
    patternId: number,
    teamId: number
  ): Promise<{ valid: boolean; concerns: string[] }> {
    const [pattern] = await db
      .select()
      .from(learningPatterns)
      .where(eq(learningPatterns.id, patternId))
      .limit(1);

    if (!pattern) {
      return { valid: false, concerns: ["Pattern not found"] };
    }

    const concerns: string[] = [];

    const claimIndicators = [
      /\d+%/,
      /according to/i,
      /studies show/i,
      /research indicates/i,
      /statistics/i,
      /data shows/i,
    ];

    const containsClaim = claimIndicators.some((regex) =>
      regex.test(pattern.patternValue)
    );

    if (containsClaim) {
      const factPack = await factStore.searchFacts({
        teamId,
        query: pattern.patternValue.substring(0, 100),
        limit: 5,
      });

      if (factPack.length === 0) {
        concerns.push(
          `Pattern "${pattern.patternName}" contains claims but no supporting facts found`
        );
      }
    }

    return {
      valid: concerns.length === 0,
      concerns,
    };
  }

  /**
   * DETERMINISTIC HUMANIZATION: Analyze and improve pattern text quality
   * Ensures learned patterns don't perpetuate AI-isms
   */
  async analyzePatternQuality(
    teamId: number,
    patternId: number
  ): Promise<{
    quality: ReturnType<typeof analyzeContentQuality>;
    needsHumanization: boolean;
    recommendations: string[];
  }> {
    const [pattern] = await db
      .select()
      .from(learningPatterns)
      .where(eq(learningPatterns.id, patternId));

    if (!pattern) {
      throw new Error(`Pattern ${patternId} not found`);
    }

    const quality = analyzeContentQuality(pattern.patternValue);
    const recommendations: string[] = [];

    if (quality.aiIsmCount > 0) {
      recommendations.push(`Contains ${quality.aiIsmCount} AI-isms that should be scrubbed`);
    }

    if (quality.burstiness < 0.3) {
      recommendations.push(`Low sentence variety (${quality.burstiness}) - add more sentence length variation`);
    }

    if (quality.averageSentenceLength > 25) {
      recommendations.push(`Long average sentence length (${quality.averageSentenceLength}) - break into shorter sentences`);
    }

    return {
      quality,
      needsHumanization: recommendations.length > 0,
      recommendations,
    };
  }

  /**
   * DETERMINISTIC HUMANIZATION: Apply humanization to pattern text
   * Used when patterns are applied to new content
   */
  humanizePatternForApplication(
    patternValue: string,
    contentType: string
  ): HumanizationResult {
    const configByType: Record<string, HumanizationConfig> = {
      [ContentType.ARTICLE]: { burstinessTarget: 0.45, scrubLevel: "standard", channelFormat: "article" },
      [ContentType.SOCIAL]: { burstinessTarget: 0.35, scrubLevel: "aggressive", channelFormat: "social" },
      [ContentType.VIDEO]: { burstinessTarget: 0.40, scrubLevel: "standard", channelFormat: "video" },
      [ContentType.PODCAST]: { burstinessTarget: 0.50, scrubLevel: "minimal", channelFormat: "podcast" },
    };

    const config = configByType[contentType] || configByType[ContentType.ARTICLE]!
    return humanizeContent(patternValue, config);
  }

  /**
   * DETERMINISTIC HUMANIZATION: Get humanization-aware optimization context
   * Enhances prompt suggestions with anti-AI-ism guidelines
   */
  async getHumanizedOptimizationContext(
    teamId: number,
    contentType: string,
    options?: {
      industry?: string;
      audience?: string;
      patternTypes?: string[];
      stableId?: string;
      terminalKpi?: string;
      campaignId?: number | null;
    }
  ): Promise<OptimizationContext & { humanizationGuidelines: string[] }> {
    const baseContext = await this.getOptimizationContext(teamId, contentType, options);
    if (!baseContext) throw new Error(`No optimization context for team ${teamId}, type ${contentType}`);
    
    const humanizationGuidelines = [
      "Vary sentence lengths naturally - mix short punchy sentences with longer ones",
      "Avoid corporate jargon: 'leverage', 'synergy', 'paradigm shift', 'game-changer'",
      "Start sentences differently - avoid repetitive patterns",
      "Use active voice and concrete examples",
      "Remove filler phrases: 'It's worth noting', 'In today's world', 'Let's dive into'",
    ];

    // Analyze existing patterns for quality
    for (const pattern of baseContext.patterns) {
      const quality = analyzeContentQuality(pattern.patternValue);
      if (quality.aiIsmCount > 2) {
        console.warn(`⚠️ [DH-Learning] Pattern "${pattern.patternName}" contains ${quality.aiIsmCount} AI-isms`);
      }
    }

    return {
      ...baseContext,
      humanizationGuidelines,
    } as OptimizationContext & { humanizationGuidelines: string[] };
  }

  // ============================================================================
  // GUARDIAN AGENT FAILURE LEDGER
  // ============================================================================

  async recordGuardianFailures(
    teamId: number,
    contentType: string,
    failures: string[]
  ): Promise<void> {
    try {
      const { aiLearningLedger } = await import("../shared/schema");
      const now = new Date();

      for (const failure of failures) {
        const errorType = failure.split(":")[0]!.trim().toUpperCase();
        const existing = await db
          .select()
          .from(aiLearningLedger)
          .where(
            and(
              eq(aiLearningLedger.teamId, teamId),
              eq(aiLearningLedger.contentType, contentType),
              eq(aiLearningLedger.errorType, errorType)
            )
          )
          .limit(1);

        if (existing.length > 0) {
          await db
            .update(aiLearningLedger)
            .set({ count: existing[0]!.count + 1, lastOccurrence: now })
            .where(eq(aiLearningLedger.id, existing[0]!.id));
        } else {
          await db.insert(aiLearningLedger).values({
            teamId,
            contentType,
            errorType,
            count: 1,
            lastOccurrence: now,
          });
        }
      }
    } catch (error) {
      console.warn("⚠️ Failed to record Guardian failures to ledger:", error);
    }
  }

  async getTopRecurringFailures(
    teamId: number,
    contentType: string,
    limit = 3
  ): Promise<Array<{ errorType: string; count: number; lastOccurrence: Date }>> {
    try {
      const { aiLearningLedger } = await import("../shared/schema");
      const rows = await db
        .select()
        .from(aiLearningLedger)
        .where(
          and(
            eq(aiLearningLedger.teamId, teamId),
            eq(aiLearningLedger.contentType, contentType)
          )
        )
        .orderBy(desc(aiLearningLedger.count))
        .limit(limit);

      return rows.map(r => ({
        errorType: r.errorType,
        count: r.count,
        lastOccurrence: r.lastOccurrence,
      }));
    } catch (error) {
      console.warn("⚠️ Failed to fetch recurring failures from ledger:", error);
      return [];
    }
  }

  // ============================================================================
  // Task #25: Competitive Intelligence — External Pattern Seeding
  // ============================================================================

  /**
   * Seed external patterns discovered via competitive research into the learning
   * system at a low initial Wilson score (floor of 5).  They compete in the
   * Thompson Sampling exploration slot alongside internal patterns but only
   * graduate to the exploitation pool once validatedByOwnAudience is promoted.
   *
   * Uses an upsert strategy keyed on (agentId, patternType, patternName) to
   * avoid duplicates when research is run multiple times for the same niche.
   */
  async seedExternalPatterns(
    teamId: number,
    contentType: string,
    patterns: Array<{
      patternType: string;
      patternName: string;
      patternValue: string;
      externalUrl?: string;
      externalPlatform?: string;
    }>
  ): Promise<{ seeded: number; skipped: number }> {
    let seeded = 0;
    let skipped = 0;

    const agent = await this.getAgentForContentType(teamId, contentType);
    if (!agent) {
      await this.initializeDefaultAgents(teamId);
      const newAgent = await this.getAgentForContentType(teamId, contentType);
      if (!newAgent) {
        console.warn(`[CompetitiveIntel] No agent found for team ${teamId} / ${contentType}`);
        return { seeded: 0, skipped: patterns.length };
      }
    }

    const resolvedAgent = agent ?? (await this.getAgentForContentType(teamId, contentType));
    if (!resolvedAgent) return { seeded: 0, skipped: patterns.length };

    for (const p of patterns) {
      try {
        // Check for duplicate by agentId + patternType + patternName
        const existing = await db
          .select({ id: learningPatterns.id })
          .from(learningPatterns)
          .where(
            and(
              eq(learningPatterns.agentId, resolvedAgent.id),
              eq(learningPatterns.patternType, p.patternType),
              eq(learningPatterns.patternName, p.patternName)
            )
          )
          .limit(1);

        if (existing.length > 0) {
          skipped++;
          continue;
        }

        await db.insert(learningPatterns).values({
          agentId: resolvedAgent.id,
          teamId,
          contentType,
          patternType: p.patternType,
          patternName: p.patternName,
          patternValue: p.patternValue,
          successRate: 5,      // Floor Wilson score — must be validated up
          engagementScore: 5,
          qualityScore: 50,
          confidence: 0,
          // External CI fields
          source: "external",
          externalUrl: p.externalUrl ?? null,
          externalPlatform: p.externalPlatform ?? null,
          validatedByOwnAudience: false,
        } as any);

        seeded++;
      } catch (err) {
        console.warn(`[CompetitiveIntel] Failed to seed pattern "${p.patternName}":`, (err as Error).message);
        skipped++;
      }
    }

    // After seeding: promote external patterns whose Wilson score now exceeds
    // the internal median for this dimension (graduated → validatedByOwnAudience=true).
    await this.promoteValidatedExternalPatterns(teamId, contentType);

    console.log(`[CompetitiveIntel] Seeded ${seeded} external patterns, skipped ${skipped} duplicates`);
    return { seeded, skipped };
  }

  /**
   * Promote external patterns whose success rate has risen above the internal
   * median for their content type — signalling the team's own audience has
   * validated them.
   */
  private async promoteValidatedExternalPatterns(teamId: number, contentType: string): Promise<void> {
    try {
      const [medianRow] = await db
        .select({ median: sql<number>`percentile_cont(0.5) WITHIN GROUP (ORDER BY success_rate)` })
        .from(learningPatterns)
        .where(
          and(
            eq(learningPatterns.teamId, teamId),
            eq(learningPatterns.contentType, contentType),
            eq(learningPatterns.source, "internal"),
            eq(learningPatterns.isArchived, false)
          )
        );

      const internalMedian = Number(medianRow?.median ?? 0);
      if (internalMedian === 0) return; // Not enough internal data yet

      await db
        .update(learningPatterns)
        .set({ validatedByOwnAudience: true, updatedAt: new Date() })
        .where(
          and(
            eq(learningPatterns.teamId, teamId),
            eq(learningPatterns.contentType, contentType),
            eq(learningPatterns.source, "external"),
            eq(learningPatterns.validatedByOwnAudience, false),
            sql`${learningPatterns.successRate} > ${internalMedian}`
          )
        );
    } catch {
      // Non-fatal
    }
  }

  /**
   * Return external patterns for a team + content type with their validation status.
   */
  async getExternalPatterns(
    teamId: number,
    contentType: string
  ): Promise<Array<{
    id: number;
    patternType: string;
    patternName: string;
    patternValue: string;
    successRate: number;
    confidence: number;
    externalUrl?: string | null;
    externalPlatform?: string | null;
    validatedByOwnAudience: boolean;
    createdAt: Date;
  }>> {
    const rows = await db
      .select()
      .from(learningPatterns)
      .where(
        and(
          eq(learningPatterns.teamId, teamId),
          eq(learningPatterns.contentType, contentType),
          eq(learningPatterns.source, "external"),
          eq(learningPatterns.isArchived, false)
        )
      )
      .orderBy(desc(learningPatterns.successRate))
      .limit(50);

    return rows.map(r => ({
      id: r.id,
      patternType: r.patternType,
      patternName: r.patternName,
      patternValue: r.patternValue,
      successRate: r.successRate,
      confidence: r.confidence,
      externalUrl: (r as any).externalUrl ?? null,
      externalPlatform: (r as any).externalPlatform ?? null,
      validatedByOwnAudience: (r as any).validatedByOwnAudience ?? false,
      createdAt: r.createdAt,
    }));
  }
}

export const learningService = LearningService.getInstance();
