import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import speakeasy from "speakeasy";
import qrcode from "qrcode";
import { nanoid } from "nanoid";
import crypto from "crypto";

// Lazy getter — throws at call time, not module load time.
// A module-scope throw in Next.js 16 Turbopack silently converts every route
// in the import chain to a cached 404 with no terminal output. Throwing inside
// the functions that actually need the secret gives the same "fail fast" safety
// while keeping the module loadable at cold-boot even if dotenv hasn't fired yet.
function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("FATAL: JWT_SECRET environment variable is not set. Authentication cannot proceed.");
  }
  return secret;
}

const JWT_EXPIRES_IN_SECONDS = 24 * 60 * 60;
const REFRESH_TOKEN_EXPIRES_IN = "7d"; // 7 days

// ============================================================================
// PASSWORD HASHING
// ============================================================================

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return bcrypt.hash(password, saltRounds);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ============================================================================
// JWT TOKEN MANAGEMENT
// ============================================================================

export interface JWTPayload {
  userId: number;
  email: string;
  role: string;
  sessionId?: number;
  tokenPurpose?: "access";
}

export function generateAccessToken(
  payload: JWTPayload,
  expiresInSeconds: number = JWT_EXPIRES_IN_SECONDS,
): string {
  // jti (JWT ID) ensures each token is unique even when two are issued for the
  // same user within the same second, preventing tokenHash unique-key collisions.
  return jwt.sign(
    { ...payload, tokenPurpose: "access", jti: crypto.randomBytes(16).toString("hex") },
    getJwtSecret(),
    { expiresIn: expiresInSeconds }
  );
}

export function generateRefreshToken(payload: JWTPayload): string {
  return jwt.sign(
    { ...payload, jti: crypto.randomBytes(16).toString("hex") },
    getJwtSecret(),
    { expiresIn: REFRESH_TOKEN_EXPIRES_IN }
  );
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as JWTPayload & { purpose?: string };
    if (decoded.purpose || (decoded.tokenPurpose && decoded.tokenPurpose !== "access")) return null;
    return decoded;
  } catch (error) {
    return null;
  }
}

export function hashToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

// ============================================================================
// TOTP (Google Authenticator)
// ============================================================================

export interface TOTPSetup {
  secret: string;
  qrCodeUrl: string;
  manualEntryKey: string;
}

interface TOTPSetupTokenPayload {
  purpose: "totp_setup";
  userId: number;
  secret: string;
  sessionId: number;
  factorVersion: number;
  passwordBinding: string;
}

export function generateTOTPSetupToken(
  userId: number,
  secret: string,
  sessionId: number,
  factorVersion: number,
  passwordHash: string,
): string {
  return jwt.sign(
    {
      purpose: "totp_setup",
      userId,
      secret,
      sessionId,
      factorVersion,
      passwordBinding: hashToken(passwordHash),
      jti: crypto.randomBytes(16).toString("hex"),
    },
    getJwtSecret(),
    { expiresIn: 10 * 60 },
  );
}

export function verifyTOTPSetupToken(token: string): TOTPSetupTokenPayload | null {
  try {
    const payload = jwt.verify(token, getJwtSecret()) as TOTPSetupTokenPayload;
    if (
      payload.purpose !== "totp_setup" ||
      !payload.userId ||
      !payload.secret ||
      !payload.sessionId ||
      !Number.isInteger(payload.factorVersion) ||
      !payload.passwordBinding
    ) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function generateTOTPSecret(userEmail: string, appName: string = "Citefi"): Promise<TOTPSetup> {
  const secret = speakeasy.generateSecret({
    name: `${appName} (${userEmail})`,
    issuer: appName,
    length: 32,
  });

  const qrCodeUrl = await qrcode.toDataURL(secret.otpauth_url!);

  return {
    secret: secret.base32!,
    qrCodeUrl,
    manualEntryKey: secret.base32!,
  };
}

export function verifyTOTPToken(token: string, secret: string): boolean {
  return verifyTOTPTokenCounter(token, secret) !== null;
}

export function verifyTOTPTokenCounter(
  token: string,
  secret: string,
  nowMs: number = Date.now(),
): number | null {
  if (!/^\d{6}$/.test(token)) return null;
  const stepSeconds = 30;
  const nowSeconds = Math.floor(nowMs / 1000);
  const match = speakeasy.totp.verifyDelta({
    secret,
    encoding: "base32",
    token,
    window: 1, // Allow one 30-second step of clock drift in either direction
    step: stepSeconds,
    time: nowSeconds,
  });
  return match ? Math.floor(nowSeconds / stepSeconds) + match.delta : null;
}

// ============================================================================
// EMAIL VERIFICATION CODES
// ============================================================================

export function generateEmailCode(): string {
  return crypto.randomInt(100000, 1_000_000).toString();
}

// ============================================================================
// BACKUP CODES
// ============================================================================

export async function generateBackupCodes(count: number = 10): Promise<string[]> {
  const codes: string[] = [];
  for (let i = 0; i < count; i++) {
    codes.push(nanoid(12));
  }
  return codes;
}

export async function hashBackupCodes(codes: string[]): Promise<string[]> {
  return Promise.all(codes.map(code => hashPassword(code)));
}

export async function verifyBackupCode(code: string, hashedCodes: string[]): Promise<boolean> {
  return (await findBackupCodeIndex(code, hashedCodes)) !== null;
}

export async function findBackupCodeIndex(code: string, hashedCodes: string[]): Promise<number | null> {
  for (const hashedCode of hashedCodes) {
    if (await verifyPassword(code, hashedCode)) {
      return hashedCodes.indexOf(hashedCode);
    }
  }
  return null;
}

// ============================================================================
// PASSWORD VALIDATION
// ============================================================================

export interface PasswordValidationResult {
  isValid: boolean;
  errors: string[];
}

export function validatePassword(password: string): PasswordValidationResult {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push("Password must be at least 8 characters long");
  }

  if (!/[a-z]/.test(password)) {
    errors.push("Password must contain at least one lowercase letter");
  }

  if (!/[A-Z]/.test(password)) {
    errors.push("Password must contain at least one uppercase letter");
  }

  if (!/[0-9]/.test(password)) {
    errors.push("Password must contain at least one number");
  }

  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push("Password must contain at least one special character");
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

// ============================================================================
// RATE LIMITING HELPERS
// ============================================================================

export function calculateLockoutDuration(failedAttempts: number): number {
  if (failedAttempts >= 10) return 60 * 60 * 1000; // 1 hour
  if (failedAttempts >= 7) return 30 * 60 * 1000; // 30 minutes
  if (failedAttempts >= 5) return 15 * 60 * 1000; // 15 minutes
  return 0;
}

export function isAccountLocked(lockedUntil: Date | null): boolean {
  if (!lockedUntil) return false;
  return new Date() < new Date(lockedUntil);
}
